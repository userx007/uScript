#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif


static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x6626afca, "down" },
	{ 0xcf2a6966, "up" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xbd394d8, "tty_termios_baud_rate" },
	{ 0x436eea25, "sysfs_notify" },
	{ 0xb8aa396d, "tty_check_change" },
	{ 0x668b19a1, "down_read" },
	{ 0x53b954a2, "up_read" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x36cce78, "tty_termios_input_baud_rate" },
	{ 0xc5b03fe3, "tty_set_termios" },
	{ 0xa19b956, "__stack_chk_fail" },
	{ 0x528bfe0f, "tty_insert_flip_string_fixed_flag" },
	{ 0x1877d2c2, "tty_flip_buffer_push" },
	{ 0x9fc40b2f, "__tty_alloc_driver" },
	{ 0x67b27ec1, "tty_std_termios" },
	{ 0xe0f5dd83, "tty_port_init" },
	{ 0xdd084802, "tty_port_link_device" },
	{ 0xa4710563, "tty_register_driver" },
	{ 0x92997ed8, "_printk" },
	{ 0xd70707dd, "tty_driver_kref_put" },
	{ 0xc80d0404, "kmalloc_caches" },
	{ 0x52dd86bf, "kmalloc_trace" },
	{ 0xdb0e5e97, "tty_register_device_attr" },
	{ 0x4f382dac, "tty_unregister_device" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xe0a683ed, "current_task" },
	{ 0xaad8c7d6, "default_wake_function" },
	{ 0x4afb2238, "add_wait_queue" },
	{ 0x1000e51, "schedule" },
	{ 0x37110088, "remove_wait_queue" },
	{ 0x6383b27c, "__x86_indirect_thunk_rdx" },
	{ 0xae468c07, "tty_unthrottle" },
	{ 0x58e8e293, "tty_driver_flush_buffer" },
	{ 0xe2964344, "__wake_up" },
	{ 0xbc9a9add, "tty_port_destroy" },
	{ 0x5643c620, "tty_unregister_driver" },
	{ 0x37a0cba, "kfree" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x160c03af, "module_layout" },
};

MODULE_INFO(depends, "");

