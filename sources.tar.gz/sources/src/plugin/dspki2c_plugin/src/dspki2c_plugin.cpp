#include "ICommDriver.hpp"
#include "PluginExport.hpp"
#include "dspki2c_plugin.hpp"
#include "dspki2c_setup.hpp"
#include "uCommScriptClient.hpp"
#include "uCommScriptCommandInterpreter.hpp"
#include "uCommScriptDataTypes.hpp"
#include "uCommandExec.hpp"
#include "uDigisparkI2C.hpp"
#include "uFile.hpp"
#include "uHexlify.hpp"
#include "uLogger.hpp"
#include "uNumeric.hpp"
#include "uPluginSettings.hpp"
#include "uSharedConfig.hpp"
#include "uString.hpp"

#include <stdint.h>
#include <cstdio>
#include <exception>
#include <memory>
#include <new>
#include <span>
#include <stop_token>
#include <string>
#include <vector>

/////////////////////////////////////////////////////////////////////////////////
//                  PLUGIN ENTRY POINTS                                        //
/////////////////////////////////////////////////////////////////////////////////

extern "C"
{
    EXPORTED DSPKi2cPlugin* pluginEntry()
    {
        return new DSPKi2cPlugin();
    }

    EXPORTED void pluginExit( DSPKi2cPlugin *ptrPlugin)
    {
        if (nullptr != ptrPlugin)
        {
            delete ptrPlugin;
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////
//                 PLUGIN TOP LEVEL COMMANDS                                   //
/////////////////////////////////////////////////////////////////////////////////

/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief INFO command implementation; shows details about plugin and
  *        describes the supported functions with examples of usage.
  *        This command takes no arguments and is executed even if the plugin initialization fails.
  *
  * \note Usage example:
  *       DSPKI2C.INFO
  *
  * \param[in] args empty string (no arguments expected)
  *
  * \return true on success, false otherwise
*/
/*--------------------------------------------------------------------------------------------------------*/


bool DSPKi2cPlugin::m_DSPKI2C_INFO (const std::string &args, std::stop_token st ) const
{
    // expected no arguments
    if (!args.empty())
    {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Expected no argument(s)"));
        return false;
    }

    // if plugin is not enabled stop execution here and return true as the argument(s) validation passed
    if (!m_bIsEnabled)
    {
        return true;
    }

    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING(DSPKI2C_PLUGIN_NAME); LOG_STRING("Vers:"); LOG_STRING(m_strVersion));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Build:"); LOG_STRING(__DATE__); LOG_STRING(__TIME__));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Description: communicate with I2C devices via Digispark ATtiny85 USB bridge"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CONFIG : configure the USB bridge and I2C parameters"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Args   : [v=vid] [p=pid] [a=slave_addr] [r=read_tout] [w=write_tout] [s=recv_bufsize]"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Usage  : DSPKI2C.CONFIG v=16C0 p=05DF a=48 r=2000 w=2000 s=64"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         DSPKI2C.CONFIG a=68 r=500"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note   : VID/PID are hex (no 0x prefix); slave_addr is 7-bit hex"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("SCAN   : discover all responding I2C slaves on the bus"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Args   : (none)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Usage  : DSPKI2C.SCAN"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CMD    : send, receive or both over I2C"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Args   : direction message"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Usage  : DSPKI2C.CMD > H\"AABBCCDD\" | ok"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         DSPKI2C.CMD < \"Please send!\" | F\"data.bin, 64\""));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note   : can be both sent/received: (un)quoted strings, hex lines"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note   : can be only sent: files, only received: tokens"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("SCRIPT : send commands from a file"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Args   : script [|delay]"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Usage  : DSPKI2C.SCRIPT script.txt"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         DSPKI2C.SCRIPT i2c_seq.txt |50"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CYCLIC : send one or more periodic messages"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Args   : time1 val1 [id1], time2 val2 [id2], ... (time_i in ms, val_i hex)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Usage  : DSPKI2C.CYCLIC 100 AABBCCDD 0x50, 250 1122 0x51"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         DSPKI2C.CYCLIC 100 AABBCCDD 0x50, 250 1122 0x51 &"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note   : id is optional; when omitted, falls back to the default slave address"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         set via CONFIG"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note   : without '&' sends one full pattern (lcm of the time_i) then returns;"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         with '&' repeats forever until the script/thread is stopped"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("INI file parameters (copy/paste into your ini file):"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("[DSPKI2C]"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("ARTEFACTS_PATH =         # directory used by SCRIPT/CMD/wrrdf for reading/writing artefact files"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("I2C_VID        = 0x16C0  # USB VID of the digispark I2C bridge"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("I2C_PID        = 0x05DF  # USB PID of the digispark I2C bridge"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("I2C_SLAVE_ADDR = 0x00    # 7-bit I2C slave address"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("READ_TIMEOUT   = 2000    # read timeout in ms"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("WRITE_TIMEOUT  = 2000    # write timeout in ms"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("READ_BUF_SIZE  = 64      # size in bytes of the local read buffer"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("RAW_RESULT     = false   # CMD returns raw bytes instead of a hexlified string when true"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CYCLIC_CACHED  = true    # true=validate/parse each CYCLIC entry once per session; false=re-resolve every tick (needed for volatile ?= macros)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note: the CONFIG command above can override a subset of these at runtime;"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("      any key not accepted by CONFIG must be set via the ini file."));


    return true;

}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief CONFIG command implementation; overwrite the current I2C/USB bridge parameters.
  *
  * \note Usage examples:
  *       DSPKI2C.CONFIG v=16C0 p=05DF a=48 r=2000 w=2000 s=64
  *       DSPKI2C.CONFIG a=68 r=500
  *
  * \param[in] args  space-separated key=value pairs (see dspki2c_setup.hpp)
  *
  * \return true if all parameters were accepted, false otherwise
*/
/*--------------------------------------------------------------------------------------------------------*/


bool DSPKi2cPlugin::m_DSPKI2C_CONFIG ( const std::string &args, std::stop_token st ) const
{
    return generic_i2c_set_params<DSPKi2cPlugin>(this, args);
}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief SCAN command implementation; discovers all responding I2C slave addresses.
  *
  * Opens a fresh I2CBridge connection, issues a bus scan (CMD_SCAN), logs each
  * found address, and closes the device.  The scan result is also appended to
  * m_strResultData so callers can retrieve addresses programmatically via getData().
  *
  * \note Usage example:
  *       DSPKI2C.SCAN
  *
  * \param[in] args  empty string (no arguments expected)
  *
  * \return true on success, false otherwise
*/
/*--------------------------------------------------------------------------------------------------------*/

bool DSPKi2cPlugin::m_DSPKI2C_SCAN ( const std::string &args, std::stop_token st ) const
{
    bool bRetVal = false;

    do {

        if (!args.empty()) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Expected no argument(s)"));
            break;
        }

        // if plugin is not enabled stop execution here and return true as the argument(s) validation passed
        if (false == m_bIsEnabled) {
            bRetVal = true;
            break;
        }

        try {
            // RAII: open the Digispark bridge; destructor calls close()
            auto shpBridge = std::make_shared<I2CBridge>(m_u16Vid, m_u16Pid);

            if (!shpBridge->is_open()) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to open I2C bridge (VID/PID mismatch or device absent)"));
                break;
            }

            auto result = shpBridge->scan(I2CBridge::I2C_SCAN_DEFAULT_TIMEOUT);

            if (result.status != ICommDriver::Status::SUCCESS) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Bus scan failed:"); LOG_STRING(ICommDriver::to_string(result.status)));
                break;
            }

            if (result.addresses.empty()) {
                LOG_PRINT(LOG_INFO, LOG_HDR; LOG_STRING("Bus scan complete — no devices found"));
            } else {
                LOG_PRINT(LOG_INFO, LOG_HDR; LOG_STRING("Bus scan complete — found addresses:"));
                for (uint8_t addr : result.addresses) {
                    LOG_PRINT(LOG_EMPTY, LOG_HDR; LOG_HEX8(addr));
                    // append to result data for programmatic retrieval
                    char buf[8];
                    std::snprintf(buf, sizeof(buf), "0x%02X\n", addr);
                    m_strResultData += buf;
                }
            }

            bRetVal = true;

        } catch (const std::bad_alloc& e) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Memory allocation failed:"); LOG_STRING(e.what()));
        } catch (const std::exception& e) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Execution failed:"); LOG_STRING(e.what()));
        }

    } while(false);

    return bRetVal;

}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief CMD command implementation; sends and/or receives I2C frames.
  *
  * Uses the same mini-language as UART.CMD.  The I2CBridge is opened
  * fresh per invocation (RAII) using the currently configured VID/PID
  * and slave address.
  *
  * \note Usage examples:
  *       DSPKI2C.CMD > H"AABBCCDD" | ok
  *       DSPKI2C.CMD < "Ping" | H"FF"
  *
  * \param[in] args  command string parsed by CommScriptCommandValidator
  *
  * \return true on success, false otherwise
*/
/*--------------------------------------------------------------------------------------------------------*/


bool DSPKi2cPlugin::m_DSPKI2C_CMD ( const std::string &args, std::stop_token st ) const
{
    (void)st;

    return ucmdexec::generic_cmd(
        args, m_bIsEnabled,
        [this]() -> std::shared_ptr<I2CBridge> {
            // RAII: open the Digispark bridge; destructor calls close()
            auto shpBridge = std::make_shared<I2CBridge>(m_u16Vid, m_u16Pid);

            if (!shpBridge->is_open()) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to open I2C bridge (VID/PID mismatch or device absent)"));
                return nullptr;
            }

            return shpBridge;
        },
        m_strInstanceName,
        m_u32ReadBufferSize, m_u32ReadTimeout, LT_HDR, &m_strResultData, m_bRawResult, {}, {}, st);
}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief SCRIPT command implementation; executes a file containing CMD lines.
  *
  * \note Usage examples:
  *       DSPKI2C.SCRIPT i2c_seq.txt
  *       DSPKI2C.SCRIPT i2c_seq.txt |50
  *
  * \param[in] args  scriptpathname [|delay_ms]
  *
  * \return true on success, false otherwise
*/
/*--------------------------------------------------------------------------------------------------------*/

bool DSPKi2cPlugin::m_DSPKI2C_SCRIPT ( const std::string &args, std::stop_token st ) const
{
    (void)st;

    return ucmdexec::generic_script(
        args, m_bIsEnabled,
        [this]() -> std::shared_ptr<I2CBridge> {
            // RAII: open the Digispark bridge; destructor calls close()
            auto shpBridge = std::make_shared<I2CBridge>(m_u16Vid, m_u16Pid);

            if (!shpBridge->is_open()) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to open I2C bridge (VID/PID mismatch or device absent)"));
                return nullptr;
            }

            return shpBridge;
        },
        m_strInstanceName,
        m_strArtefactsPath, m_u32ReadBufferSize, m_u32ReadTimeout, LT_HDR, {}, {}, st);
}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief CYCLIC command implementation; send one or more periodic DSPKI2C messages.
  *
  * \note The Digispark I2C bridge is opened once for the whole CYCLIC session (like SCRIPT) and
  *       closed automatically on return (RAII). Each entry's optional "id" is the 7-bit I2C
  *       slave address (decimal or 0x-hex; falls back to the default slave address set via
  *       CONFIG when omitted) and "val" is the payload as a plain hex string (e.g. "AABBCCDD").
  *
  * \note Usage example:
  *       DSPKI2C.CYCLIC 100 AABBCCDD 0x50, 250 1122 0x51
  *       DSPKI2C.CYCLIC 100 AABBCCDD 0x50, 250 1122 0x51 &
  *
  * \param[in] args  "time1 val1 , time2 val2 , ..." (see generic_send_cyclic())
  * \param[in] st    stop_token; forwarded as-is (present/absent '&' selects run-once vs. forever)
  *
  * \return true on success, false otherwise
*/
/*--------------------------------------------------------------------------------------------------------*/

bool DSPKi2cPlugin::m_DSPKI2C_CYCLIC ( const std::string &args, std::stop_token st ) const
{
    return ucmdexec::generic_send_cyclic(
        args, m_bIsEnabled,
        [this]() -> std::shared_ptr<I2CBridge> {
            // RAII: open the Digispark bridge; destructor calls close()
            auto shpBridge = std::make_shared<I2CBridge>(m_u16Vid, m_u16Pid);

            if (!shpBridge->is_open()) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to open I2C bridge (VID/PID mismatch or device absent)"));
                return nullptr;
            }

            return shpBridge;
        },

        m_strInstanceName, m_u32ReadBufferSize, m_u32ReadTimeout, LT_HDR, st, m_bCyclicCached);
}


/////////////////////////////////////////////////////////////////////////////////
//            PRIVATE INTERFACES IMPLEMENTATION                                //
/////////////////////////////////////////////////////////////////////////////////


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief Load and validate settings from the INI file / PluginDataSet.
  *
  * Recognised keys (case-sensitive):
  *   ARTEFACTS_PATH, I2C_VID, I2C_PID, I2C_SLAVE_ADDR,
  *   READ_TIMEOUT, WRITE_TIMEOUT, READ_BUF_SIZE
*/
/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief message sender — delegates to ICommDriver::tout_write().
  *
  * The I2CBridge base-interface write convention requires the first byte of
  * the buffer to be the 7-bit slave address.  This wrapper prepends the
  * configured m_u8SlaveAddr automatically so callers can pass raw payload.
*/
/*--------------------------------------------------------------------------------------------------------*/

bool DSPKi2cPlugin::m_Send( std::span<const uint8_t> dataSpan, std::shared_ptr<const ICommDriver> shpDriver ) const
{
    // Build a buffer with the slave address as the leading byte
    std::vector<uint8_t> buf;
    buf.reserve(1 + dataSpan.size());
    buf.push_back(m_u8SlaveAddr);
    buf.insert(buf.end(), dataSpan.begin(), dataSpan.end());

    auto result = shpDriver->tout_write(m_u32WriteTimeout, std::span<const uint8_t>(buf));

    if (result.status != ICommDriver::Status::SUCCESS) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Write failed:");
                  LOG_STRING(ICommDriver::to_string(result.status));
                  LOG_STRING("Bytes written:"); LOG_SIZET(result.bytes_written));
        return false;
    }

    return true;
}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief message receiver — delegates to ICommDriver::tout_read().
  *
  * Maps CommCommandReadType onto ICommDriver::ReadMode following the same
  * convention used by the UART plugin:
  *   LINE            → UntilDelimiter  (delimiter = '\\n')
  *   TOKEN_STRING /
  *   TOKEN_HEXSTREAM → UntilToken      (token = expected payload)
  *   default         → Exact
  *
  * For I2CBridge the slave address is passed through ReadOptions::delimiter
  * (base-interface convention documented in uDigisparkI2C.hpp).
*/
/*--------------------------------------------------------------------------------------------------------*/

bool DSPKi2cPlugin::m_Receive( std::span<uint8_t> dataSpan, size_t& szSize, CommCommandReadType readType, std::shared_ptr<const ICommDriver> shpDriver ) const
{
    bool bRetVal = false;
    ICommDriver::ReadOptions options;

    switch(readType)
    {
        case CommCommandReadType::LINE:
            options.mode      = ICommDriver::ReadMode::UntilDelimiter;
            options.delimiter = m_u8SlaveAddr;  // slave addr carried in delimiter field
            break;

        case CommCommandReadType::TOKEN_STRING:
            [[fallthrough]];
        case CommCommandReadType::TOKEN_HEXSTREAM:
            options.mode       = ICommDriver::ReadMode::UntilToken;
            options.token      = dataSpan;
            options.use_buffer = true;
            options.delimiter  = m_u8SlaveAddr;
            break;

        default:
            options.mode      = ICommDriver::ReadMode::Exact;
            options.delimiter = m_u8SlaveAddr;
            break;
    }

    auto result = shpDriver->tout_read(m_u32ReadTimeout, dataSpan, options);

    if (result.status == ICommDriver::Status::SUCCESS) {
        szSize   = result.bytes_read;
        bRetVal  = true;
    } else {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Read failed:");
                  LOG_STRING(ICommDriver::to_string(result.status));
                  LOG_STRING("Bytes read:"); LOG_SIZET(result.bytes_read));
        szSize  = result.bytes_read;
        bRetVal = false;
    }

    return bRetVal;
}
