#include "ushell_core.h"
#include "ushell_core_keys.h"
#include "ushell_user_logger.h"

// used from script components
#include "uPluginLoader.hpp"
#include "uSharedConfig.hpp" // get paths to plugins
#include "IScriptInterpreterShell.hpp"
#include "uScriptDataTypes.hpp"
#include "uString.hpp"

#if (1 == uSHELL_SUPPORTS_MULTIPLE_INSTANCES)
#include <cstring>
#include <memory>
#include <utility>
#include <filesystem>

#if defined(_MSC_VER)
    #include <dirent_vs.h>
#else
    #include <unistd.h>
    #include <dirent.h>
#endif
#endif /*(1 == uSHELL_SUPPORTS_MULTIPLE_INSTANCES)*/

// ---------------------------------------------------------------------------
// Returns the directory that contains the running executable.
// Used to resolve plugin sub-folders (splugins/, iplugins/) independently
// of the process working directory, which is set to the script's location.
// ---------------------------------------------------------------------------
static std::filesystem::path executableDir()
{
#if defined(_WIN32)
    wchar_t buf[MAX_PATH];
    GetModuleFileNameW(nullptr, buf, MAX_PATH);
    return std::filesystem::path(buf).parent_path();
#else
    return std::filesystem::read_symlink("/proc/self/exe").parent_path();
#endif
}

///////////////////////////////////////////////////////////////////
//            INTERNAL INTERFACES                                //
///////////////////////////////////////////////////////////////////

static int privListPlugins          (const char *pstrCaption, const char *pstrPath, const char *pstrExtension);
static int privListScriptItems      (void);
static int privListScriptCommands   (void);
static int privLoadScriptPlugin     (const char *pstrPluginName);
static int privExecScriptCommand    (const char *pstrCommand);
static std::string adaptInputLine   (const std::string& line);


///////////////////////////////////////////////////////////////////
//            EXPORTED VARIABLES DECLARATION                     //
///////////////////////////////////////////////////////////////////


#if (1 == uSHELL_SUPPORTS_EXTERNAL_USER_DATA)
extern void *pvLocalUserData;
#endif /* (1 == uSHELL_SUPPORTS_EXTERNAL_USER_DATA) */


///////////////////////////////////////////////////////////////////
//            USER COMMANDS IMPLEMENTATION                       //
///////////////////////////////////////////////////////////////////



#if (1 == uSHELL_SUPPORTS_MULTIPLE_INSTANCES)
/*------------------------------------------------------------
 * list all the available plugins
------------------------------------------------------------*/
int list(void)
{

#if (1 == uSHELL_SUPPORTS_MULTIPLE_INSTANCES)
    privListPlugins("shell", SHELL_PLUGINS_PATH, SHELL_PLUGIN_EXTENSION);
#endif /* (1 == uSHELL_SUPPORTS_MULTIPLE_INSTANCES) */
    privListPlugins("script", SCRIPT_PLUGINS_PATH, SCRIPT_PLUGIN_EXTENSION);
    return 0;

} /* list() */


/*------------------------------------------------------------
 * load the plugin
------------------------------------------------------------*/
int pload(char *pstrPluginName)
{
    int iRetVal = 0; // success
    const std::string pluginsPath = (executableDir() / SHELL_PLUGINS_PATH).string();
    PluginLoaderFunctor<uShellInst_s> loader(PluginPathGenerator(pluginsPath, PLUGIN_PREFIX, SHELL_PLUGIN_EXTENSION),
                                             PluginEntryPointResolver(SHELL_PLUGIN_ENTRY_POINT_NAME, SHELL_PLUGIN_EXIT_POINT_NAME));

    auto [handle, error] = loader(pstrPluginName);
    if (!handle.first || !handle.second) {
        uSHELL_LOG(ULOG_ERROR, "Failed to load plugin: %s", error.value().message);
        iRetVal = 0xFF;
    } else {
        uSHELL_LOG(ULOG_INFO, "Plugin loaded successfully!");

        auto typedPtr = std::static_pointer_cast<uShellInst_s>(handle.second);
        uShellInst_s* rawPtr = typedPtr.get();

        /* continue execution with the valid shell instance */
        std::shared_ptr<Microshell> pShellPtr = Microshell::getShellSharedPtr(rawPtr, pstrPluginName);

        /* this call is blocking until the shell is released with #q */
        if (nullptr != pShellPtr) {
            pShellPtr->Run();
        }
    }
    return iRetVal;

} /* pload() */

#endif /* (1 == uSHELL_SUPPORTS_MULTIPLE_INSTANCES) */


///////////////////////////////////////////////////////////////////
//               USER SHORTCUTS HANDLERS                         //
///////////////////////////////////////////////////////////////////


#if (1 == uSHELL_IMPLEMENTS_USER_SHORTCUTS)

void uShellUserHandleShortcut_Dot( const char *pstrArgs )
{
    char *pstrArg = (char*)pstrArgs;

    do {

        // case: [..args] => load a plugin
        if( '.' == *pstrArg )
        {
            ++pstrArg;
            // skip the spaces
            while((uSHELL_KEY_SPACE == *pstrArg) && ('\0' != *pstrArg)) { ++pstrArg; }
            if( '\0' == *pstrArg )
            {
                uSHELL_PRINTF("[..] plugin name not provided!\n");
            }
            else
            {
                uSHELL_PRINTF("[..] loading plugin [%s]\n", pstrArg);
                privLoadScriptPlugin( pstrArg );
            }
            break;
        }

        // case: [.l] => list the script macros and plugins
        if( ('l' == *pstrArg) && ('\0' == *(pstrArg + 1)) )
        {
            uSHELL_PRINTF("[.l] list script items\n");
            privListScriptItems();
            break;
        }

        // case: [.l] => list the script commands
        if( ('c' == *pstrArg) && ('\0' == *(pstrArg + 1)) )
        {
            uSHELL_PRINTF("[.c] list script commands\n");
            privListScriptCommands();
            break;
        }

        // case: [.h] => show the help
        if( ('h' == *pstrArg) && ('\0' == *(pstrArg + 1)) )
        {
            uSHELL_PRINTF("\t[.h] help\n");
            uSHELL_PRINTF("\t[.l] list script macros and plugins\n");
            uSHELL_PRINTF("\t[.c] list script commands\n");
            uSHELL_PRINTF("\t[.arg] execute the command provided as argument\n");
            uSHELL_PRINTF("\t[..arg] load the plugin provided as argument \n");
            break;
        }

        //default [.args] declare a macro or execute a command
        privExecScriptCommand(adaptInputLine(pstrArg).c_str());

    } while(false);

} /* uShellUserHandleShortcut_Dot() */


/******************************************************************************/
void uShellUserHandleShortcut_Slash( const char *pstrArgs )
{
    uSHELL_LOG(ULOG_WARNING, "[/] registered but not implemented | args[%s] ", pstrArgs);

} /* uShellUserHandleShortcut_Slash() */

#endif /*(1 == uSHELL_IMPLEMENTS_USER_SHORTCUTS)*/


///////////////////////////////////////////////////////////////////
//               PRIVATE IMPLEMENTATION                          //
///////////////////////////////////////////////////////////////////

/*------------------------------------------------------------
 * list the available plugins
------------------------------------------------------------*/
#if (1 == uSHELL_SUPPORTS_MULTIPLE_INSTANCES)
static int privListPlugins (const char *pstrCaption, const char *pstrPath, const char *pstrExtension)
{
    #define MAX_WORKBUFFER_SIZE    128U
    char vstrPluginPathName[MAX_WORKBUFFER_SIZE] = {0};
    struct dirent *entry = nullptr;

    // Resolve the relative plugin folder against the executable's directory so
    // that opendir() works regardless of the process CWD (which is set to the
    // script's directory by the Qt front-end).
    const std::string absPath = (executableDir() / pstrPath).string();
    DIR *dir = opendir(absPath.c_str());

    uSHELL_LOG(ULOG_INFO, "--- %s plugins ---", pstrCaption);

    if (nullptr == dir) 
    {
        uSHELL_LOG(ULOG_ERROR, "Failed to open the plugins folder [%s]", pstrPath);
        return 1;
    }

    while ((entry = readdir(dir)) != nullptr) 
    {
        if (strstr(entry->d_name, pstrExtension) != nullptr) {
            size_t name_len = strlen(entry->d_name);
            size_t ext_len = strlen(pstrExtension);

            // Ensure safe modification of string
            if (name_len > ext_len) {
                entry->d_name[name_len - ext_len] = '\0';
            }

            int written = snprintf(vstrPluginPathName, MAX_WORKBUFFER_SIZE, "%20s%s | %s", entry->d_name, pstrExtension, entry->d_name + strlen(PLUGIN_PREFIX));
            if (written >= MAX_WORKBUFFER_SIZE) {
                uSHELL_LOG(ULOG_WARNING, "Plugin name truncated: [%s]", vstrPluginPathName);
            }

            uSHELL_LOG(ULOG_INFO, "%s", vstrPluginPathName);
        }
    }

    closedir(dir);

    return 0;

} /* privListPlugins() */
#endif /* (1 == uSHELL_SUPPORTS_MULTIPLE_INSTANCES) */


/*------------------------------------------------------------
 * list the script items
------------------------------------------------------------*/
static int privListScriptItems (void)
{
    if( nullptr != pvLocalUserData ) {
        IScriptInterpreterShell<ScriptEntriesType> *pScript = reinterpret_cast<IScriptInterpreterShell<ScriptEntriesType>*>(pvLocalUserData);
        pScript->listMacrosPlugins();
    }

    return 0;

} /* privListScriptItems() */



/*------------------------------------------------------------
 * list the script commands
------------------------------------------------------------*/
static int privListScriptCommands (void)
{
    if( nullptr != pvLocalUserData ) {
        IScriptInterpreterShell<ScriptEntriesType> *pScript = reinterpret_cast<IScriptInterpreterShell<ScriptEntriesType>*>(pvLocalUserData);
        pScript->listCommands();
    }

    return 0;

} /* privListScriptCommands() */



/*------------------------------------------------------------
 * load the script plugin provided by name
------------------------------------------------------------*/
int privLoadScriptPlugin (const char* pstrPluginName)
{
    if( nullptr != pvLocalUserData ) {
        IScriptInterpreterShell<ScriptEntriesType> *pScript = reinterpret_cast<IScriptInterpreterShell<ScriptEntriesType>*>(pvLocalUserData);
        pScript->loadPlugin(pstrPluginName, true);
    }

    return 0;

} /* privLoadScriptPlugin() */


/*------------------------------------------------------------
 * execute a script command
------------------------------------------------------------*/
static int privExecScriptCommand (const char *pstrCommand)
{
    uSHELL_PRINTF("[.] executing [%s]\n", pstrCommand);
    if( nullptr != pvLocalUserData ) {
        IScriptInterpreterShell<ScriptEntriesType> *pScript = reinterpret_cast<IScriptInterpreterShell<ScriptEntriesType>*>(pvLocalUserData);
        pScript->executeCmd(pstrCommand);
    }

    return 0;

} /* privExecScriptCommand() */


/*------------------------------------------------------------
 * adapt the input to match the script expected format (upprecases in some cases)
------------------------------------------------------------*/
std::string adaptInputLine(const std::string& line) 
{
    // Normalize: ensure spaces around := and ?= so tokenizer sees them as separate tokens
    std::string normalized = ustring::replace_all(line, "?=", " ?= ");
    ustring::replace_all_inplace(normalized, ":=", " := ");

    auto tokens = ustring::tokenize(normalized);     // split on whitespace
    if (tokens.empty()) return line;

    auto upperDot = [](std::string& tok) {
        auto [lhs, rhs] = ustring::splitAtFirst(tok, '.');
        if (!rhs.empty()) {
            ustring::touppercase(lhs);
            ustring::touppercase(rhs);
            tok = lhs + '.' + rhs;
        }
    };
    auto isKeyword = [](const std::string& s) {
        const auto u = ustring::touppercase(s);
        return u == "PRINT" || u == "FORMAT" || u == "MATH";
    };

    if (tokens.size() > 1 && tokens[1] == "?=") {   
        if (tokens.size() > 2) {
            if (ustring::containsChar(tokens[2], '.'))
                upperDot(tokens[2]);
            else if (isKeyword(tokens[2]))
                ustring::touppercase(tokens[2]);
        }
    } else if (tokens.size() > 1 && tokens[1] == ":=") {
        // don't change anything
    } else {                                         
        if (ustring::containsChar(tokens[0], '.'))
            upperDot(tokens[0]);
        else
            ustring::touppercase(tokens[0]);
    }
    return ustring::joinStrings(tokens, ' ');
    
} /* adaptInputLine() */
