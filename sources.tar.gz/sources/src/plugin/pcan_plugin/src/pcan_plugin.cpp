#include "ICommDriver.hpp"
#include "PluginExport.hpp"
#include "pcan_plugin.hpp"
#include "pcan_setup.hpp"
#include "uCommScriptClient.hpp"
#include "uCommScriptCommandInterpreter.hpp"
#include "uCommandExec.hpp"
#include "uFile.hpp"
#include "uHexlify.hpp"
#include "uLogger.hpp"
#include "uNumeric.hpp"
#include "uPcan.hpp"
#include "uPluginSettings.hpp"
#include "uSharedConfig.hpp"
#include "uString.hpp"

#include <stdint.h>
#include <memory>
#include <span>
#include <stop_token>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

/////////////////////////////////////////////////////////////////////////////////
//                  PLUGIN ENTRY POINTS                                        //
/////////////////////////////////////////////////////////////////////////////////

extern "C"
{
    EXPORTED PCANPlugin* pluginEntry()
    {
        return new PCANPlugin();
    }

    EXPORTED void pluginExit( PCANPlugin *ptrPlugin)
    {
        if (nullptr != ptrPlugin)
        {
            delete ptrPlugin;
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////
//                 PLUGIN TOP LEVEL COMMANDS                                   //
/////////////////////////////////////////////////////////////////////////////////

/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief INFO command implementation; shows details about the plugin and
  *        describes the supported functions with examples of usage.
  *        This command takes no arguments and is executed even if plugin initialization fails.
  *
  * \note Usage example:
  *       PCAN.INFO
  *
  * \param[in] args  empty string (no arguments expected)
  *
  * \return true on success, false otherwise
*/
/*--------------------------------------------------------------------------------------------------------*/

bool PCANPlugin::m_PCAN_INFO (const std::string &args, std::stop_token st) const
{
    // expected no arguments
    if (!args.empty())
    {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Expected no argument(s)"));
        return false;
    }

    // if plugin is not enabled stop execution here and return true as the argument(s) validation passed
    if (!m_bIsEnabled)
    {
        return true;
    }

    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING(PCAN_PLUGIN_NAME); LOG_STRING("Vers:"); LOG_STRING(m_strVersion));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Build:"); LOG_STRING(__DATE__); LOG_STRING(__TIME__));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Description: communicate via PEAK-System PCAN-Basic (USB/PCI/PCIe adapters)"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CONFIG : set the PCAN channel, bitrate and transfer parameters"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Args   : [i=channel] [b=bitrate] [x=tx_id] [y=rx_id] [r=read_tout] [w=write_tout]"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         [s=recv_bufsize] [e=extended] [f=fd] [t=tp_protocol]"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Usage  : PCAN.CONFIG i=0x51 b=500000 x=0x7FF r=2000 w=2000 s=8"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         PCAN.CONFIG i=0x51 b=500000 x=0x18DAF100 e=0 f=0"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         PCAN.CONFIG x=0x7E0 y=0x7E8 t=isotp"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("  i  - PCAN channel handle (decimal or 0x-hex): 0x51=PCAN_USBBUS1,"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("       0x52=PCAN_USBBUS2, 0x41=PCAN_ISABUS1, 0x81=PCAN_PCIBUS1, …"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("  b  - CAN bitrate in bps: 1000000, 800000, 500000, 250000, 125000,"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("       100000, 95000, 83000, 50000, 47000, 33000, 20000, 10000, 5000"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("  x  - TX CAN ID (decimal or 0x-hex); EFF flag auto-set when ID > 0x7FF"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("  y  - RX CAN ID for peer responses/handshake frames; only used once"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("       t=tp_protocol != none. Defaults to mirroring x=tx_id."));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("  r  - read timeout in ms (default 1000)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("  w  - write timeout in ms (default 1000)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("  s  - read buffer size in bytes, 1-64 (default 8 for classic CAN)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("  e  - force extended (29-bit) frame format: 0=auto, 1=force EFF"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("  f  - CAN FD mode: 0=classic CAN (default), 1=CAN FD"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("  t  - transport protocol for payloads over one frame: none (default,"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("       naive fragmentation) | isotp (ISO 15765-2) | j1939 (SAE J1939-21)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note   : x=tx_id also becomes the default RX filter id (replaces the"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         whole filter list with one entry matching tx_id)"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("FILTER : install a software acceptance filter (checked per received frame)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Args   : <id:mask>[,<id:mask>…]  (empty string clears the filter)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Usage  : PCAN.FILTER 0x100:0x7FF"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         PCAN.FILTER 0x100:0x7FF,0x18DAF100:0x1FFFFFFF"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         PCAN.FILTER"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note   : only the FIRST id:mask entry is actually enforced today — the"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         driver tracks one active RX filter id, unlike KVCAN's full list"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note   : overrides the RX default derived from CONFIG's x=tx_id"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("SCRIPT : send commands from a script file"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Args   : scriptpathname [delay_ms]"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Usage  : PCAN.SCRIPT obd_sequence.txt"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         PCAN.SCRIPT uds_session.txt 10"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CMD    : send, receive or both"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Args   : direction message"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Usage  : PCAN.CMD > H\"AABBCCDD\" | H\"06\""));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         PCAN.CMD < \"Ready\" | \"Go!\""));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note   : payload over 8/64 bytes is fragmented across frames; select"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         t=tp_protocol (see CONFIG) for a real segmented transport"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CYCLIC : send one or more periodic messages"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Args   : time1 val1 [id1], time2 val2 [id2], ... (time_i in ms, val_i hex)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Usage  : PCAN.CYCLIC 100 AABBCCDD 0x100, 250 1122 0x200"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         PCAN.CYCLIC 100 AABBCCDD 0x100, 250 1122 0x200 &"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note   : id is optional; when omitted, falls back to the default TX id"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note   : without '&' sends one full pattern (lcm of the time_i) then returns;"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("         with '&' repeats forever until the script/thread is stopped"));
    LOG_SEP();
    LOG_PRINT(LOG_EMPTY, LOG_STRING("INI file parameters (copy/paste into your ini file):"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("[PCAN]"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("ARTEFACTS_PATH           =               # directory used by SCRIPT/CMD/wrrdf for reading/writing artefact files"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("PCAN_CHANNEL             = PCAN_USBBUS1  # PEAK-System PCAN channel identifier"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("PCAN_BITRATE             = 500000        # classic CAN arbitration bitrate in bit/s"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("PCAN_EXTENDED            = false         # use 29-bit extended CAN identifiers when true"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("PCAN_FD                  = false         # enable CAN FD when true"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CAN_TX_ID                =               # CAN arbitration ID used by CMD/SCRIPT/CYCLIC when sending"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CAN_RX_ID                =               # CAN arbitration ID to filter on when receiving (empty = accept all)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CAN_FILTERS              =               # comma-separated list of hardware CAN ID/mask filter entries"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CAN_TP_PROTOCOL          = none          # transport protocol layered on top of raw CAN frames (none/isotp/j1939/canopen/fastpacket)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_BLOCK_SIZE            =               # ISO-TP: block size (BS) sent in our Flow Control frames (0 = no limit)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_ST_MIN                =               # ISO-TP: separation time (STmin) sent in our Flow Control frames, raw encoded byte"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_PAD_FRAMES            =               # ISO-TP: pad SF/CF/FC to 8 bytes (classic CAN convention) when true"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_PADDING_BYTE          =               # ISO-TP: padding fill byte"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_TIMEOUT_NBS           =               # ISO-TP: N_Bs - max wait in ms for Flow Control after our First Frame"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_TIMEOUT_NCR           =               # ISO-TP: N_Cr - max wait in ms for the next Consecutive Frame from the peer"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_MAX_MSG_LEN           =               # ISO-TP: classic 12-bit length field limit"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("J1939_USE_BAM            =               # J1939-21: true = broadcast (BAM), false = peer-to-peer (RTS/CTS)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("J1939_MAX_PACKETS        =               # J1939-21: max packets granted per CTS (RTS/CTS only)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_TIMEOUT_T1            =               # J1939-21: T1 - max wait in ms for CTS after RTS"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_TIMEOUT_T2            =               # J1939-21: T2 - max wait in ms for a data packet after CTS"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_TIMEOUT_T3            =               # J1939-21: T3 - max wait in ms for the next CTS after a burst"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_TIMEOUT_TH            =               # J1939-21: Th (BAM) - max inter-packet gap in ms on the receive side"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("J1939_MAX_MSG_LEN        =               # J1939-21: message size limit"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CANOPEN_INDEX            =               # CANopen SDO: Object Dictionary index of the entry being transferred"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CANOPEN_SUBINDEX         =               # CANopen SDO: Object Dictionary sub-index"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CANOPEN_USE_BLOCK        =               # CANopen SDO: true = block transfer, false = segmented transfer"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CANOPEN_BLOCK_SIZE       =               # CANopen SDO: block transfer segments per block, 1-127"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_TIMEOUT_SDO           =               # CANopen SDO: response timeout in ms"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CANOPEN_MAX_MSG_LEN      =               # CANopen SDO: message size limit"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("TP_TIMEOUT_FP_INTERFRAME =               # Fast Packet: max inter-frame gap in ms"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("FP_MAX_MSG_LEN           =               # Fast Packet: message size limit"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("READ_TIMEOUT             = 2000          # read timeout in ms"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("WRITE_TIMEOUT            = 2000          # write timeout in ms"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("READ_BUF_SIZE            = 1024          # size in bytes of the local read buffer"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("RAW_RESULT               = false         # CMD returns raw bytes instead of a hexlified string when true"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("CYCLIC_CACHED            = true          # true=validate/parse each CYCLIC entry once per session; false=re-resolve every tick (needed for volatile ?= macros)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("(TP_*/J1939_*/CANOPEN_*/FP_* left blank above = keep the transport-protocol"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING(" library's own built-in default; they only apply once CAN_TP_PROTOCOL selects"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING(" a segmented protocol)"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("Note: the CONFIG command above can override a subset of these at runtime;"));
    LOG_PRINT(LOG_EMPTY, LOG_STRING("      any key not accepted by CONFIG must be set via the ini file."));


    return true;
}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief CONFIG command implementation; overwrite the current PCAN parameters at runtime.
  *
  * \note Any subset of parameters can be specified; omitted keys retain their current values.
  *       The channel is not reopened by CONFIG — changes take effect on the next CMD or SCRIPT call.
  *
  * \note Usage example:
  *       PCAN.CONFIG i=0x51 b=500000 x=0x7FF r=2000 w=2000 s=8
  *       PCAN.CONFIG i=0x51 b=500000 x=0x18DAF100
  *
  * \param[in] args  [i=channel] [b=bitrate] [x=tx_id] [r=read_tout] [w=write_tout]
  *                  [s=recv_bufsize] [e=extended] [f=fd]
  *
  * \return true if parameters were updated successfully, false otherwise
*/
/*--------------------------------------------------------------------------------------------------------*/

bool PCANPlugin::m_PCAN_CONFIG (const std::string &args, std::stop_token st) const
{
    return generic_can_set_params<PCANPlugin>(this, args);
}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief FILTER command implementation; install software acceptance filters.
  *
  * \note Filters are stored in m_vFilters and applied inside the driver's receive loop
  *       on every CMD or SCRIPT call. Calling FILTER with an empty argument clears all
  *       filters (accept everything).  Syntax is identical to KVCAN.FILTER.
  *
  * \note Usage example:
  *       PCAN.FILTER 0x100:0x7FF
  *       PCAN.FILTER 0x100:0x7FF,0x18DAF100:0x1FFFFFFF
  *       PCAN.FILTER
  *
  * \param[in] args  comma-separated list of <id>:<mask> pairs, or empty to clear
  *
  * \return true on success, false on parse error
*/
/*--------------------------------------------------------------------------------------------------------*/

bool PCANPlugin::m_PCAN_FILTER (const std::string &args, std::stop_token st) const
{
    // if plugin is not enabled stop execution here and return true as the argument(s) validation passed
    if (!m_bIsEnabled)
    {
        return true;
    }

    std::vector<std::pair<uint32_t,uint32_t>> vFilters;

    if (!args.empty())
    {
        if (false == m_ParseFilters(args, vFilters))
        {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("FILTER: invalid filter string:"); LOG_STRING(args));
            return false;
        }
    }

    m_vFilters = std::move(vFilters);

    LOG_PRINT(LOG_VERBOSE, LOG_HDR;
              LOG_STRING("Filters set, count:"); LOG_UINT32(static_cast<uint32_t>(m_vFilters.size())));

    return true;
}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief CMD command implementation; execute a single send/receive operation over PCAN.
  *
  * \note The PCAN channel is opened for the duration of the call and closed automatically on return (RAII).
  *       Software acceptance filters stored in m_vFilters are passed as an RX filter hint
  *       (first filter entry's id as xtra_params) to the driver's tout_read.
  *
  * \note Usage example:
  *       PCAN.CMD > H\"AABBCCDD\" | H\"06\"
  *       PCAN.CMD < \"Ready\" | \"Go!\"
  *
  * \param[in] args  direction and data expression (see CommScriptCommandValidator grammar)
  *
  * \return true on success, false otherwise
*/
/*--------------------------------------------------------------------------------------------------------*/

bool PCANPlugin::m_PCAN_CMD (const std::string &args, std::stop_token st) const
{
    return ucmdexec::generic_cmd(
        args, m_bIsEnabled,
        [this]() -> std::shared_ptr<PCAN> {
            auto shpDriver = m_OpenAndConfigure();
            return (shpDriver && shpDriver->is_open()) ? shpDriver : nullptr;
        },
        m_strInstanceName,
        m_u32ReadBufferSize, m_u32ReadTimeout, LT_HDR, &m_strResultData, m_bRawResult,
        // Trivial pass-throughs — PCAN::tout_write()/tout_read() already
        // dump every physical frame themselves (see PCAN::dumpFrame(), which
        // covers both the naive-fragmentation path and a segmented transport
        // protocol's SF/FF/CF/FC frames). Installing *any* non-empty pfsend/
        // pfrecv here only exists to make the interpreter skip its own
        // generic dump of the pre-fragmentation logical payload, which would
        // otherwise duplicate/misrepresent what PCAN::dumpFrame() already
        // reports accurately — see uCommScriptCommandInterpreter.hpp.
        [](uint32_t t, std::span<const uint8_t> d, std::shared_ptr<const PCAN> drv, std::string_view x, std::stop_token tok) {
            return drv->tout_write(t, d, x, tok);
        },
        [](uint32_t t, std::span<uint8_t> b, const ICommDriver::ReadOptions& o, std::shared_ptr<const PCAN> drv, std::string_view x, std::stop_token tok) {
            return drv->tout_read(t, b, o, x, tok);
        }, st);
}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief SCRIPT command implementation; execute a multi-command script file over PCAN.
  *
  * \note The PCAN channel is opened once for the lifetime of the script and closed on return.
  *
  * \note Usage example:
  *       PCAN.SCRIPT obd_sequence.txt
  *       PCAN.SCRIPT uds_session.txt 10
  *
  * \param[in] args  filename [delay_ms]
  *
  * \return true on success, false otherwise
*/
/*--------------------------------------------------------------------------------------------------------*/

bool PCANPlugin::m_PCAN_SCRIPT (const std::string &args, std::stop_token st) const
{
    return ucmdexec::generic_script(
        args, m_bIsEnabled,
        [this]() -> std::shared_ptr<PCAN> {
            auto shpDriver = m_OpenAndConfigure();
            return (shpDriver && shpDriver->is_open()) ? shpDriver : nullptr;
        },
        m_strInstanceName,
        m_strArtefactsPath, m_u32ReadBufferSize, m_u32ReadTimeout, LT_HDR,
        // Same rationale as m_PCAN_CMD() above.
        [](uint32_t t, std::span<const uint8_t> d, std::shared_ptr<const PCAN> drv, std::string_view x, std::stop_token tok) {
            return drv->tout_write(t, d, x, tok);
        },
        [](uint32_t t, std::span<uint8_t> b, const ICommDriver::ReadOptions& o, std::shared_ptr<const PCAN> drv, std::string_view x, std::stop_token tok) {
            return drv->tout_read(t, b, o, x, tok);
        }, st);
}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief CYCLIC command implementation; send one or more periodic PCAN messages.
  *
  * \note The PCAN channel is opened once for the whole CYCLIC session (like SCRIPT) and closed
  *       automatically on return (RAII). Each entry's optional "id" is the PCAN CAN id (decimal
  *       or 0x-hex, same syntax PCAN::tout_write()'s xtra_params already accepts — an empty id
  *       falls back to the default TX id) and "val" is the payload as a plain hex string
  *       (e.g. "AABBCCDD"), <= 8 bytes classic CAN / <= 64 bytes CAN FD.
  *
  * \note This bypasses TP-segmented transport on purpose — same rationale as KVCAN's CYCLIC: a
  *       cyclic message is by definition a single, self-contained frame per tick.
  *
  * \note Usage example:
  *       PCAN.CYCLIC 100 AABBCCDD 0x100, 250 1122 0x200
  *       PCAN.CYCLIC 100 AABBCCDD 0x100, 250 1122 0x200 &
  *
  * \param[in] args  "time1 val1 , time2 val2 , ..." (see generic_send_cyclic())
  * \param[in] st    stop_token; forwarded as-is (present/absent '&' selects run-once vs. forever)
  *
  * \return true on success, false otherwise
*/
/*--------------------------------------------------------------------------------------------------------*/

bool PCANPlugin::m_PCAN_CYCLIC (const std::string &args, std::stop_token st) const
{
    return ucmdexec::generic_send_cyclic(
        args, m_bIsEnabled,
        [this]() -> std::shared_ptr<PCAN> {
            auto shpDriver = m_OpenAndConfigure();
            return (shpDriver && shpDriver->is_open()) ? shpDriver : nullptr;
        },
        m_strInstanceName, m_u32ReadBufferSize, m_u32ReadTimeout, LT_HDR, st, m_bCyclicCached);
}

/////////////////////////////////////////////////////////////////////////////////
//            PRIVATE INTERFACES IMPLEMENTATION                                //
/////////////////////////////////////////////////////////////////////////////////

/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief Parse a comma-separated "<id>:<mask>" filter string into a vector of (can_id, can_mask) pairs.
  *        Both id and mask fields accept decimal or 0x-prefixed hex values.
  *        Example: "0x100:0x7FF,0x18DAF100:0x1FFFFFFF"
  *
  *        CAN_EFF_FLAG auto-correction mirrors the KVCAN plugin's m_ParseFilters exactly.
*/
/*--------------------------------------------------------------------------------------------------------*/

bool PCANPlugin::m_ParseFilters(const std::string& strFilters,
                                std::vector<std::pair<uint32_t,uint32_t>>& vFilters) const
{
    vFilters.clear();

    // SocketCAN-compatible frame-ID flag bits (mirrors linux/can.h)
    static constexpr uint32_t CAN_EFF_FLAG = 0x80000000U;
    static constexpr uint32_t CAN_RTR_FLAG = 0x40000000U;
    static constexpr uint32_t CAN_ERR_FLAG = 0x20000000U;
    static constexpr uint32_t CAN_SFF_MASK = 0x000007FFU;
    static constexpr uint32_t CAN_EFF_MASK = 0x1FFFFFFFU;

    // Split on commas to get individual "<id>:<mask>" tokens
    std::vector<std::string> vstrEntries;
    ustring::tokenize(strFilters, ',', vstrEntries);

    for (const auto& strEntry : vstrEntries)
    {
        // Split each entry on ':' to separate id from mask
        std::vector<std::string> vstrParts;
        ustring::tokenize(strEntry, ':', vstrParts);

        if (vstrParts.size() != 2) {
            LOG_PRINT(LOG_ERROR, LOG_HDR;
                      LOG_STRING("Filter entry malformed (expected id:mask):"); LOG_STRING(strEntry));
            return false;
        }

        uint32_t can_id   = 0U;
        uint32_t can_mask = 0U;

        if (false == numeric::str2uint32(ustring::trim(vstrParts[0]), can_id)) {
            LOG_PRINT(LOG_ERROR, LOG_HDR;
                      LOG_STRING("Filter id parse failed:"); LOG_STRING(vstrParts[0]));
            return false;
        }

        if (false == numeric::str2uint32(ustring::trim(vstrParts[1]), can_mask)) {
            LOG_PRINT(LOG_ERROR, LOG_HDR;
                      LOG_STRING("Filter mask parse failed:"); LOG_STRING(vstrParts[1]));
            return false;
        }

        // ── EFF / SFF flag fixup (mirrors KVCAN plugin m_ParseFilters) ──────────
        const uint32_t flagsInId = can_id & (CAN_EFF_FLAG | CAN_RTR_FLAG | CAN_ERR_FLAG);
        can_mask |= flagsInId;

        if (can_id & CAN_EFF_FLAG) {
            can_id   &= (CAN_EFF_FLAG | CAN_RTR_FLAG | CAN_EFF_MASK);
            can_mask &= (CAN_EFF_FLAG | CAN_RTR_FLAG | CAN_ERR_FLAG | CAN_EFF_MASK);
        } else {
            if ((can_id & CAN_EFF_MASK) > CAN_SFF_MASK) {
                LOG_PRINT(LOG_WARNING, LOG_HDR;
                          LOG_STRING("Filter id > 0x7FF without CAN_EFF_FLAG — setting EFF flag automatically:"); LOG_STRING(strEntry));
                can_id   |= CAN_EFF_FLAG;
                can_mask |= CAN_EFF_FLAG;
                can_id   &= (CAN_EFF_FLAG | CAN_RTR_FLAG | CAN_EFF_MASK);
                can_mask &= (CAN_EFF_FLAG | CAN_RTR_FLAG | CAN_ERR_FLAG | CAN_EFF_MASK);
            } else {
                can_id   &= (CAN_RTR_FLAG | CAN_SFF_MASK);
                can_mask &= (CAN_EFF_FLAG | CAN_RTR_FLAG | CAN_ERR_FLAG | CAN_SFF_MASK);
            }
        }

        vFilters.emplace_back(can_id, can_mask);
    }

    return true;
}


/*--------------------------------------------------------------------------------------------------------*/
/**
  * \brief Open the PCAN channel with the current configuration and return a shared_ptr to
  *        the PCAN driver.
  *
  * \note If m_vFilters is non-empty, only its FIRST entry's id is forwarded to the driver
  *       (PCAN::setDefaultRxFilterId()) — see the note on m_ParseFilters(). This is a
  *       software-only comparison done per received frame inside PCAN::frameMatchesFilter();
  *       PCAN-Basic itself is not asked to filter anything at the hardware/driver level.
  *       setCanTxId() keeps this in sync automatically: every CONFIG "x=" (or CAN_TX_ID ini
  *       entry) replaces m_vFilters with one entry matching the new TX id, mirroring KVCAN's
  *       "RX default == TX default" behaviour.
  *
  *        Returns nullptr if the channel could not be opened (already logged by the driver).
*/
/*--------------------------------------------------------------------------------------------------------*/

std::shared_ptr<PCAN> PCANPlugin::m_OpenAndConfigure (void) const
{
    auto shpDriver = std::make_shared<PCAN>(
        m_strPcanChannel,
        m_u32Bitrate,
        m_u32CanTxId,
        m_bExtended,
        m_bFd,
        m_strPcanChannel,
        m_strInstanceName
    );

    if (!shpDriver->is_open()) {
        LOG_PRINT(LOG_ERROR, LOG_HDR;
                  LOG_STRING("Failed to open PCAN channel:"); LOG_STRING(m_strPcanChannel.c_str());
                  LOG_STRING("bitrate:"); LOG_UINT32(m_u32Bitrate));
        return nullptr;
    }

    // Transport-protocol selection is orthogonal to the channel/filter setup
    // above — push it regardless, so it's already in place for the driver's
    // tout_write()/tout_read() calls.
    shpDriver->setTpProtocol(m_eTpProtocol);
    shpDriver->setTpConfig(m_sTpConfig);
    if (true == m_bCanRxIdSet) {
        shpDriver->setTpRxId(m_u32CanRxId);
    }

    // Forward the first filter entry's id as the driver's single active RX
    // filter (software comparison only — see PCAN::frameMatchesFilter()).
    // setCanTxId() ensures this is normally the same id as the default TX id;
    // an explicit FILTER command can replace it with a different one.
    if (!m_vFilters.empty()) {
        shpDriver->setDefaultRxFilterId(m_vFilters.front().first);
    }

    LOG_PRINT(LOG_DEBUG, LOG_HDR;
              LOG_STRING("PCAN channel ready:"); LOG_STRING(m_strPcanChannel.c_str());
              LOG_STRING("TX ID:"); LOG_HEX32(m_u32CanTxId));

    return shpDriver;
}
