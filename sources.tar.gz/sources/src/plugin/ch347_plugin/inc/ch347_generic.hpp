#ifndef CH374_GENERIC_HPP
#define CH374_GENERIC_HPP
#include "ICommDriver.hpp"
#include "uCommScriptClient.hpp"
#include "uLogger.hpp"
#include "uString.hpp"
#include "uHexlify.hpp"
#include "uNumeric.hpp"
#include "uFile.hpp"

#include <stop_token>
#include <vector>
#include <map>
#include <span>
#include <functional>
#include <string>
#include <cstdint>
#include <fstream>

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
    #undef LT_HDR
#endif
#ifdef LOG_HDR
    #undef LOG_HDR
#endif

#define LT_HDR     "CH347_GEN   |"
#define LOG_HDR    LOG_STRING(LT_HDR)

///////////////////////////////////////////////////////////////////
//              LOCAL DEFINES AND DATA TYPES                     //
///////////////////////////////////////////////////////////////////

#define CH347_WRITE_MAX_CHUNK_SIZE  ((size_t)(4096U))
#define CH347_BULK_MAX_BYTES        ((size_t)(4096U))  // CH347 USB bulk max

template <typename T>
using MCFP = bool (T::*)(const std::string& args, std::stop_token st) const;

template <typename T>
using ModuleCommandsMap = std::map<const std::string, MCFP<T>>;

using ModuleSpeedMap = std::map<const std::string, const size_t>;
using SpeedsMapsMap  = std::map<const std::string, ModuleSpeedMap*>;

template <typename T>
using CommandsMapsMap = std::map<const std::string, ModuleCommandsMap<T>*>;

/////////////////////////////////////////////////////////////////////////////////
//              CH347 SPI CLOCK INDEX HELPER                                   //
//  iClock: 0=60MHz 1=30MHz 2=15MHz 3=7.5MHz 4=3.75MHz                         //
//          5=1.875MHz 6=937.5kHz 7=468.75kHz                                  //
/////////////////////////////////////////////////////////////////////////////////

inline uint8_t spiHzToClockIndex(uint32_t hz)
{
    if (hz >= 60000000u) return 0;
    if (hz >= 30000000u) return 1;
    if (hz >= 15000000u) return 2;
    if (hz >=  7500000u) return 3;
    if (hz >=  3750000u) return 4;
    if (hz >=  1875000u) return 5;
    if (hz >=   937500u) return 6;
    return 7; // 468.75 kHz (minimum)
}

inline uint32_t spiClockIndexToHz(uint8_t idx)
{
    static const uint32_t kTable[] = {
        60000000u, 30000000u, 15000000u, 7500000u,
        3750000u,  1875000u,   937500u,  468750u
    };
    return (idx < 8) ? kTable[idx] : kTable[7];
}

/////////////////////////////////////////////////////////////////////////////////
//                 GENERIC TEMPLATE HELPERS                                    //
/////////////////////////////////////////////////////////////////////////////////

/* ============================================================
   generic_module_list_commands
============================================================ */
template <typename T>
bool generic_module_list_commands(const T* pOwner, const std::string& strModule)
{
    ModuleCommandsMap<T>* pMap = pOwner->getModuleCmdsMap(strModule);

    if (pMap && !pMap->empty()) {
        LOG_PRINT(LOG_INFO, LOG_HDR; LOG_STRING(strModule); LOG_STRING(": available commands:"));
        for (const auto& cmd : *pMap) {
            LOG_PRINT(LOG_INFO, LOG_HDR; LOG_STRING("  -"); LOG_STRING(cmd.first));
        }
    } else {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING(strModule); LOG_STRING(": no commands available"));
    }
    return true;
}

/* ============================================================
   generic_module_dispatch  (named cmd + args already split)
============================================================ */
template <typename T>
bool generic_module_dispatch(const T* pOwner,
                              const std::string& strModule,
                              const std::string& strCmd,
                              const std::string& args,
                              std::stop_token st = {})
{
    ModuleCommandsMap<T>* pMap = pOwner->getModuleCmdsMap(strModule);
    auto it = pMap->find(strCmd);
    if (it != pMap->end()) {
        return (pOwner->*it->second)(args, st);
    }
    LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING(strModule);
              LOG_STRING(": command not supported:"); LOG_STRING(strCmd));
    return false;
}

/* ============================================================
   generic_module_dispatch  (single "cmd args" string)
============================================================ */
template <typename T>
bool generic_module_dispatch(const T* pOwner,
                              const std::string& strModule,
                              const std::string& args,
                              std::stop_token st = {})
{
    std::vector<std::string> parts;
    ustring::splitAtFirst(args, CHAR_SEPARATOR_SPACE, parts);

    if (parts.empty()) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING(strModule); LOG_STRING(": expected [help] or [cmd args]"));
        return false;
    }

    if (parts.size() == 1) {
        const std::string& cmd = parts[0];
        if (cmd == "help" || cmd == "close" || cmd == "scan") {
            return generic_module_dispatch<T>(pOwner, strModule, cmd, "", st);
        }
    }

    if (parts.size() < 2) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING(strModule); LOG_STRING(": expected [cmd args]"));
        return false;
    }

    return generic_module_dispatch<T>(pOwner, strModule, parts[0], parts[1], st);
}

/* ============================================================
   generic_module_set_speed
============================================================ */
template <typename T>
bool generic_module_set_speed(const T* pOwner,
                               const std::string& strModule,
                               const std::string& args)
{
    const ModuleSpeedMap* pSpeedMap = pOwner->getModuleSpeedsMap(strModule);
    if (!pSpeedMap) {
        size_t hz = 0;
        if (!numeric::str2sizet(args, hz)) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING(strModule);
                      LOG_STRING(": pass a raw Hz value (e.g. 1000000)"));
            return false;
        }
        return pOwner->setModuleSpeed(strModule, hz);
    }

    if (args == "help") {
        LOG_PRINT(LOG_EMPTY, LOG_STRING(strModule); LOG_STRING(": available speeds:"));
        for (const auto& s : *pSpeedMap) {
            std::string line = s.first + " -> " + std::to_string(s.second) + " Hz";
            LOG_PRINT(LOG_EMPTY, LOG_STRING(line));
        }
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Or pass a raw Hz value directly"));
        return true;
    }

    auto it = pSpeedMap->find(args);
    if (it != pSpeedMap->end()) {
        return pOwner->setModuleSpeed(strModule, it->second);
    }

    size_t hz = 0;
    if (numeric::str2sizet(args, hz)) {
        return pOwner->setModuleSpeed(strModule, hz);
    }

    LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING(strModule);
              LOG_STRING(": unknown speed:"); LOG_STRING(args));
    return false;
}

/* ============================================================
   generic_write_data
============================================================ */
template <typename T>
using WriteCbk = bool (T::*)(std::span<const uint8_t>) const;

template <typename T>
bool generic_write_data(const T* pOwner, const std::string& args, WriteCbk<T> cbk)
{
    if (args == "help") {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use: write AABBCC..  (hex bytes, up to 4096)"));
        return true;
    }

    std::vector<uint8_t> data;
    if (!hexutils::stringUnhexlify(args, data)) return false;

    if (data.empty()) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Expected at least 1 byte"));
        return false;
    }
    if (data.size() > CH347_BULK_MAX_BYTES) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Too many bytes (max 4096):"); LOG_SIZET(data.size()));
        return false;
    }

    return (pOwner->*cbk)(data);
}

/* ============================================================
   generic_write_read_data
============================================================ */
template <typename T>
using WrRdCbk = bool (T::*)(std::span<const uint8_t>, size_t) const;

template <typename T>
bool generic_write_read_data(const T* pOwner, const std::string& args, WrRdCbk<T> cbk)
{
    if (args == "help") {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use: [hexdata][:rdlen]  e.g. DEADBEEF:4 | :4 | DEADBEEF"));
        return true;
    }

    std::vector<uint8_t> request;
    size_t readLen = 0;

    if (args[0] == ':') {
        if (!numeric::str2sizet(args.substr(1), readLen)) return false;
    } else {
        std::vector<std::string> parts;
        ustring::tokenize(args, CHAR_SEPARATOR_COLON, parts);
        if (parts.empty()) return false;
        if (!hexutils::stringUnhexlify(parts[0], request)) return false;
        if (parts.size() == 2) {
            if (!numeric::str2sizet(parts[1], readLen)) return false;
        }
    }

    return (pOwner->*cbk)(request, readLen);
}

/* ============================================================
   generic_write_read_file
============================================================ */
template <typename T>
bool generic_write_read_file(const T* pOwner,
                              const std::string& args,
                              WrRdCbk<T> cbk,
                              const std::string& artefactsPath)
{
    if (args == "help") {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use: filename[:wrchunk][:rdchunk]"));
        return true;
    }

    std::vector<std::string> parts;
    ustring::tokenize(args, CHAR_SEPARATOR_COLON, parts);
    if (parts.empty()) return false;

    std::string path;
    ufile::buildFilePath(artefactsPath, parts[0], path);

    if (!ufile::fileExistsAndNotEmpty(path)) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("File not found or empty:"); LOG_STRING(path));
        return false;
    }

    size_t wrChunk = CH347_WRITE_MAX_CHUNK_SIZE;
    size_t rdChunk = CH347_WRITE_MAX_CHUNK_SIZE;
    if (parts.size() >= 2 && !numeric::str2sizet(parts[1], wrChunk)) return false;
    if (parts.size() >= 3 && !numeric::str2sizet(parts[2], rdChunk)) return false;
    if (wrChunk == 0) wrChunk = CH347_WRITE_MAX_CHUNK_SIZE;
    if (rdChunk == 0) rdChunk = CH347_WRITE_MAX_CHUNK_SIZE;

    std::ifstream fin(path, std::ios::binary);
    if (!fin.is_open()) return false;

    auto fileSize   = ufile::getFileSize(path);
    size_t nChunks  = static_cast<size_t>(fileSize / wrChunk);
    size_t lastSize = static_cast<size_t>(fileSize % wrChunk);

    for (size_t i = 0; i < nChunks; ++i) {
        std::vector<uint8_t> buf(wrChunk);
        fin.read(reinterpret_cast<char*>(buf.data()), static_cast<std::streamsize>(wrChunk));
        if (!(pOwner->*cbk)(buf, rdChunk)) return false;
    }
    if (lastSize > 0) {
        std::vector<uint8_t> buf(lastSize);
        fin.read(reinterpret_cast<char*>(buf.data()), static_cast<std::streamsize>(lastSize));
        if (!(pOwner->*cbk)(buf, std::min(rdChunk, lastSize))) return false;
    }
    return true;
}

/* ============================================================
   generic_execute_script
============================================================ */
template <typename TDriver>
bool generic_execute_script(
    TDriver*           pDriver,
    const std::string& pluginName,
    const std::string& scriptName,
    const std::string& artefactsPath,
    size_t             szMaxRecvSize,
    uint32_t           u32ReadTimeout,
    uint32_t           u32ScriptDelay,
    bool               bEnabled,
    std::stop_token    st = {})
{
    if (!pDriver || !pDriver->is_open()) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Driver not open — run 'open' first"));
        return false;
    }

    std::string strPath;
    ufile::buildFilePath(artefactsPath, scriptName, strPath);

    if (!ufile::fileExistsAndNotEmpty(strPath)) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Script not found or empty:"); LOG_STRING(strPath));
        return false;
    }

    auto spDriver = std::shared_ptr<TDriver>(std::shared_ptr<TDriver>{}, pDriver);


    try {
        CommScriptClient<TDriver> client(strPath, spDriver,
                                          pluginName,
                                          szMaxRecvSize,
                                          u32ReadTimeout,
                                          u32ScriptDelay,
                                          typename CommScriptClient<TDriver>::SendFunc{},
                                          typename CommScriptClient<TDriver>::RecvFunc{},
                                          st);
        return client.execute(bEnabled);
    } catch (const std::bad_alloc& e) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("OOM allocating script client:"); LOG_STRING(e.what()));
    } catch (const std::exception& e) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Script execution failed:"); LOG_STRING(e.what()));
    }
    return false;
}

#endif //CH374_GENERIC_HPP
