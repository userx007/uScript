/*
http://dangerousprototypes.com/docs/1-Wire_(binary)
*/
#include "bithandling.h"
#include "buspirate_generic.hpp"
#include "buspirate_plugin.hpp"
#include "uLogger.hpp"
#include "uNumeric.hpp"
#include "uString.hpp"

#include <stddef.h>
#include <stdint.h>
#include <algorithm>
#include <iostream>
#include <span>
#include <stop_token>
#include <string>

/////////////////////////////////////////////////////////////////////////////////
//                            LOCAL DEFINITIONS                                //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
    #undef LT_HDR
#endif
#ifdef LOG_HDR
    #undef LOG_HDR
#endif
#define LT_HDR     "BPIRATE_OWIR|"
#define LOG_HDR    LOG_STRING(LT_HDR)

///////////////////////////////////////////////////////////////////
//                          DEFINES                              //
///////////////////////////////////////////////////////////////////

#define PROTOCOL_NAME    "ONEWIRE"

///////////////////////////////////////////////////////////////////
//             PUBLIC INTERFACES IMPLEMENTATION                  //
///////////////////////////////////////////////////////////////////

/* ============================================================================================
 List the subcommands of the protocol
============================================================================================ */

bool BuspiratePlugin::m_handle_onewire_help(const std::string &args, std::stop_token /*st*/) const
{
   return generic_module_list_commands<BuspiratePlugin>(this, PROTOCOL_NAME);
}

/* ============================================================================================
00000010 – 1-Wire reset
Send a 1-Wire reset. Responds 0×01.
Use a dummy char /string for the second parameter (will be ignored)
============================================================================================ */

bool BuspiratePlugin::m_handle_onewire_reset(const std::string &args, std::stop_token st) const
{
    uint8_t request = 0x02;
    uint8_t response[sizeof(m_positive_response)] = {};
    return generic_uart_send_receive(numeric::byte2span(request), numeric::byte2span(response), numeric::byte2span(m_positive_response), true, st);

} /* m_handle_onewire_reset() */

/* ============================================================================================
00001000 - ROM search macro (0xf0)
00001001 - ALARM search macro (0xec)

Search macros are special 1-Wire procedures that determine device addresses.
The command returns 0x01, and then each 8-byte 1-Wire address located.
Data ends with 8 bytes of 0xff.
============================================================================================ */

bool BuspiratePlugin::m_handle_onewire_search(const std::string &args, std::stop_token st) const
{
    bool bRetVal = true;
    uint8_t request = 0U;

    // The Bus Pirate binary protocol commands for search macros are 0x08 (ROM) and 0x09 (ALARM).
    // These are NOT the 1-Wire ROM codes (0xF0 / 0xEC) — those are the codes the Bus Pirate
    // sends internally to the bus on behalf of the host.
    if      ("rom"   == args) { request = 0x08U; }  // 00001000 – ROM search macro (0xf0)
    else if ("alarm" == args) { request = 0x09U; }  // 00001001 – ALARM search macro (0xec)
    else if ("help"  == args) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use: rom alarm"));
    } else {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid subcommand:"); LOG_STRING(args));
        bRetVal = false;
    }

    if (true == bRetVal && "help" != args) {
        uint8_t response[sizeof(m_positive_response)] = {};
        bRetVal = generic_uart_send_receive(numeric::byte2span(request), numeric::byte2span(response), numeric::byte2span(m_positive_response), true, st);
    }

    return bRetVal;

} /* m_handle_onewire_search() */

/* ============================================================================================
00000100 – Read byte(s)
Reads a byte from the bus, returns the byte.
============================================================================================ */

bool BuspiratePlugin::m_handle_onewire_read(const std::string &args, std::stop_token st) const
{
    bool bRetVal = true;

    if ("help" == args) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use: 1 .. N"));
    } else {
        size_t szReadSize = 0;
        if (true == (bRetVal = numeric::str2sizet(args, szReadSize))) {
            for (size_t i = 0; i < szReadSize; ++i) {
                if (st.stop_requested()) { bRetVal = false; break; }
                uint8_t request  = 0x04; // 00000100 – Read byte
                uint8_t response = 0x00;
                if (false == (bRetVal = generic_uart_send_receive(numeric::byte2span(request), numeric::byte2span(response), std::span<const uint8_t>{}, true, st))) {
                    break;
                }
            }
        }
    }

    return bRetVal;

} /* m_handle_onewire_read() */

/* ============================================================================================
 0001xxxx – Bulk 1-Wire write, send 1-16 bytes (0=1byte!)

Bulk write transfers a packet of xxxx+1 bytes to the 1-Wire bus.
Up to 16 data bytes can be sent at once. Note that 0000 indicates 1 byte because there’s no
reason to send 0. BP replies 0×01 to each byte.
============================================================================================ */

bool BuspiratePlugin::m_handle_onewire_write(const std::string &args, std::stop_token st) const
{
    return generic_write_data(this, args, &BuspiratePlugin::generic_wire_write_data, st);

} /* m_handle_onewire_write() */

/* ============================================================================================
 0100wxyz – Configure peripherals w=power, x=pullups, y=AUX, z=CS

Enable (1) and disable (0) Bus Pirate peripherals and pins.
- bit w enables the power supplies,
- bit x toggles the on-board pull-up resistors,
- y sets the state of the auxiliary pin,
- z sets the chip select pin.
Features not present in a specific hardware version are ignored.
Bus Pirate responds 0×01 on success.

Note:
CS pin always follows the current HiZ pin configuration.
AUX is always a normal pin output (0=GND, 1=3.3volts).
============================================================================================ */

bool BuspiratePlugin::m_handle_onewire_cfg(const std::string &args, std::stop_token st) const
{
    bool bRetVal = true;
    uint8_t request = 0x40;

    if ("help" == args) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("w/W - disable/enable power "));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("p/P - toggle pull-up resistors"));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("a/A - toggle AUX pin"));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("c/C - toggle CS pin"));
    } else if ("?" == args) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("onewire::cfg:"); LOG_UINT8(request));
    } else {
        // pin output
        if (ustring::containsChar(args, 'w')) { BIT_CLEAR(request, 3); }
        if (ustring::containsChar(args, 'W')) { BIT_SET(request,   3); }
        // clock idle phase
        if (ustring::containsChar(args, 'p')) { BIT_CLEAR(request, 2); }
        if (ustring::containsChar(args, 'P')) { BIT_SET(request,   2); }
        // clock edge
        if (ustring::containsChar(args, 'a')) { BIT_CLEAR(request, 1); }
        if (ustring::containsChar(args, 'A')) { BIT_SET(request,   1); }
        // sample time
        if (ustring::containsChar(args, 'c')) { BIT_CLEAR(request, 0); }
        if (ustring::containsChar(args, 'C')) { BIT_SET(request,   0); }

        uint8_t response[sizeof(m_positive_response)] = {};
        bRetVal = generic_uart_send_receive(numeric::byte2span(request), numeric::byte2span(response), numeric::byte2span(m_positive_response), true, st);
    }

    return bRetVal;

} /* m_handle_onewire_cfg() */

/* ============================================================================================
    BuspiratePlugin::m_onewire_read

    00000100 - Read byte
    Reads a byte from the bus, returns the byte. Same command byte as
    m_handle_onewire_read() above, called once per byte since the Bus Pirate
    1-Wire binary protocol has no bulk-read command (unlike bulk write) —
    difference from m_handle_onewire_read(): this captures each byte into
    the caller's buffer instead of discarding it, for use by
    ONEWIRE_CommDriver::tout_read() (see buspirate_plugin.hpp).
============================================================================================ */
bool BuspiratePlugin::m_onewire_read(std::span<uint8_t> response, std::stop_token st) const
{
    static constexpr uint8_t ONEWIRE_READ_BYTE = 0x04; // 00000100

    for (size_t i = 0; i < response.size(); ++i) {
        if (st.stop_requested()) return false;
        uint8_t request = ONEWIRE_READ_BYTE;
        uint8_t data    = 0;
        if (false == generic_uart_send_receive(numeric::byte2span(request), numeric::byte2span(data), std::span<const uint8_t>{}, true, st)) {
            return false;
        }
        response[i] = data;
    }

    return true;

} /* m_onewire_read() */

/* ============================================================================================
    BuspiratePlugin::m_onewire_bulk_write

    Chunks request into <=16-byte pieces and delegates each to the existing
    generic_wire_write_data() (shared with RawWire/UART — see buspirate_generic.cpp),
    which enforces that 16-byte-per-call limit itself. For use by
    ONEWIRE_CommDriver::tout_write() (see buspirate_plugin.hpp).
============================================================================================ */
bool BuspiratePlugin::m_onewire_bulk_write(std::span<const uint8_t> request, std::stop_token st) const
{
    static constexpr size_t szMaxChunk = 16;

    size_t offset = 0;
    while (offset < request.size()) {
        const size_t szCount = std::min(szMaxChunk, request.size() - offset);
        if (false == generic_wire_write_data(request.subspan(offset, szCount), st)) {
            return false;
        }
        offset += szCount;
        if (st.stop_requested()) return false;
    }

    return true;

} /* m_onewire_bulk_write() */

/* ============================================================================================
    BuspiratePlugin::m_handle_onewire_script
============================================================================================ */
bool BuspiratePlugin::m_handle_onewire_script(const std::string &args, std::stop_token st) const
{
    bool bRetVal = true;

    if ("help" == args) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use: <scriptname>"));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("  Executes script from ARTEFACTS_PATH/scriptname"));
    } else {
        bRetVal = generic_execute_script<BuspiratePlugin, BuspiratePlugin::ONEWIRE_CommDriver>(this, m_strInstanceName, args, st);
    }

    return bRetVal;

} /* m_handle_onewire_script() */
