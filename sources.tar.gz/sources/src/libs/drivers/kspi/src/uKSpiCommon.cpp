#include "uKSpi.hpp"
#include "uKmpMatch.hpp"
#include "uLogger.hpp"

#include <array>
#include <mutex>
#include <span>
#include <stddef.h>
#include <stdint.h>
#include <stop_token>
#include <string_view>
#include <vector>

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
#undef LT_HDR
#endif
#ifdef LOG_HDR
#undef LOG_HDR
#endif

#define LT_HDR  "KSPI_DRV    |"
#define LOG_HDR LOG_STRING(LT_HDR)

/////////////////////////////////////////////////////////////////////////////////
//                            IMPLEMENTATION                                   //
/////////////////////////////////////////////////////////////////////////////////

bool KSPI::is_open() const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_iHandle >= 0;
}

// ============================================================================
// PUBLIC UNIFIED INTERFACE IMPLEMENTATION
// ============================================================================

KSPI::ReadResult KSPI::tout_read(uint32_t u32ReadTimeout,
                                 std::span<uint8_t> buffer,
                                 const ReadOptions &sOptions,
                                 std::string_view /*xtra_params*/,
                                 std::stop_token stop_tok) const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    ReadResult result;

    switch (sOptions.mode) {
    case ReadMode::Exact: {
        size_t bytes_read       = 0;
        result.status           = timeout_read(u32ReadTimeout, buffer, bytes_read, stop_tok);
        result.bytes_read       = bytes_read;
        result.found_terminator = false;
        break;
    }

    case ReadMode::UntilDelimiter: {
        size_t bytes_read       = 0;
        result.status           = timeout_read_until(u32ReadTimeout, buffer,
                                                     sOptions.delimiter, bytes_read, stop_tok);
        result.bytes_read       = bytes_read;
        result.found_terminator = (result.status == Status::SUCCESS);
        break;
    }

    case ReadMode::UntilToken: {
        result.status           = timeout_wait_for_token(u32ReadTimeout,
                                                         sOptions.token,
                                                         sOptions.use_buffer,
                                                         stop_tok);
        result.bytes_read       = 0; // Token search does not fill the user buffer
        result.found_terminator = (result.status == Status::SUCCESS);
        break;
    }

    default:
        result.status           = Status::INVALID_PARAM;
        result.bytes_read       = 0;
        result.found_terminator = false;
        break;
    }

    return result;
}

KSPI::WriteResult KSPI::tout_write(uint32_t u32WriteTimeout,
                                   std::span<const uint8_t> buffer,
                                   std::string_view /*xtra_params*/,
                                   std::stop_token stop_tok) const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    WriteResult result;
    size_t bytes_written = 0;

    result.status        = timeout_write(u32WriteTimeout, buffer, bytes_written, stop_tok);
    result.bytes_written = bytes_written;

    return result;
}

// ============================================================================
// PRIVATE LEGACY IMPLEMENTATION (INTERNAL USE ONLY)
// ============================================================================

KSPI::Status KSPI::timeout_wait_for_token(uint32_t u32ReadTimeout,
                                          std::span<const uint8_t> token,
                                          bool bUseBuffer,
                                          std::stop_token stop_tok) const
{
    const size_t szTokenLength = token.size();
    if (token.empty() || szTokenLength == 0 || szTokenLength >= KSPI_MAX_BUFLENGTH) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid token or length"));
        return Status::INVALID_PARAM;
    }

    const uint32_t u32Timeout   = (u32ReadTimeout == 0) ? KSPI_READ_DEFAULT_TIMEOUT : u32ReadTimeout;
    const bool bReturnOnTimeout = (u32ReadTimeout != 0);

    std::vector<int> viLps;
    build_kmp_table(token, szTokenLength, viLps);

    return kmp_stream_match(token, viLps, u32Timeout, bReturnOnTimeout, bUseBuffer, stop_tok);
}

void KSPI::build_kmp_table(std::span<const uint8_t> pattern,
                           size_t szLength,
                           std::vector<int> &vViLps) const
{
    ukmp::build_kmp_table(pattern, szLength, vViLps);
}

KSPI::Status KSPI::kmp_stream_match(std::span<const uint8_t> token,
                                    const std::vector<int> &vViLps,
                                    uint32_t u32Timeout,
                                    bool bReturnOnTimeout,
                                    bool bUseBuffer,
                                    std::stop_token stop_tok) const
{
    return ukmp::kmp_stream_match(
        [this, stop_tok](uint32_t timeout, std::span<uint8_t> buf, size_t &bytesRead) { return timeout_read(timeout, buf, bytesRead, stop_tok); },
        token, vViLps, u32Timeout, bReturnOnTimeout, bUseBuffer,
        /*szChunkBufferSize=*/1, /*szRingBufferSize=*/KSPI_MAX_BUFLENGTH);
}

KSPI::Status KSPI::timeout_read_until(uint32_t u32ReadTimeout,
                                      std::span<uint8_t> buffer,
                                      uint8_t u8CDelimiter,
                                      size_t &szBytesRead,
                                      std::stop_token stop_tok) const
{
    if (buffer.size() < 2) {
        LOG_PRINT(LOG_ERROR, LOG_HDR;
                  LOG_STRING("Buffer too small for delimiter + null terminator"));
        return Status::INVALID_PARAM;
    }

    szBytesRead          = 0;
    KSPI::Status eResult = Status::RETVAL_NOT_SET;

    while (eResult == Status::RETVAL_NOT_SET) {
        const size_t bytesRemaining = buffer.size() - szBytesRead - 1; // reserve for '\0'
        if (bytesRemaining == 0) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Buffer full before delimiter found"));
            return Status::BUFFER_OVERFLOW;
        }

        uint8_t cByte          = 0;
        size_t actualBytesRead = 0;

        KSPI::Status readResult =
            timeout_read(u32ReadTimeout, std::span<uint8_t>(&cByte, 1), actualBytesRead, stop_tok);

        if (readResult == Status::SUCCESS && actualBytesRead > 0) {
            if (cByte == u8CDelimiter) {
                buffer[szBytesRead] = '\0';
                return Status::SUCCESS;
            }
            buffer[szBytesRead++] = cByte;
        } else if (readResult == Status::READ_TIMEOUT) {
            eResult = (u32ReadTimeout > 0) ? Status::READ_TIMEOUT : Status::PORT_ACCESS;
        } else {
            eResult = Status::PORT_ACCESS;
        }
    }

    return eResult;
}
