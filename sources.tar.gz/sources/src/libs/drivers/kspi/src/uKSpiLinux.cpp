#include "uKSpi.hpp"
#include "uLogger.hpp"

#include <algorithm>
#include <chrono>
#include <compare>
#include <cstring>
#include <errno.h>
#include <fcntl.h>
#include <linux/spi/spidev.h> // SPI_IOC_WR_*, SPI_IOC_MESSAGE, spi_ioc_transfer
#include <mutex>
#include <poll.h>
#include <span>
#include <stdint.h>
#include <stop_token>
#include <string>
#include <sys/ioctl.h>
#include <unistd.h>
#include <vector>

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
#undef LT_HDR
#endif
#ifdef LOG_HDR
#undef LOG_HDR
#endif

#define LT_HDR  "KSPI_DRV    |"
#define LOG_HDR LOG_STRING(LT_HDR)

/////////////////////////////////////////////////////////////////////////////////
//                            IMPLEMENTATION                                   //
/////////////////////////////////////////////////////////////////////////////////

// ============================================================================
// OPEN / CLOSE
// ============================================================================

KSPI::Status KSPI::open(const std::string &strDevice, const SpiConfig &sConfig)
{
    std::lock_guard<std::mutex> lock(m_mutex);

    if (strDevice.empty()) {
        LOG_PRINT(LOG_ERROR, LOG_HDR;
                  LOG_STRING("Invalid parameter: empty device path"));
        return Status::INVALID_PARAM;
    }

    m_iHandle = ::open(strDevice.c_str(), O_RDWR | O_CLOEXEC);
    if (m_iHandle < 0) {
        const int errnoRet = errno;
        LOG_PRINT(LOG_ERROR, LOG_HDR;
                  LOG_STRING("Failed to open ["); LOG_STRING(strDevice.c_str());
                  LOG_STRING("] errno:"); LOG_INT(errnoRet));
        return Status::PORT_ACCESS;
    }

    const Status result = setup(sConfig);
    if (result != Status::SUCCESS) {
        LOG_PRINT(LOG_ERROR, LOG_HDR;
                  LOG_STRING("Failed to configure ["); LOG_STRING(strDevice.c_str());
                  LOG_STRING("] Error:"); LOG_INT(static_cast<int>(result)));
        ::close(m_iHandle);
        m_iHandle = -1;
        return Status::PORT_ACCESS;
    }

    m_config = sConfig;

    LOG_PRINT(LOG_VERBOSE, LOG_HDR;
              LOG_STRING("KSPI ["); LOG_STRING(strDevice.c_str());
              LOG_STRING("] opened, mode:"); LOG_UINT32(sConfig.mode);
              LOG_STRING(" speed:"); LOG_UINT32(sConfig.speed_hz);
              LOG_STRING(" bpw:"); LOG_UINT32(sConfig.bits_per_word);
              LOG_STRING(", handle:"); LOG_INT(m_iHandle));

    return Status::SUCCESS;
}

KSPI::Status KSPI::close()
{
    std::lock_guard<std::mutex> lock(m_mutex);

    if (m_iHandle >= 0) {
        ::close(m_iHandle);
        LOG_PRINT(LOG_VERBOSE, LOG_HDR;
                  LOG_STRING("KSPI closed, handle:"); LOG_INT(m_iHandle));
        m_iHandle = -1;
    }

    return Status::SUCCESS;
}

// ============================================================================
// BUS CONFIGURATION
// ============================================================================

KSPI::Status KSPI::setup(const SpiConfig &sConfig) const
{
    // KSPI mode (CPOL / CPHA)
    uint8_t mode = sConfig.mode & 0x03u;
    if (::ioctl(m_iHandle, SPI_IOC_WR_MODE, &mode) < 0) {
        const int err = errno;
        LOG_PRINT(LOG_ERROR, LOG_HDR;
                  LOG_STRING("ioctl(SPI_IOC_WR_MODE) failed, errno:"); LOG_INT(err));
        return Status::PORT_ACCESS;
    }

    // LSB / MSB bit order
    uint8_t lsb = sConfig.lsb_first ? 1u : 0u;
    if (::ioctl(m_iHandle, SPI_IOC_WR_LSB_FIRST, &lsb) < 0) {
        const int err = errno;
        LOG_PRINT(LOG_ERROR, LOG_HDR;
                  LOG_STRING("ioctl(SPI_IOC_WR_LSB_FIRST) failed, errno:"); LOG_INT(err));
        return Status::PORT_ACCESS;
    }

    // Bits per word
    uint8_t bpw = sConfig.bits_per_word;
    if (::ioctl(m_iHandle, SPI_IOC_WR_BITS_PER_WORD, &bpw) < 0) {
        const int err = errno;
        LOG_PRINT(LOG_ERROR, LOG_HDR;
                  LOG_STRING("ioctl(SPI_IOC_WR_BITS_PER_WORD) failed, errno:"); LOG_INT(err));
        return Status::PORT_ACCESS;
    }

    // Maximum bus speed
    uint32_t speed = sConfig.speed_hz;
    if (::ioctl(m_iHandle, SPI_IOC_WR_MAX_SPEED_HZ, &speed) < 0) {
        const int err = errno;
        LOG_PRINT(LOG_ERROR, LOG_HDR;
                  LOG_STRING("ioctl(SPI_IOC_WR_MAX_SPEED_HZ) failed, errno:"); LOG_INT(err));
        return Status::PORT_ACCESS;
    }

    return Status::SUCCESS;
}

// ============================================================================
// INTERNAL FULL-DUPLEX TRANSFER PRIMITIVE
// ============================================================================

KSPI::Status KSPI::spi_transfer(const uint8_t *pu8TxBuf,
                                uint8_t *pu8RxBuf,
                                size_t length) const
{
    // Zero-initialise so any un-set fields default to using the values
    // already configured on the file descriptor by setup().
    struct spi_ioc_transfer xfer = {};
    xfer.tx_buf                  = reinterpret_cast<uintptr_t>(pu8TxBuf);
    xfer.rx_buf                  = reinterpret_cast<uintptr_t>(pu8RxBuf);
    xfer.len                     = static_cast<uint32_t>(length);
    xfer.speed_hz                = m_config.speed_hz;
    xfer.bits_per_word           = m_config.bits_per_word;
    xfer.delay_usecs             = 0;
    xfer.cs_change               = 0;

    if (::ioctl(m_iHandle, SPI_IOC_MESSAGE(1), &xfer) < 0) {
        const int err = errno;
        LOG_PRINT(LOG_ERROR, LOG_HDR;
                  LOG_STRING("SPI_IOC_MESSAGE failed, errno:"); LOG_INT(err));
        return Status::READ_ERROR;
    }

    return Status::SUCCESS;
}

// ============================================================================
// INTERNAL READ PRIMITIVE
// ============================================================================

KSPI::Status KSPI::timeout_read(uint32_t u32ReadTimeout,
                                std::span<uint8_t> buffer,
                                size_t &szBytesRead,
                                std::stop_token stop_tok) const
{
    if (buffer.empty()) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("timeout_read: invalid parameter"));
        return Status::INVALID_PARAM;
    }

    szBytesRead = 0;

    // poll(2) on a spidev fd unblocks immediately (KSPI is synchronous), but
    // we keep the guard consistent with the UART / I2C drivers so that a
    // hung kernel driver does not block indefinitely.
    struct pollfd sPollFd;
    sPollFd.fd                 = m_iHandle;
    sPollFd.events             = POLLOUT; // spidev signals writable when the bus is ready
    sPollFd.revents            = 0;

    // 0 == infinite timeout: never expire the wait ourselves. Either way,
    // poll in bounded slices so a stop request can be observed promptly.
    constexpr int kPollSliceMs = 200;
    const bool bInfinite       = (u32ReadTimeout == 0);
    const auto tDeadline       = std::chrono::steady_clock::now() + std::chrono::milliseconds(u32ReadTimeout);

    int iPollResult            = 0;
    while (true) {
        if (stop_tok.stop_requested()) {
            return Status::READ_TIMEOUT;
        }

        int iSliceMs = kPollSliceMs;
        if (!bInfinite) {
            const auto remaining = tDeadline - std::chrono::steady_clock::now();
            if (remaining <= std::chrono::milliseconds(0)) {
                return Status::READ_TIMEOUT;
            }
            iSliceMs = static_cast<int>(std::min<int64_t>(kPollSliceMs,
                                                          std::chrono::duration_cast<std::chrono::milliseconds>(remaining).count()));
        }

        iPollResult = ::poll(&sPollFd, 1, iSliceMs);
        if (iPollResult < 0) {
            const int err = errno;
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("poll() failed"); LOG_INT(err));
            return Status::READ_ERROR;
        }
        if (iPollResult > 0) {
            break;
        }
    }

    // TX padding: send 0x00 bytes while clocking in the RX data.
    std::vector<uint8_t> txPad(buffer.size(), 0x00u);

    const Status st = spi_transfer(txPad.data(), buffer.data(), buffer.size());
    if (st != Status::SUCCESS) {
        return Status::READ_ERROR;
    }

    szBytesRead = buffer.size();
    return Status::SUCCESS;
}

// ============================================================================
// INTERNAL WRITE PRIMITIVE
// ============================================================================

KSPI::Status KSPI::timeout_write(uint32_t u32WriteTimeout,
                                 std::span<const uint8_t> buffer,
                                 size_t &szBytesWritten,
                                 std::stop_token stop_tok) const
{
    if (buffer.empty()) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid parameter: buffer.empty()"));
        return Status::INVALID_PARAM;
    }

    szBytesWritten = 0;

    // poll guard — consistent with UART / I2C drivers.
    struct pollfd sPollFd;
    sPollFd.fd                 = m_iHandle;
    sPollFd.events             = POLLOUT;
    sPollFd.revents            = 0;

    // 0 == infinite timeout: never expire the wait ourselves. Either way,
    // poll in bounded slices so a stop request can be observed promptly.
    constexpr int kPollSliceMs = 200;
    const bool bInfinite       = (u32WriteTimeout == 0);
    const auto tDeadline       = std::chrono::steady_clock::now() + std::chrono::milliseconds(u32WriteTimeout);

    int iPollResult            = 0;
    while (true) {
        if (stop_tok.stop_requested()) {
            return Status::WRITE_TIMEOUT;
        }

        int iSliceMs = kPollSliceMs;
        if (!bInfinite) {
            const auto remaining = tDeadline - std::chrono::steady_clock::now();
            if (remaining <= std::chrono::milliseconds(0)) {
                return Status::WRITE_TIMEOUT;
            }
            iSliceMs = static_cast<int>(std::min<int64_t>(kPollSliceMs,
                                                          std::chrono::duration_cast<std::chrono::milliseconds>(remaining).count()));
        }

        iPollResult = ::poll(&sPollFd, 1, iSliceMs);
        if (iPollResult < 0) {
            const int err = errno;
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("poll() failed"); LOG_INT(err));
            return Status::WRITE_ERROR;
        }
        if (iPollResult > 0) {
            break;
        }
    }

    // RX sink: allocate a discard buffer for the simultaneous incoming bytes.
    std::vector<uint8_t> rxSink(buffer.size(), 0x00u);

    const Status st = spi_transfer(buffer.data(), rxSink.data(), buffer.size());
    if (st != Status::SUCCESS) {
        return Status::WRITE_ERROR;
    }

    szBytesWritten = buffer.size();
    return Status::SUCCESS;
}
