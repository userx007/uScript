#ifndef HYDRABUS_SMARTCARD_HPP
#define HYDRABUS_SMARTCARD_HPP

#include "Protocol.hpp"

#include <memory>
#include <optional>
#include <span>
#include <stddef.h>
#include <stdint.h>
#include <stop_token>
#include <vector>

namespace HydraHAL {
    class Hydrabus;

    /**
     * @brief HydraBus Smartcard (ISO 7816) binary mode handler.
     *
     * Provides RST pin control, baud/prescaler/guard-time configuration,
     * ATR retrieval, and a write-then-read primitive that covers both
     * pure writes and pure reads.
     *
     * @example
     * @code
     * auto hb = std::make_shared<HydraHAL::Hydrabus>(driver);
     * hb->enter_bbio();
     *
     * HydraHAL::Smartcard sc(hb);
     * sc.set_prescaler(12);
     * sc.set_baud(9600);
     * sc.set_rst(1); sc.set_rst(0);
     * auto atr = sc.get_atr();
     * @endcode
     */

    class Smartcard : public Protocol {

        public:
            explicit Smartcard(std::shared_ptr<Hydrabus> shpHydrabus);

            // -------------------------------------------------------------------------
            // Data transfer
            // -------------------------------------------------------------------------

            /**
             * @brief Write-then-read operation (HydraFW 0b00000100).
             * @param data     Bytes to transmit.
             * @param read_len Number of bytes to read back.
             * @return Read bytes, or nullopt on error.
             */
            std::optional<std::vector<uint8_t>> write_read(
                std::span<const uint8_t> data,
                size_t read_len,
                std::stop_token stop_tok = {});

            bool write(std::span<const uint8_t> data, std::stop_token stop_tok = {});

            std::vector<uint8_t> read(size_t length, std::stop_token stop_tok = {});

            // -------------------------------------------------------------------------
            // ATR
            // -------------------------------------------------------------------------

            /**
             * @brief Retrieve the card's Answer-To-Reset (ATR) byte string.
             * @return ATR bytes (variable length).
             */
            std::vector<uint8_t> get_atr(std::stop_token stop_tok = {});

            // -------------------------------------------------------------------------
            // RST pin
            // -------------------------------------------------------------------------

            /** @return Current RST pin level. */
            int get_rst() const;

            /** @param level 0 or 1. @return true on success. */
            bool set_rst(int iLevel);

            // -------------------------------------------------------------------------
            // Configuration
            // -------------------------------------------------------------------------

            uint32_t get_baud() const;
            bool set_baud(uint32_t u32Baud);

            uint8_t get_prescaler() const;
            bool set_prescaler(uint8_t u8Value);

            uint8_t get_guardtime() const;
            bool set_guardtime(uint8_t u8Value);

            bool get_pullup() const;
            bool set_pullup(bool bEnable);

        private:
            bool _configure_port();

            uint8_t _config{0b0000};
            int _rst{1};
            uint32_t _baud{9600};
            uint8_t _prescaler{12};
            uint8_t _guardtime{16};
    };

} // namespace HydraHAL

#endif // HYDRABUS_SMARTCARD_HPP
