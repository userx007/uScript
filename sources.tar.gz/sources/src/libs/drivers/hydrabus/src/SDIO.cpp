#include "SDIO.hpp"

#include "Support.hpp"
#include "uLogger.hpp"

#include <utility>

namespace HydraHAL {
    class Hydrabus;
} // namespace HydraHAL

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
#undef LT_HDR
#endif
#ifdef LOG_HDR
#undef LOG_HDR
#endif

#define LT_HDR  "HYDRA_SDIO  |"
#define LOG_HDR LOG_STRING(LT_HDR)

/////////////////////////////////////////////////////////////////////////////////
//                         NAMESPACE IMPLEMENTATION                            //
/////////////////////////////////////////////////////////////////////////////////

namespace HydraHAL {

    SDIO::SDIO(std::shared_ptr<Hydrabus> shpHydrabus)
        : Protocol(std::move(shpHydrabus), "SDI1", "SDIO", 0x0E)
    {
    }

    // ---------------------------------------------------------------------------
    // Command variants
    // ---------------------------------------------------------------------------

    bool SDIO::send_no(uint8_t u8Cmd_id, uint32_t u32Cmd_arg, std::stop_token stop_tok)
    {
        _write_byte(0b00000100, stop_tok);
        _write_byte(u8Cmd_id, stop_tok);
        _write_u32_le(u32Cmd_arg, stop_tok);
        return _read_byte(stop_tok) == 0x01;
    }

    std::optional<std::vector<uint8_t>> SDIO::send_short(uint8_t cmd_id, uint32_t cmd_arg, std::stop_token stop_tok)
    {
        _write_byte(0b00000101, stop_tok);
        _write_byte(cmd_id, stop_tok);
        _write_u32_le(cmd_arg, stop_tok);

        if (_read_byte(stop_tok) != 0x01) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("send_short: error response"));
            return std::nullopt;
        }
        return _read(4, stop_tok);
    }

    std::optional<std::vector<uint8_t>> SDIO::send_long(uint8_t cmd_id, uint32_t cmd_arg, std::stop_token stop_tok)
    {
        _write_byte(0b00000110, stop_tok);
        _write_byte(cmd_id, stop_tok);
        _write_u32_le(cmd_arg, stop_tok);

        if (_read_byte(stop_tok) != 0x01) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("send_long: error response"));
            return std::nullopt;
        }
        return _read(16, stop_tok);
    }

    // ---------------------------------------------------------------------------
    // Data transfer
    // ---------------------------------------------------------------------------

    bool SDIO::write(uint8_t u8Cmd_id, uint32_t u32Cmd_arg, std::span<const uint8_t> data, std::stop_token stop_tok)
    {
        if (data.size() != BLOCK_SIZE) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("write: data must be exactly 512 bytes"));
            return false;
        }

        _write_byte(0b00001001, stop_tok);
        _write_byte(u8Cmd_id, stop_tok);
        _write_u32_le(u32Cmd_arg, stop_tok);
        _write(data, stop_tok);

        return _read_byte(stop_tok) == 0x01;
    }

    std::vector<uint8_t> SDIO::read(uint8_t cmd_id, uint32_t cmd_arg, std::stop_token stop_tok)
    {
        _write_byte(0b00001101, stop_tok);
        _write_byte(cmd_id, stop_tok);
        _write_u32_le(cmd_arg, stop_tok);

        if (_read_byte(stop_tok) != 0x01) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("read: error response"));
            return {};
        }
        return _read(BLOCK_SIZE, stop_tok);
    }

    // ---------------------------------------------------------------------------
    // Configuration
    // ---------------------------------------------------------------------------

    int SDIO::get_bus_width() const
    {
        return (_config & 0b01) ? 4 : 1;
    }

    bool SDIO::set_bus_width(int iWidth)
    {
        if (iWidth == 1) {
            _config = static_cast<uint8_t>(_config & ~0b01);
        } else if (iWidth == 4) {
            _config = static_cast<uint8_t>(_config | 0b01);
        } else {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("set_bus_width: valid values are 1 or 4"));
            return false;
        }
        return _configure_port();
    }

    int SDIO::get_frequency() const
    {
        return (_config & 0b10) ? 1 : 0;
    }

    bool SDIO::set_frequency(int iFreq)
    {
        if (iFreq == 0) {
            _config = static_cast<uint8_t>(_config & ~(1 << 1));
        } else if (iFreq == 1) {
            _config = static_cast<uint8_t>(_config | (1 << 1));
        } else {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("set_frequency: valid values are 0 (slow) or 1 (fast)"));
            return false;
        }
        return _configure_port();
    }

    bool SDIO::_configure_port()
    {
        uint8_t cmd = static_cast<uint8_t>(0b10000000 | (_config & 0x7F));
        _write_byte(cmd);
        if (!_ack("_configure_port")) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Error setting config"));
            return false;
        }
        return true;
    }

} // namespace HydraHAL
