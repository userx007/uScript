#include "MMC.hpp"

#include "Support.hpp"
#include "uLogger.hpp"

#include <utility>

namespace HydraHAL {
    class Hydrabus;
} // namespace HydraHAL

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
#undef LT_HDR
#endif
#ifdef LOG_HDR
#undef LOG_HDR
#endif

#define LT_HDR  "HYDRA_MMC   |"
#define LOG_HDR LOG_STRING(LT_HDR)

/////////////////////////////////////////////////////////////////////////////////
//                         NAMESPACE IMPLEMENTATION                            //
/////////////////////////////////////////////////////////////////////////////////

namespace HydraHAL {

    MMC::MMC(std::shared_ptr<Hydrabus> shpHydrabus)
        : Protocol(std::move(shpHydrabus), "MMC1", "eMMC", 0x0D)
    {
    }

    // ---------------------------------------------------------------------------
    // Register access
    // ---------------------------------------------------------------------------

    std::vector<uint8_t> MMC::get_cid(std::stop_token stop_tok)
    {
        _write_byte(0b00000010, stop_tok);
        /* status byte */ _read_byte(stop_tok);
        return _read(REG_SIZE_STD, stop_tok);
    }

    std::vector<uint8_t> MMC::get_csd(std::stop_token stop_tok)
    {
        _write_byte(0b00000011, stop_tok);
        /* status byte */ _read_byte(stop_tok);
        return _read(REG_SIZE_STD, stop_tok);
    }

    std::vector<uint8_t> MMC::get_ext_csd(std::stop_token stop_tok)
    {
        _write_byte(0b00000110, stop_tok);
        /* status byte */ _read_byte(stop_tok);
        return _read(REG_SIZE_EXT, stop_tok);
    }

    // ---------------------------------------------------------------------------
    // Block I/O
    // ---------------------------------------------------------------------------

    std::vector<uint8_t> MMC::read(uint32_t block_num, std::stop_token stop_tok)
    {
        _write_byte(0b00000100, stop_tok);
        _write_u32_be(block_num, stop_tok);

        uint8_t status = _read_byte(stop_tok);
        if (status != 0x01) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("read: error status"); LOG_HEX8(status));
            return {};
        }
        return _read(BLOCK_SIZE, stop_tok);
    }

    bool MMC::write(std::span<const uint8_t> data, uint32_t u32Block_num, std::stop_token stop_tok)
    {
        if (data.size() != BLOCK_SIZE) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("write: data must be exactly 512 bytes"));
            return false;
        }

        _write_byte(0b00000101, stop_tok);
        _write_u32_be(u32Block_num, stop_tok);
        _write(data, stop_tok);

        return _read_byte(stop_tok) == 0x01;
    }

    // ---------------------------------------------------------------------------
    // Configuration
    // ---------------------------------------------------------------------------

    int MMC::get_bus_width() const
    {
        return (_config & 0b1) ? 4 : 1;
    }

    bool MMC::set_bus_width(int iWidth)
    {
        if (iWidth == 1) {
            _config = static_cast<uint8_t>(_config & ~0b1);
        } else if (iWidth == 4) {
            _config = static_cast<uint8_t>(_config | 0b1);
        } else {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("set_bus_width: valid values are 1 or 4"));
            return false;
        }
        return _configure_port();
    }

    bool MMC::_configure_port()
    {
        uint8_t cmd = static_cast<uint8_t>(0b10000000 | (_config & 0x7F));
        _write_byte(cmd);
        if (!_ack("_configure_port")) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Error setting config"));
            return false;
        }
        return true;
    }

} // namespace HydraHAL
