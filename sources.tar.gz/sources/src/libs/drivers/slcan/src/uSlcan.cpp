/**
 * @file  uSlcan.cpp
 * @brief SLCAN driver implementation — WeActStudio USB2CANFDV1 protocol.
 *
 * Wire format reference:
 *   https://github.com/WeActStudio/WeActStudio.USB2CANFDV1 (README.md)
 *
 * Frame encoding/decoding
 * -----------------------
 *
 *   CAN 2.0 standard data  : t<III><L><DD…>[CR]   ID=3 hex, L=1 hex nibble, DD=2 hex/byte
 *   CAN 2.0 extended data  : T<IIIIIIII><L><DD…>[CR]  ID=8 hex
 *   CAN 2.0 std remote     : r<III><L>[CR]
 *   CAN 2.0 ext remote     : R<IIIIIIII><L>[CR]
 *   CANFD std (no BRS)     : d<III><L><DD…>[CR]
 *   CANFD ext (no BRS)     : D<IIIIIIII><L><DD…>[CR]
 *   CANFD std (BRS)        : b<III><L><DD…>[CR]
 *   CANFD ext (BRS)        : B<IIIIIIII><L><DD…>[CR]
 *
 *   L for CANFD = DLC code character:
 *     '0'–'8' = 0–8 bytes, '9'=12, 'A'=16, 'B'=20, 'C'=24, 'D'=32, 'E'=48, 'F'=64
 *
 * Acknowledge
 * -----------
 *   CR  (0x0D) = command accepted
 *   BEL (0x07) = command rejected
 *   EXCEPT "C" (close_channel()) — see that function's comment: no adapter
 *   this driver has been checked against acknowledges Close at all, and
 *   this is a documented general SLCAN-protocol convention, not specific to
 *   any one firmware.
 *
 * Cross-adapter compatibility
 * ----------------------------
 * Everything above (frame TX/RX encoding, S/Y bit-rate presets, M/A mode
 * commands, O/C open/close, F filters, V version) matches the general/
 * "legacy" SLCAN protocol that most SLCAN-speaking firmwares — including
 * Elmue's CANable 2.5 firmware
 * (https://github.com/Elmue/CANable-2.5-firmware-Slcan-and-Candlelight) —
 * implement identically, so this driver works against any of them for the
 * functionality the slcan_plugin/ actually exercises. Two methods on this
 * class are the exception, kept for this driver's original WeActStudio
 * target but not portable to every SLCAN firmware — see their own doc
 * comments in uSlcan.hpp: set_enhance_mode() ("H" command) and
 * get_error_state() (a synchronous "E" query some firmwares, Elmue's
 * included, don't implement — errors are push-only events there). Neither
 * is called anywhere in slcan_plugin/.
 */
#include "uSlcan.hpp"

#include "uCanFrame.hpp"
#include "uLogger.hpp"
#include "uUart.hpp"

#include <algorithm>
#include <array>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <string>

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
#undef LT_HDR
#endif
#ifdef LOG_HDR
#undef LOG_HDR
#endif

#define LT_HDR  "SLCAN_DRV   |"
#define LOG_HDR LOG_STRING(LT_HDR)

/////////////////////////////////////////////////////////////////////////////////
//                            IMPLEMENTATION                                   //
/////////////////////////////////////////////////////////////////////////////////

// ============================================================================
// Hex helpers
// ============================================================================

static inline char nibble_to_hex(uint8_t u8V)
{
    return (u8V < 10) ? ('0' + u8V) : ('A' + u8V - 10);
}

static inline int hex_to_nibble(char c)
{
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    if (c >= 'A' && c <= 'F') {
        return 10 + (c - 'A');
    }
    if (c >= 'a' && c <= 'f') {
        return 10 + (c - 'a');
    }
    return -1;
}

/** Write @p digits hex characters representing the lower bits of @p value into @p buf. */
static size_t write_hex(uint8_t *pu8Buf, uint32_t u32Value, int iDigits)
{
    for (int i = iDigits - 1; i >= 0; --i) {
        pu8Buf[i] = static_cast<uint8_t>(nibble_to_hex(u32Value & 0x0F));
        u32Value >>= 4;
    }
    return static_cast<size_t>(iDigits);
}

/** Parse @p digits hex characters from @p src into @p out; returns false on bad char. */
static bool read_hex(const uint8_t *pu8Src, int iDigits, uint32_t &u32Out)
{
    u32Out = 0;
    for (int i = 0; i < iDigits; ++i) {
        int n = hex_to_nibble(static_cast<char>(pu8Src[i]));
        if (n < 0) {
            return false;
        }
        u32Out = (u32Out << 4) | static_cast<uint32_t>(n);
    }
    return true;
}

// ============================================================================
// Construction / destruction
// ============================================================================

SLCAN::SLCAN(const std::string &strDevice, uint32_t u32Speed, const std::string &strIdentityLabel)
    : m_uart(std::make_shared<UART>())
    , m_strIdentityLabel(strIdentityLabel)
{
    open(strDevice, u32Speed);
}

SLCAN::~SLCAN()
{
    if (m_channel_open) {
        (void)close_channel();
    }
    close();
}

// ============================================================================
// Port management
// ============================================================================

ICommDriver::Status SLCAN::open(const std::string &strDevice, uint32_t u32Speed)
{
    if (!m_uart) {
        m_uart = std::make_shared<UART>();
    }
    Status s = m_uart->open(strDevice, u32Speed);
    if (s != Status::SUCCESS) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to open UART "); LOG_STRING(strDevice.c_str()));
    }
    return s;
}

ICommDriver::Status SLCAN::close()
{
    if (!m_uart) {
        return Status::SUCCESS;
    }
    return m_uart->close();
}

bool SLCAN::is_open() const
{
    return m_uart && m_uart->is_open();
}

// ============================================================================
// Internal UART helpers
// ============================================================================

ICommDriver::Status SLCAN::uart_write(const uint8_t *pu8Data, size_t len, uint32_t u32Timeout_ms, std::stop_token stop_tok) const
{
    if (!m_uart || !m_uart->is_open()) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("uart_write: port not open"));
        return Status::PORT_ACCESS;
    }
    auto res = m_uart->tout_write(u32Timeout_ms, std::span<const uint8_t>(pu8Data, len), {}, stop_tok);
    if (res.status != Status::SUCCESS) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("uart_write failed: "); LOG_STRING(to_string(res.status).c_str()));
    }
    return res.status;
}

ICommDriver::Status SLCAN::uart_read_line(uint8_t *pu8Buf, size_t buf_size,
                                          size_t &out_len, uint32_t u32Timeout_ms, std::stop_token stop_tok) const
{
    if (!m_uart || !m_uart->is_open()) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("uart_read_line: port not open"));
        return Status::PORT_ACCESS;
    }

    ReadOptions opts;
    opts.mode      = ReadMode::UntilDelimiter;
    opts.delimiter = SLCAN_CR;

    auto res       = m_uart->tout_read(u32Timeout_ms,
                                       std::span<uint8_t>(pu8Buf, buf_size),
                                       opts, {}, stop_tok);
    out_len        = res.bytes_read;
    return res.status;
}

// ============================================================================
// send_command  — write cmd+CR and wait for ACK byte
// ============================================================================

ICommDriver::Status SLCAN::send_command(std::string_view cmd, uint32_t u32Timeout_ms)
{
    // Build command: cmd bytes + CR
    std::array<uint8_t, 64> tx{};
    if (cmd.size() + 1 > tx.size()) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("send_command: cmd too long"));
        return Status::INVALID_PARAM;
    }
    std::memcpy(tx.data(), cmd.data(), cmd.size());
    tx[cmd.size()] = SLCAN_CR;

    LOG_PRINT(LOG_VERBOSE, LOG_HDR; LOG_STRING("CMD >> "); LOG_STRING(std::string(cmd).c_str()));

    Status s = uart_write(tx.data(), cmd.size() + 1, u32Timeout_ms);
    if (s != Status::SUCCESS) {
        return s;
    }

    // Read one-byte ACK: CR (success) or BEL (failure)
    // The adapter echoes CR on success, 0x07 on failure.
    // We read until delimiter=CR or a single-byte read.
    uint8_t ack = 0;
    size_t got  = 0;
    ReadOptions ro;
    ro.mode      = ReadMode::Exact;
    ro.delimiter = SLCAN_CR;
    auto res     = m_uart->tout_read(u32Timeout_ms, std::span<uint8_t>(&ack, 1), ro);
    got          = res.bytes_read;

    if (res.status != Status::SUCCESS || got == 0) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("ACK read failed: "); LOG_STRING(to_string(res.status).c_str()));
        return res.status;
    }

    if (ack == SLCAN_NAK) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("CMD NAK for: "); LOG_STRING(std::string(cmd).c_str()));
        return Status::NACK;
    }
    // Any other byte (including CR) treated as success
    return Status::SUCCESS;
}

// ============================================================================
// send_command_get_response  — write cmd+CR and read text back until CR
// ============================================================================

ICommDriver::Status SLCAN::send_command_get_response(std::string_view cmd, std::string &strResp,
                                                     uint32_t u32Timeout_ms)
{
    std::array<uint8_t, 64> tx{};
    if (cmd.size() + 1 > tx.size()) {
        return Status::INVALID_PARAM;
    }
    std::memcpy(tx.data(), cmd.data(), cmd.size());
    tx[cmd.size()] = SLCAN_CR;

    Status s       = uart_write(tx.data(), cmd.size() + 1, u32Timeout_ms);
    if (s != Status::SUCCESS) {
        return s;
    }

    std::array<uint8_t, 128> rx{};
    size_t got = 0;
    s          = uart_read_line(rx.data(), rx.size(), got, u32Timeout_ms);
    if (s != Status::SUCCESS) {
        return s;
    }

    strResp.assign(reinterpret_cast<char *>(rx.data()), got);
    return Status::SUCCESS;
}

// ============================================================================
// Channel configuration
// ============================================================================

ICommDriver::Status SLCAN::set_bitrate(CanBitrate eRate, uint32_t u32Timeout_ms)
{
    if (m_channel_open) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("set_bitrate called with channel open"));
        return Status::INVALID_PARAM;
    }
    char cmd[4];
    if (static_cast<uint8_t>(eRate) < 10) {
        std::snprintf(cmd, sizeof(cmd), "S%X", static_cast<unsigned>(eRate));
    } else {
        std::snprintf(cmd, sizeof(cmd), "S%X", static_cast<unsigned>(eRate));
    }
    return send_command(cmd, u32Timeout_ms);
}

ICommDriver::Status SLCAN::set_bitrate_custom(uint16_t u16Prescaler, uint16_t u16Seg1, uint16_t u16Seg2, uint8_t u8Sjw,
                                              uint32_t u32Timeout_ms)
{
    if (m_channel_open) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("set_bitrate_custom called with channel open"));
        return Status::INVALID_PARAM;
    }
    char cmd[32];
    // Lowercase "s", decimal, comma-separated — NOT the same letter/format
    // as the uppercase "S" preset command (see set_bitrate() above and this
    // method's doc comment in uSlcan.hpp).
    std::snprintf(cmd, sizeof(cmd), "s%u,%u,%u,%u", u16Prescaler, u16Seg1, u16Seg2, u8Sjw);
    return send_command(cmd, u32Timeout_ms);
}

ICommDriver::Status SLCAN::set_fd_data_rate(CanFdDataRate eRate, uint32_t u32Timeout_ms)
{
    if (m_channel_open) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("set_fd_data_rate called with channel open"));
        return Status::INVALID_PARAM;
    }
    char cmd[4];
    std::snprintf(cmd, sizeof(cmd), "Y%X", static_cast<unsigned>(eRate));
    return send_command(cmd, u32Timeout_ms);
}

ICommDriver::Status SLCAN::set_fd_data_rate_custom(uint16_t u16Prescaler, uint16_t u16Seg1, uint16_t u16Seg2, uint8_t u8Sjw,
                                                   uint32_t u32Timeout_ms)
{
    if (m_channel_open) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("set_fd_data_rate_custom called with channel open"));
        return Status::INVALID_PARAM;
    }
    char cmd[32];
    // Lowercase "y", same format as set_bitrate_custom() above.
    std::snprintf(cmd, sizeof(cmd), "y%u,%u,%u,%u", u16Prescaler, u16Seg1, u16Seg2, u8Sjw);
    return send_command(cmd, u32Timeout_ms);
}

ICommDriver::Status SLCAN::set_mode(CanMode eMode, uint32_t u32Timeout_ms)
{
    if (m_channel_open) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("set_mode called with channel open"));
        return Status::INVALID_PARAM;
    }
    char cmd[4];
    std::snprintf(cmd, sizeof(cmd), "M%u", static_cast<unsigned>(eMode));
    return send_command(cmd, u32Timeout_ms);
}

ICommDriver::Status SLCAN::set_auto_retx(CanAutoRetx eRetx, uint32_t u32Timeout_ms)
{
    if (m_channel_open) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("set_auto_retx called with channel open"));
        return Status::INVALID_PARAM;
    }
    char cmd[4];
    std::snprintf(cmd, sizeof(cmd), "A%u", static_cast<unsigned>(eRetx));
    return send_command(cmd, u32Timeout_ms);
}

ICommDriver::Status SLCAN::set_enhance_mode(SlcanEnhance eMode, uint32_t u32Timeout_ms)
{
    if (m_channel_open) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("set_enhance_mode called with channel open"));
        return Status::INVALID_PARAM;
    }
    char cmd[4];
    std::snprintf(cmd, sizeof(cmd), "H%u", static_cast<unsigned>(eMode));
    return send_command(cmd, u32Timeout_ms);
}

ICommDriver::Status SLCAN::set_std_filter(uint16_t u16Id, uint16_t u16Mask, uint32_t u32Timeout_ms)
{
    if (m_channel_open) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("set_std_filter called with channel open"));
        return Status::INVALID_PARAM;
    }
    char cmd[16];
    // F<id>,<mask> — uppercase F for both standard and extended filters (the
    // adapter tells them apart by the id's magnitude/digit count, not by
    // command letter case); comma-separated hex, no fixed width, no leading
    // zeros — e.g. "F7E8,7FF" (see e.g. Elmue's CANable 2.5 firmware manual's
    // Host Filter examples). NOT "f<3-hex><3-hex>" — that fixed-width,
    // no-separator, lowercase-for-standard scheme is this driver's own
    // earlier invention and isn't a real SLCAN adapter's wire format.
    std::snprintf(cmd, sizeof(cmd), "F%X,%X", u16Id & 0x7FFu, u16Mask & 0x7FFu);
    return send_command(cmd, u32Timeout_ms);
}

ICommDriver::Status SLCAN::set_ext_filter(uint32_t u32Id, uint32_t u32Mask, uint32_t u32Timeout_ms)
{
    if (m_channel_open) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("set_ext_filter called with channel open"));
        return Status::INVALID_PARAM;
    }
    char cmd[24];
    // Same F<id>,<mask> format as set_std_filter() — see that function's
    // comment. A 29-bit id naturally needs more hex digits than an 11-bit
    // one, which is how the adapter distinguishes std from ext.
    std::snprintf(cmd, sizeof(cmd), "F%X,%X", u32Id & 0x1FFFFFFFu, u32Mask & 0x1FFFFFFFu);
    return send_command(cmd, u32Timeout_ms);
}

ICommDriver::Status SLCAN::clear_filters(uint32_t u32Timeout_ms)
{
    if (m_channel_open) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("clear_filters called with channel open"));
        return Status::INVALID_PARAM;
    }
    // "f" with no arguments — see set_std_filter()'s doc comment.
    return send_command("f", u32Timeout_ms);
}

// ============================================================================
// Channel open / close
// ============================================================================

ICommDriver::Status SLCAN::open_channel(uint32_t u32Timeout_ms)
{
    Status s = send_command("O", u32Timeout_ms);
    if (s == Status::SUCCESS) {
        m_channel_open = true;
        LOG_PRINT(LOG_DEBUG, LOG_HDR; LOG_STRING("CAN channel opened"));
    }
    return s;
}

ICommDriver::Status SLCAN::close_channel(uint32_t u32Timeout_ms)
{
    // Close is special: per the SLCAN protocol convention (explicitly
    // documented by e.g. Elmue's CANable 2.5 firmware manual — "the command
    // 'Close' is the only command that does not send a feedback... it never
    // sends a feedback, [even] as the legacy command"), the adapter does
    // NOT reply with CR/BEL to "C". send_command()'s ack-wait would block
    // for the full timeout on every single call (this driver's destructor
    // calls close_channel() unconditionally whenever the channel is open),
    // so this writes the command directly instead of going through
    // send_command(). This also means a truly bad/rejected Close cannot be
    // distinguished from a good one at the protocol level — same limitation
    // every other SLCAN host implementation has.
    std::array<uint8_t, 2> tx{static_cast<uint8_t>('C'), SLCAN_CR};
    Status s       = uart_write(tx.data(), tx.size(), u32Timeout_ms);
    m_channel_open = false; // mark closed even on error to avoid loops
    LOG_PRINT(LOG_DEBUG, LOG_HDR; LOG_STRING("CAN channel closed"));
    return s;
}

// ============================================================================
// Diagnostic queries
// ============================================================================

ICommDriver::Status SLCAN::get_version(std::string &strVersion, uint32_t u32Timeout_ms)
{
    return send_command_get_response("V", strVersion, u32Timeout_ms);
}

ICommDriver::Status SLCAN::get_error_state(std::string &strError_str, uint32_t u32Timeout_ms)
{
    return send_command_get_response("E", strError_str, u32Timeout_ms);
}

// ============================================================================
// Frame encoding (static)
// ============================================================================

size_t SLCAN::encode_frame(const CanFrame &sFrame, std::span<uint8_t> out)
{
    if (out.size() < SLCAN_MAX_FRAME_LEN) {
        return 0;
    }

    uint8_t *p = out.data();
    size_t n   = 0;

    // Select command character
    char cmd;
    if (sFrame.is_canfd) {
        if (sFrame.is_extended) {
            cmd = sFrame.brs ? 'B' : 'D';
        } else {
            cmd = sFrame.brs ? 'b' : 'd';
        }
    } else {
        if (sFrame.is_remote) {
            cmd = sFrame.is_extended ? 'R' : 'r';
        } else {
            cmd = sFrame.is_extended ? 'T' : 't';
        }
    }

    p[n++] = static_cast<uint8_t>(cmd);

    // ID field
    if (sFrame.is_extended) {
        n += write_hex(p + n, sFrame.id & 0x1FFFFFFFu, 8);
    } else {
        n += write_hex(p + n, sFrame.id & 0x7FFu, 3);
    }

    // DLC / length character
    uint8_t dlc = sFrame.is_canfd ? ucanframe::len_to_dlc(sFrame.len) : sFrame.len;

    // For CANFD the DLC character is the hex nibble ('0'–'F')
    if (sFrame.is_canfd) {
        if (dlc < 10) {
            p[n++] = static_cast<uint8_t>('0' + dlc);
        } else {
            p[n++] = static_cast<uint8_t>('A' + dlc - 10);
        }
    } else {
        // CAN 2.0: DLC is 0–8, printed as single decimal digit
        p[n++] = static_cast<uint8_t>('0' + (dlc & 0x0F));
    }

    // Data bytes (not for remote frames)
    if (!sFrame.is_remote) {
        uint8_t data_len = sFrame.is_canfd ? ucanframe::dlc_to_len(dlc) : sFrame.len;
        for (uint8_t i = 0; i < data_len; ++i) {
            p[n++] = static_cast<uint8_t>(nibble_to_hex((sFrame.data[i] >> 4) & 0x0F));
            p[n++] = static_cast<uint8_t>(nibble_to_hex(sFrame.data[i] & 0x0F));
        }
    }

    p[n++] = SLCAN_CR;
    return n;
}

// ============================================================================
// Frame decoding (static)
// ============================================================================

bool SLCAN::decode_rx_frame(const uint8_t *pu8Line, size_t len, CanFrame &sFrame)
{
    if (!pu8Line || len < 5) {
        return false;
    }

    // Strip trailing CR / whitespace
    while (len > 0 && (pu8Line[len - 1] == '\r' || pu8Line[len - 1] == '\n' || pu8Line[len - 1] == 0)) {
        --len;
    }
    if (len < 4) {
        return false;
    }

    char cmd         = static_cast<char>(pu8Line[0]);
    bool is_extended = false;
    bool is_remote   = false;
    bool is_canfd    = false;
    bool brs         = false;
    int id_digits    = 0;

    switch (cmd) {
    case 't':
        is_extended = false;
        is_remote   = false;
        is_canfd    = false;
        id_digits   = 3;
        break;
    case 'T':
        is_extended = true;
        is_remote   = false;
        is_canfd    = false;
        id_digits   = 8;
        break;
    case 'r':
        is_extended = false;
        is_remote   = true;
        is_canfd    = false;
        id_digits   = 3;
        break;
    case 'R':
        is_extended = true;
        is_remote   = true;
        is_canfd    = false;
        id_digits   = 8;
        break;
    case 'd':
        is_extended = false;
        is_remote   = false;
        is_canfd    = true;
        brs         = false;
        id_digits   = 3;
        break;
    case 'D':
        is_extended = true;
        is_remote   = false;
        is_canfd    = true;
        brs         = false;
        id_digits   = 8;
        break;
    case 'b':
        is_extended = false;
        is_remote   = false;
        is_canfd    = true;
        brs         = true;
        id_digits   = 3;
        break;
    case 'B':
        is_extended = true;
        is_remote   = false;
        is_canfd    = true;
        brs         = true;
        id_digits   = 8;
        break;
    default:
        return false;
    }

    const uint8_t *pos = pu8Line + 1;
    size_t remaining   = len - 1;

    if (remaining < static_cast<size_t>(id_digits + 1)) {
        return false;
    }

    // Parse ID
    uint32_t id = 0;
    if (!read_hex(pos, id_digits, id)) {
        return false;
    }
    pos += id_digits;
    remaining -= id_digits;

    // Parse DLC character
    char dlc_char = static_cast<char>(*pos);
    pos++;
    remaining--;

    uint8_t dlc_code = 0;
    if (dlc_char >= '0' && dlc_char <= '9') {
        dlc_code = static_cast<uint8_t>(dlc_char - '0');
    } else if (dlc_char >= 'A' && dlc_char <= 'F') {
        dlc_code = static_cast<uint8_t>(10 + dlc_char - 'A');
    } else if (dlc_char >= 'a' && dlc_char <= 'f') {
        dlc_code = static_cast<uint8_t>(10 + dlc_char - 'a');
    } else {
        return false;
    }

    uint8_t data_len = is_canfd ? ucanframe::dlc_to_len(dlc_code) : (dlc_code <= 8 ? dlc_code : 8);

    // Parse data bytes (not for remote frames)
    std::array<uint8_t, 64> data{};
    if (!is_remote) {
        if (remaining < static_cast<size_t>(data_len * 2)) {
            return false;
        }
        for (uint8_t i = 0; i < data_len; ++i) {
            uint32_t byte_val = 0;
            if (!read_hex(pos, 2, byte_val)) {
                return false;
            }
            data[i] = static_cast<uint8_t>(byte_val);
            pos += 2;
        }
    }

    // Populate output struct
    sFrame.is_extended = is_extended;
    sFrame.is_remote   = is_remote;
    sFrame.is_canfd    = is_canfd;
    sFrame.brs         = brs;
    sFrame.id          = id;
    sFrame.dlc         = dlc_code;
    sFrame.len         = data_len;
    sFrame.data        = data;

    return true;
}

// ============================================================================
// send_frame
// ============================================================================

ICommDriver::Status SLCAN::send_frame(const CanFrame &sFrame, uint32_t u32Timeout_ms, std::stop_token stop_tok)
{
    if (!m_channel_open) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("send_frame: channel not open"));
        return Status::PORT_ACCESS;
    }

    std::array<uint8_t, SLCAN_MAX_FRAME_LEN> tx{};
    size_t n = encode_frame(sFrame, std::span<uint8_t>(tx));
    if (n == 0) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("send_frame: encode failed"));
        return Status::INVALID_PARAM;
    }

    LOG_PRINT(LOG_VERBOSE, LOG_HDR;
              LOG_STRING("TX id="); LOG_HEX32(sFrame.id);
              LOG_STRING(" len="); LOG_UINT8(sFrame.len);
              LOG_STRING(sFrame.is_extended ? " EXT" : " STD");
              LOG_STRING(sFrame.is_canfd ? " CANFD" : " CAN");
              LOG_STRING(sFrame.brs ? " BRS" : ""));

    // Write the encoded ASCII frame
    Status ws = uart_write(tx.data(), n, u32Timeout_ms, stop_tok);
    if (ws != Status::SUCCESS) {
        return ws;
    }

    // Read single ACK byte
    uint8_t ack = 0;
    ReadOptions ro;
    ro.mode  = ReadMode::Exact;
    auto res = m_uart->tout_read(u32Timeout_ms, std::span<uint8_t>(&ack, 1), ro, {}, stop_tok);

    if (res.status != Status::SUCCESS || res.bytes_read == 0) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("send_frame: ACK timeout"));
        return (res.status == Status::READ_TIMEOUT) ? Status::WRITE_TIMEOUT : Status::WRITE_ERROR;
    }
    if (ack == SLCAN_NAK) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("send_frame: NAK"));
        return Status::NACK;
    }
    return Status::SUCCESS;
}

// ============================================================================
// receive_frame
// ============================================================================

ICommDriver::Status SLCAN::receive_frame(CanFrame &sFrame, uint32_t u32Timeout_ms, std::stop_token stop_tok)
{
    std::array<uint8_t, SLCAN_RX_BUF_LEN> buf{};
    size_t got = 0;

    Status s   = uart_read_line(buf.data(), buf.size(), got, u32Timeout_ms, stop_tok);
    if (s != Status::SUCCESS) {
        if (s == Status::READ_TIMEOUT) {
            return Status::READ_TIMEOUT;
        }
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("receive_frame: read error: "); LOG_STRING(to_string(s).c_str()));
        return Status::READ_ERROR;
    }

    if (!decode_rx_frame(buf.data(), got, sFrame)) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("receive_frame: decode failed (len="); LOG_SIZET(got); LOG_STRING(")"));
        return Status::READ_ERROR;
    }

    LOG_PRINT(LOG_VERBOSE, LOG_HDR;
              LOG_STRING("RX id="); LOG_HEX32(sFrame.id);
              LOG_STRING(" len="); LOG_UINT8(sFrame.len);
              LOG_STRING(sFrame.is_extended ? " EXT" : " STD");
              LOG_STRING(sFrame.is_canfd ? " CANFD" : " CAN"));

    return Status::SUCCESS;
}

// ============================================================================
// ICommDriver generic interface
// ============================================================================

SLCAN::ReadResult SLCAN::tout_read(uint32_t u32ReadTimeout,
                                   std::span<uint8_t> buffer,
                                   const ReadOptions & /*options*/,
                                   std::string_view /*xtra_params*/,
                                   std::stop_token /*stop_tok*/) const
{
    ReadResult result;

    if (!m_uart || !m_uart->is_open()) {
        result.status = Status::PORT_ACCESS;
        return result;
    }

    // Delegate: read one SLCAN line (until CR) into the caller's buffer
    ReadOptions ro;
    ro.mode                 = ReadMode::UntilDelimiter;
    ro.delimiter            = SLCAN_CR;

    auto res                = m_uart->tout_read(u32ReadTimeout, buffer, ro);
    result.status           = res.status;
    result.bytes_read       = res.bytes_read;
    result.found_terminator = res.found_terminator;
    return result;
}

SLCAN::WriteResult SLCAN::tout_write(uint32_t u32WriteTimeout,
                                     std::span<const uint8_t> buffer,
                                     std::string_view /*xtra_params*/,
                                     std::stop_token /*stop_tok*/) const
{
    WriteResult result;

    if (!m_uart || !m_uart->is_open()) {
        result.status = Status::PORT_ACCESS;
        return result;
    }

    auto res             = m_uart->tout_write(u32WriteTimeout, buffer);
    result.status        = res.status;
    result.bytes_written = res.bytes_written;
    return result;
}
