#ifndef U_ENC28J60_NET_DRIVER_H
#define U_ENC28J60_NET_DRIVER_H

#include "ICommDriver.hpp"

#include <cstdint>
#include <mutex>
#include <stop_token>
#include <string>

#ifdef _WIN32
// No public API here actually needs <sys/socket.h>'s declarations (the
// socket fd is stored as a plain int), so on Windows this is simply
// omitted rather than swapped for <winsock2.h> — that keeps this header
// from dragging windows.h's macro soup into every translation unit that
// includes it. uEnc28J60NetWindows.cpp/uEnc28J60NetCommon.cpp pull in
// <winsock2.h> themselves where the actual socket calls live.
#else
#include <sys/socket.h>
#endif

// ============================================================================
// PUBLIC INTERFACE
// ============================================================================

/**
 * @brief Network Driver that communicates with a remote ENC28J60 board.
 *
 * Connects to a TCP server running on the ENC28J60 board. The board firmware
 * manages the TCP/IP stack (e.g., uIP/lwIP) and SPI interface.
 *
 * @par Protocol
 * Similar to W5500Net, but with simpler packet handling due to lack of hardware socket management.
 *
 * Command Format (Desktop -> Board):
 * | Byte 0 | Byte 1-2 (Big Endian) | Payload... |
 * | Cmd ID | Length N             | N bytes    |
 *
 * Cmd IDs:
 * 0x01: INIT (Initialize stack if not done)
 * 0x02: SEND (Send raw TCP payload to the active connection)
 * 0x03: RECV (Retrieve available TCP payload)
 * 0x04: CLOSE (Close the current TCP connection)
 * 0x05: GET_STATUS (Get current TCP state)
 */
class Enc28J60Net : public ICommDriver {
    public:
        static constexpr uint32_t ENC28J60NET_TIMEOUT_MS = 2000;
        static constexpr size_t ENC28J60NET_MAX_BUF      = 1460; // MTU - Header overhead

        Enc28J60Net()                                    = default;

        /**
         * @brief Construct with a display label for the GUI comm-dump panel
         * (see describeConnection()), supplied separately from ipAddr/u16Port
         * — connection itself is still established via open().
         */
        explicit Enc28J60Net(std::string strIdentityLabel)
            : m_strIdentityLabel(std::move(strIdentityLabel))
        {
        }

        Status open(const std::string &strIpAddr, uint16_t u16Port = 5000);
        Status close();
        bool is_open() const override;

        /**
         * @brief Describe this connection for the GUI comm-dump panel.
         * xtra_params is ignored (single active TCP connection through the board).
         * Falls back to "<ip>:<port>" when no identity label was supplied.
         */
        CommDetails describeConnection(std::string_view /*xtra_params*/ = {}) const override
        {
            if (!m_strIdentityLabel.empty()) {
                return commdump_details(CommFamily::NET, m_strIdentityLabel);
            }
            return commdump_details(CommFamily::NET,
                                    m_strServerIp + ":" + std::to_string(m_u16Port));
        }

        ReadResult tout_read(uint32_t u32ReadTimeout,
                             std::span<uint8_t> buffer,
                             const ReadOptions &sOptions,
                             std::string_view xtra_params = {},
                             std::stop_token stop_tok     = {}) const override;

        WriteResult tout_write(uint32_t u32WriteTimeout,
                               std::span<const uint8_t> buffer,
                               std::string_view xtra_params = {},
                               std::stop_token stop_tok     = {}) const override;

    private:
        mutable int m_iSocketFd = -1;
        mutable std::mutex m_mutex;

        std::string m_strServerIp;
        uint16_t m_u16Port = 0;
        std::string m_strIdentityLabel; /**< GUI comm-dump display label, see describeConnection(). */

        Status receive_packet(std::span<uint8_t> response_buffer, size_t max_len, size_t &bytes_read) const;
        Status send_command(uint8_t u8Cmd_id, const uint8_t *pu8Payload, size_t payload_len) const;
};

#endif // U_ENC28J60_NET_DRIVER_H
