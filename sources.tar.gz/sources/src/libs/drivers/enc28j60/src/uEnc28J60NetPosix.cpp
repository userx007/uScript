#include "uEnc28J60Net.hpp"
#include "uLogger.hpp"

#include <arpa/inet.h>
#include <cstring>
#include <fcntl.h>
#include <mutex>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdint.h>
#include <string>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
#undef LT_HDR
#endif
#ifdef LOG_HDR
#undef LOG_HDR
#endif

#define LT_HDR  "ENC28J60_DRV|"
#define LOG_HDR LOG_STRING(LT_HDR)

/////////////////////////////////////////////////////////////////////////////////
//                            IMPLEMENTATION                                   //
/////////////////////////////////////////////////////////////////////////////////

Enc28J60Net::Status Enc28J60Net::open(const std::string &strIpAddr, uint16_t u16Port)
{
    std::lock_guard<std::mutex> lock(m_mutex);

    if (m_iSocketFd != -1) {
        ::close(m_iSocketFd);
    }

    m_strServerIp = strIpAddr;
    m_u16Port     = u16Port;

    m_iSocketFd   = ::socket(AF_INET, SOCK_STREAM, 0);
    if (m_iSocketFd < 0) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to create socket"));
        return Status::PORT_ACCESS;
    }

    int flag = 1;
    if (::setsockopt(m_iSocketFd, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag)) < 0) {
        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("Failed to set TCP_NODELAY"));
    }

    struct timeval tv;
    tv.tv_sec  = 2;
    tv.tv_usec = 0;
    ::setsockopt(m_iSocketFd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    struct sockaddr_in server_addr;
    std::memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port   = htons(u16Port);

    if (::inet_pton(AF_INET, strIpAddr.c_str(), &server_addr.sin_addr) <= 0) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid IP address: "); LOG_STRING(strIpAddr.c_str()));
        ::close(m_iSocketFd);
        m_iSocketFd = -1;
        return Status::INVALID_PARAM;
    }

    if (::connect(m_iSocketFd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Connection failed to "); LOG_STRING(strIpAddr.c_str()));
        ::close(m_iSocketFd);
        m_iSocketFd = -1;
        return Status::PORT_ACCESS;
    }

    tv.tv_sec  = 0;
    tv.tv_usec = 0;
    ::setsockopt(m_iSocketFd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    LOG_PRINT(LOG_DEBUG, LOG_HDR; LOG_STRING("Connected to ENC28J60 server at "); LOG_STRING(strIpAddr.c_str()));

    return Status::SUCCESS;
}

Enc28J60Net::Status Enc28J60Net::close()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    if (m_iSocketFd != -1) {
        ::shutdown(m_iSocketFd, SHUT_RDWR);
        ::close(m_iSocketFd);
        m_iSocketFd = -1;
    }
    return Status::SUCCESS;
}

bool Enc28J60Net::is_open() const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_iSocketFd != -1;
}
