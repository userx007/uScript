#ifndef U_LAN8720_NET_DRIVER_H
#define U_LAN8720_NET_DRIVER_H

#include "ICommDriver.hpp"

#include <cstdint>
#include <mutex>
#include <stop_token>
#include <string>

#ifdef _WIN32
// See uEnc28J60Net.hpp's identical comment: nothing in this header
// itself needs socket declarations, so they're simply omitted on
// Windows rather than swapped for <winsock2.h>.
#else
#include <sys/socket.h>
#endif

/**
 * @brief Network Driver that communicates with a remote LAN8720 board.
 *
 * Connects to a TCP server running on the LAN8720 board (managed by an MCU).
 * The LAN8720 acts as the physical Ethernet interface for the MCU.
 *
 * @par Protocol
 * Uses the same binary protocol as W5500Net/Enc28J60Net for consistency.
 *
 * Command Format (Desktop -> Board):
 * | Byte 0 | Byte 1-2 (Big Endian) | Payload... |
 * | Cmd ID | Length N             | N bytes    |
 *
 * Cmd IDs:
 * 0x01: INIT (Initialize PHY if needed)
 * 0x02: SEND (Send TCP payload)
 * 0x03: RECV (Retrieve TCP payload)
 * 0x04: CLOSE (Close TCP connection)
 * 0x05: GET_STATUS (Get PHY status/link state)
 */
class Lan8720Net : public ICommDriver {
    public:
        static constexpr uint32_t LAN8720NET_TIMEOUT_MS = 2000;
        static constexpr size_t LAN8720NET_MAX_BUF      = 1460; // Standard MTU for Ethernet

        Lan8720Net()                                    = default;

        /**
         * @brief Construct with a display label for the GUI comm-dump panel
         * (see describeConnection()), supplied separately from ipAddr/u16Port
         * — connection itself is still established via open().
         */
        explicit Lan8720Net(std::string strIdentityLabel)
            : m_strIdentityLabel(std::move(strIdentityLabel))
        {
        }

        Status open(const std::string &strIpAddr, uint16_t u16Port = 5000);
        Status close();
        bool is_open() const override;

        /**
         * @brief Describe this connection for the GUI comm-dump panel.
         * xtra_params is ignored (single active TCP connection through the board).
         * Falls back to "<ip>:<port>" when no identity label was supplied.
         */
        CommDetails describeConnection(std::string_view /*xtra_params*/ = {}) const override
        {
            if (!m_strIdentityLabel.empty()) {
                return commdump_details(CommFamily::NET, m_strIdentityLabel);
            }
            return commdump_details(CommFamily::NET,
                                    m_strServerIp + ":" + std::to_string(m_u16Port));
        }

        ReadResult tout_read(uint32_t u32ReadTimeout,
                             std::span<uint8_t> buffer,
                             const ReadOptions &sOptions,
                             std::string_view xtra_params = {},
                             std::stop_token stop_tok     = {}) const override;

        WriteResult tout_write(uint32_t u32WriteTimeout,
                               std::span<const uint8_t> buffer,
                               std::string_view xtra_params = {},
                               std::stop_token stop_tok     = {}) const override;

    private:
        mutable int m_iSocketFd = -1;
        mutable std::mutex m_mutex;

        std::string m_strServerIp;
        uint16_t m_u16Port = 0;
        std::string m_strIdentityLabel; /**< GUI comm-dump display label, see describeConnection(). */

        Status receive_packet(std::span<uint8_t> response_buffer, size_t max_len, size_t &bytes_read) const;
        Status send_command(uint8_t u8Cmd_id, const uint8_t *pu8Payload, size_t payload_len) const;
};

#endif // U_LAN8720_NET_DRIVER_H
