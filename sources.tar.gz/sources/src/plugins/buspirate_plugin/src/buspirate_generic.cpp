#include "buspirate_generic.hpp"

#include "ICommDriver.hpp"
#include "bithandling.h"
#include "buspirate_plugin.hpp"
#include "uFile.hpp"
#include "uHexdump.hpp"
#include "uHexlify.hpp"
#include "uLogger.hpp"
#include "uNumeric.hpp"
#include "uSharedConfig.hpp"
#include "uString.hpp"
#include "uUart.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <span>
#include <stop_token>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#if defined(_WIN32) || defined(_WIN64)
#include <sys/stat.h>
#else
#include <sys/stat.h>
#include <unistd.h>
#endif

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
#undef LT_HDR
#endif
#ifdef LOG_HDR
#undef LOG_HDR
#endif

#define LT_HDR  "BPIRATE_GEN |"
#define LOG_HDR LOG_STRING(LT_HDR)

///////////////////////////////////////////////////////////////////
//            PUBLIC INTERFACES IMPLEMENTATION                   //
///////////////////////////////////////////////////////////////////

/* ============================================================================================
    BuspiratePlugin::getModuleCmdsMap
============================================================================================ */

ModuleCommandsMap<BuspiratePlugin> *BuspiratePlugin::getModuleCmdsMap(const std::string &strModule) const
{
    ModuleCommandsMap<BuspiratePlugin> *pCmdMap                  = nullptr;
    typename CommandsMapsMap<BuspiratePlugin>::const_iterator it = m_mapCommandsMaps.find(strModule);

    if (it != m_mapCommandsMaps.end()) {
        pCmdMap = it->second;
    }

    return pCmdMap;

} /* getModuleCmdsMap() */

/* ============================================================================================
    BuspiratePlugin::getModuleSpeedsMap
============================================================================================ */

ModuleSpeedMap *BuspiratePlugin::getModuleSpeedsMap(const std::string &strModule) const
{
    ModuleSpeedMap *pSpeedMap = nullptr;

    for (auto it1 : m_mapSpeedsMaps) {
        if (it1.first == strModule) {
            pSpeedMap = it1.second;
        }
    }

    return pSpeedMap;

} /* getModuleSpeedsMap() */

/* ============================================================================================
 0100wxyz – Configure peripherals w=power, x=pullups, y=AUX, z=CS

Enable (1) and disable (0) Bus Pirate peripherals and pins.
w enables the power supplies,
x toggles the on-board pull-up resistors,
y sets the state of the auxiliary pin,
z sets the chip select pin.
Features not present in a specific hardware version are ignored. Bus Pirate responds 0×01 on success.

Note: CS pin always follows the current HiZ pin configuration.
AUX is always a normal pin output (0=GND, 1=3.3volts).
============================================================================================ */

bool BuspiratePlugin::generic_set_peripheral(const std::string &strArgs, std::stop_token st) const
{
    bool bRetVal    = true;
    uint8_t request = 0x40;

    if ("help" == strArgs) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("w/W - power supply: w(off) W(on)"));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("p/P - pull-ups resistors: p(off) P(on)"));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("a/A - AUX: a(GND) A(3.3V)"));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("c/C - CS: c C"));
    } else if ("?" == strArgs) {
        LOG_PRINT(LOG_WERBOSE, LOG_STRING("Peripherals:"); LOG_UINT8(request));
    } else {
        // power
        if (ustring::containsChar(strArgs, 'W')) {
            BIT_SET(request, 3);
        }
        if (ustring::containsChar(strArgs, 'w')) {
            BIT_CLEAR(request, 3);
        }
        // pull-ups
        if (ustring::containsChar(strArgs, 'P')) {
            BIT_SET(request, 2);
        }
        if (ustring::containsChar(strArgs, 'p')) {
            BIT_CLEAR(request, 2);
        }
        // AUX
        if (ustring::containsChar(strArgs, 'A')) {
            BIT_SET(request, 1);
        }
        if (ustring::containsChar(strArgs, 'a')) {
            BIT_CLEAR(request, 1);
        }
        // CS
        if (ustring::containsChar(strArgs, 'C')) {
            BIT_SET(request, 0);
        }
        if (ustring::containsChar(strArgs, 'c')) {
            BIT_CLEAR(request, 0);
        }
        LOG_PRINT(LOG_WERBOSE, LOG_STRING("Peripherals:"); LOG_UINT8(request));

        if (m_bIsEnabled) {
            uint8_t response[sizeof(m_positive_response)] = {};
            bRetVal                                       = generic_uart_send_receive(std::span<uint8_t>(&request, 1), numeric::byte2span(response), numeric::byte2span(m_positive_response), true, st);
        }
    }

    return bRetVal;

} /* generic_set_peripheral() */

/* ============================================================================================
    BuspiratePlugin::generic_write_read_data
============================================================================================ */

bool BuspiratePlugin::generic_write_read_data(const uint8_t u8Cmd, const std::string &strArgs, std::stop_token st) const
{
    bool bRetVal = true;

    if (strArgs.empty()) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Invalid args"));
        bRetVal = false;
    } else if ("help" == strArgs) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use: [data][:rdsize]. Example: DEADCODE | BAADFOOD:7 | :7"));
    } else {
        std::vector<std::string> vectParams;
        std::vector<uint8_t> request;
        std::vector<uint8_t> response;
        size_t szReadSize = 0;

        if (CHAR_SEPARATOR_COLON == strArgs[0]) { // only read
            bRetVal = numeric::str2sizet(strArgs.substr(1), szReadSize);
        } else { // write and optional read
            ustring::tokenize(strArgs, CHAR_SEPARATOR_COLON, vectParams);
            if (!vectParams.empty()) {
                bRetVal = hexutils::stringUnhexlify(vectParams[0], request);
                if (bRetVal && vectParams.size() == 2) {
                    bRetVal = numeric::str2sizet(vectParams[1], szReadSize);
                }
            }
        }

        if (true == bRetVal) {
            if (true == m_bIsEnabled) {
                response.resize(szReadSize); // allocate response buffer
                bRetVal = generic_internal_write_read_data(
                    u8Cmd,
                    std::span<const uint8_t>{request},
                    std::span<uint8_t>{response},
                    false,
                    st);
            }
        }
    }

    return bRetVal;

} /* generic_write_read_data() */

/* ============================================================================================
    BuspiratePlugin::generic_write_read_file
============================================================================================ */

bool BuspiratePlugin::generic_write_read_file(const uint8_t u8Cmd, const std::string &strArgs, std::stop_token st) const
{
    bool bRetVal = true;

    if (strArgs.empty()) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Invalid args"));
        bRetVal = false;
    } else if ("help" == strArgs) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use: filename[:wrsize][:rdsize]. Example: file | file:100 | file:100:100"));
    } else {
        std::vector<std::string> vectParams;
        ustring::tokenize(strArgs, CHAR_SEPARATOR_COLON, vectParams);

        if (vectParams.size() >= 1) {
            size_t szWriteChunkSize = BP_WRITE_MAX_CHUNK_SIZE;
            size_t szReadChunkSize  = BP_WRITE_MAX_CHUNK_SIZE;

            if (vectParams.size() >= 2) {
                size_t szWriteSize = 0;
                if (true == (bRetVal = numeric::str2sizet(vectParams[1], szWriteSize))) {
                    if (0 != szWriteSize) {
                        szWriteChunkSize = szWriteSize;
                        LOG_PRINT(LOG_DEBUG, LOG_HDR; LOG_STRING("Write chunk size:"); LOG_SIZET(szWriteChunkSize));
                    } else {
                        LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("Invalid write chunk size. Use default:"); LOG_SIZET(szWriteChunkSize));
                    }

                    if (3 == vectParams.size()) {
                        size_t szReadSize = 0;
                        if (true == (bRetVal = numeric::str2sizet(vectParams[2], szReadSize))) {
                            if (0 != szReadSize) {
                                szReadChunkSize = szReadSize;
                                LOG_PRINT(LOG_DEBUG, LOG_HDR; LOG_STRING("Read chunk size:"); LOG_SIZET(szReadChunkSize));
                            } else {
                                LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("Invalid read chunk size. Use default:"); LOG_SIZET(szReadChunkSize));
                            }
                        }
                    } else {
                        szReadChunkSize = 0;
                        LOG_PRINT(LOG_DEBUG, LOG_HDR; LOG_STRING("Read chunk size(unset):"); LOG_SIZET(szReadChunkSize));
                    }
                }
            }
            if (true == bRetVal) {
                if (true == m_bIsEnabled) {
                    bRetVal = generic_internal_write_read_file(u8Cmd, vectParams[0], szWriteChunkSize, szReadChunkSize, st);
                }
            }
        }
    }

    return bRetVal;

} /* generic_write_read_file() */

/* ============================================================================================
    BuspiratePlugin::generic_wire_write_data (rawwire onewire)
============================================================================================ */

bool BuspiratePlugin::generic_wire_write_data(std::span<const uint8_t> data, std::stop_token st) const
{
    static constexpr size_t szBufflen = 17;

    if (data.size() + 1 >= szBufflen) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Length too big (max 16):"); LOG_SIZET(data.size()));
        return false;
    }

    if (false == m_bIsEnabled) {
        return true;
    }

    std::array<uint8_t, szBufflen> request = {}; // zero-initialized
    request[0]                             = 0x10 | static_cast<uint8_t>(data.size() - 1);
    std::copy(data.begin(), data.end(), request.begin() + 1);

    return generic_uart_send_receive(std::span<uint8_t>{request.data(), data.size() + 1}, std::span<uint8_t>{}, std::span<const uint8_t>{}, true, st);

} /* generic_wire_write_data() */

/* ============================================================================================
    BuspiratePlugin::generic_uart_send_receive

    New design with separate response buffer and expected pattern:
    - request: data to send
    - response: writable buffer to receive data (can be empty if no response expected)
    - expected: read-only pattern to validate against (can be empty to skip validation)
    - strictCompare: if true and expected is provided, validates received data

    Example usage:
    uint8_t response[8] = {};  // Buffer to receive data
    bRetVal = generic_uart_send_receive(
        numeric::byte2span(request),
        numeric::byte2span(response),
        numeric::byte2span(m_positive_response)
    );

============================================================================================ */

bool BuspiratePlugin::generic_uart_send_receive(std::span<const uint8_t> request, std::span<uint8_t> response, std::span<const uint8_t> expected, bool bStrictCompare, std::stop_token st) const
{
    // Determine if we should send.
    // An empty span means receive-only (e.g. draining ACK/NACK bytes after a bulk write).
    // NOTE: must NOT check byte values — a span of 0x00 bytes is a valid payload
    //       (e.g. the 20 x 0x00 sent to enter bitbang mode).
    bool shouldSend    = !request.empty();

    // Determine if we should receive
    bool shouldReceive = response.size() > 0;

    // Determine if we should compare - now uses the separate expected parameter
    bool shouldCompare = bStrictCompare && expected.size() > 0;

    // Send
    if (shouldSend) {
        hexutils::logHexdump(LOG_VERBOSE, "Sending Request:", "SAoC", request);

        auto writeResult = m_drvUart.tout_write(m_sIniValues.u32WriteTimeout, request, std::string_view{}, st);
        if (writeResult.status != ICommDriver::Status::SUCCESS) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("UART write failed:");
                      LOG_STRING(ICommDriver::to_string(writeResult.status));
                      LOG_STRING("Bytes written:"); LOG_SIZET(writeResult.bytes_written));
            return false;
        }
    } else {
        LOG_PRINT(LOG_WERBOSE, LOG_HDR; LOG_STRING("Request not initialized — skipping send"));
    }

    // Receive
    if (shouldReceive) {
        ICommDriver::ReadOptions options;
        options.mode       = ICommDriver::ReadMode::Exact; // Read exact bytes

        auto readResult    = m_drvUart.tout_read(m_sIniValues.u32ReadTimeout, response, options, std::string_view{}, st);
        size_t szBytesRead = readResult.bytes_read;

        if (readResult.status != ICommDriver::Status::SUCCESS) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("UART read failed:");
                      LOG_STRING(ICommDriver::to_string(readResult.status));
                      LOG_STRING("Bytes read:"); LOG_SIZET(szBytesRead));
            return false;
        }
        // only dump what was received
        const size_t szSafeBytesRead = std::min(szBytesRead, response.size());
        hexutils::logHexdump(LOG_VERBOSE, "Received Answer:", "SAoC", response.first(szSafeBytesRead));

        // Compare - now uses the separate expected parameter
        if (shouldCompare) {
            hexutils::logHexdump(LOG_VERBOSE, "Expected Answer:", "SAoC", expected);

            if (szBytesRead < expected.size()) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Received fewer bytes than expected"));
                return false;
            }

            if (!std::equal(expected.begin(), expected.end(), response.begin())) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Received data does not match expected"));
                return false;
            }

            LOG_PRINT(LOG_WERBOSE, LOG_HDR; LOG_STRING("Expected data matched successfully"));
        } else {
            LOG_PRINT(LOG_WERBOSE, LOG_HDR; LOG_STRING("Comparison skipped"));
        }
    } else {
        LOG_PRINT(LOG_WERBOSE, LOG_HDR; LOG_STRING("No response buffer — skipping receive"));
    }

    return true;
}

/* ============================================================================================
    BuspiratePlugin::generic_internal_write_read_data
============================================================================================ */

bool BuspiratePlugin::generic_internal_write_read_data(const uint8_t u8Cmd, std::span<const uint8_t> request, std::span<uint8_t> response, bool bStrictCompare, std::stop_token st) const
{
    const size_t szWriteSize = request.size();
    const size_t szReadSize  = response.size();

    if ((szWriteSize > BP_WRITE_MAX_CHUNK_SIZE) || (szReadSize > BP_WRITE_MAX_CHUNK_SIZE)) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid length(s). Write:"); LOG_SIZET(szWriteSize); LOG_STRING("Read:"); LOG_SIZET(szReadSize));
        return false;
    }

    if (false == m_bIsEnabled) {
        return true;
    }

    LOG_PRINT(LOG_DEBUG, LOG_HDR; LOG_STRING("Write:"); LOG_SIZET(szWriteSize); LOG_STRING("Read:"); LOG_SIZET(szReadSize));

    // Build command header
    std::vector<uint8_t> header{
        u8Cmd,
        static_cast<uint8_t>((szWriteSize >> 8) & 0xFF),
        static_cast<uint8_t>(szWriteSize & 0xFF),
        static_cast<uint8_t>((szReadSize >> 8) & 0xFF),
        static_cast<uint8_t>(szReadSize & 0xFF)};

    // Combine header + request
    std::vector<uint8_t> fullRequest;
    fullRequest.reserve(header.size() + request.size());
    fullRequest.insert(fullRequest.end(), header.begin(), header.end());
    fullRequest.insert(fullRequest.end(), request.begin(), request.end());

    // Send command + request, expect acknowledgment
    uint8_t ack_response[sizeof(m_positive_response)] = {};
    if (!generic_uart_send_receive(std::span<uint8_t>(fullRequest), numeric::byte2span(ack_response), numeric::byte2span(m_positive_response), true, st)) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to send command or receive positive acknowledgment"));
        return false;
    }

    // Read actual response into provided buffer
    if (!generic_uart_send_receive(std::span<uint8_t>{}, response, std::span<const uint8_t>{}, bStrictCompare, st)) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to read response data"));
        return false;
    }

    hexutils::logHexdump(LOG_VERBOSE, "Read buffer:", "SAoC", response);

    return true;
}

/* ============================================================================================
    BuspiratePlugin::generic_internal_write_read_file
============================================================================================ */

bool BuspiratePlugin::generic_internal_write_read_file(const uint8_t u8Cmd, const std::string &strFileName, const size_t szWriteChunkSize, const size_t szReadChunkSize, std::stop_token st) const
{
    std::ifstream fin(strFileName, std::ios_base::in | std::ios::binary);
    if (!fin.is_open()) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to open:"); LOG_STRING(strFileName));
        return false;
    }

    std::uintmax_t lFileSize = ufile::getFileSize(strFileName);
    if (lFileSize == 0) {
        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Error or empty file:"); LOG_STRING(strFileName));
        return false;
    }

    size_t szNrChunks      = static_cast<size_t>(lFileSize / szWriteChunkSize);
    size_t szLastChunkSize = static_cast<size_t>(lFileSize % szWriteChunkSize);

    LOG_PRINT(LOG_DEBUG, LOG_HDR; LOG_STRING("Chunk size:"); LOG_SIZET(szWriteChunkSize); LOG_STRING("NrChunks:"); LOG_SIZET(szNrChunks); LOG_STRING("LastChunkSize:"); LOG_SIZET(szLastChunkSize));

    for (size_t i = 0; i < szNrChunks; ++i) {
        if (st.stop_requested()) {
            return false;
        }
        std::vector<uint8_t> request(szWriteChunkSize);
        fin.read(reinterpret_cast<char *>(request.data()), szWriteChunkSize);

        std::vector<uint8_t> response(szReadChunkSize, 0x00); // Preallocated read buffer
        if (!generic_internal_write_read_data(u8Cmd, request, response, false, st)) {
            return false;
        }
    }

    if (szLastChunkSize > 0) {
        std::vector<uint8_t> request(szLastChunkSize);
        fin.read(reinterpret_cast<char *>(request.data()), szLastChunkSize);

        size_t szLastReadSize = std::min(szReadChunkSize, szLastChunkSize);
        std::vector<uint8_t> response(szLastReadSize, 0x00);

        if (!generic_internal_write_read_data(u8Cmd, request, response, false, st)) {
            return false;
        }
    }

    return true;
}
