/*
http://dangerousprototypes.com/docs/Bitbang
*/
#include "buspirate_generic.hpp"
#include "buspirate_plugin.hpp"
#include "uLogger.hpp"
#include "uNumeric.hpp"

#include <algorithm>
#include <map>
#include <span>
#include <stdint.h>
#include <stop_token>
#include <string>
#include <utility>
#include <vector>

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
#undef LT_HDR
#endif
#ifdef LOG_HDR
#undef LOG_HDR
#endif
#define LT_HDR  "BPIRATE_MODE|"
#define LOG_HDR LOG_STRING(LT_HDR)

///////////////////////////////////////////////////////////////////
//            PUBLIC INTERFACES IMPLEMENTATION                   //
///////////////////////////////////////////////////////////////////

bool BuspiratePlugin::m_handle_mode(const std::string &strArgs, std::stop_token st) const
{
    bool bRetVal   = false;
    bool bShowHelp = false;

    if ("help" == strArgs) {
        bShowHelp = true;
        bRetVal   = true;
    } else {
        LOG_PRINT(LOG_VERBOSE, LOG_HDR; LOG_STRING("Mode:"); LOG_STRING(strArgs));

        ModesMap::const_iterator it = m_mapModes.find(strArgs);
        if (it != m_mapModes.end()) {

            LOG_PRINT(LOG_VERBOSE, LOG_HDR; LOG_STRING("Found mode:"); LOG_STRING(strArgs));

            // request
            std::vector<uint8_t> request(it->second.iRepetition);
            std::fill(request.begin(), request.end(), it->second.iRequest);
            // answer
            std::string strExpect{it->second.strAnswer};

            if (0 == strExpect.compare("-")) {
                uint8_t response[sizeof(m_positive_response)] = {};
                bRetVal                                       = generic_uart_send_receive(request, numeric::byte2span(response), numeric::byte2span(m_positive_response), true, st);
            } else {
                std::vector<uint8_t> expected(strExpect.begin(), strExpect.end());
                std::vector<uint8_t> response(expected.size());
                bRetVal = generic_uart_send_receive(request, response, expected, true, st);
            }
        } else {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid mode:"); LOG_STRING(strArgs));
            bShowHelp = true;
        }
    }

    if (true == bShowHelp) {
        std::string strModeList;
        for (auto it : m_mapModes) {
            strModeList += it.first;
            strModeList += " ";
        }
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use:"); LOG_STRING(strModeList.c_str()));
    }

    return bRetVal;
}
