/*
http://dangerousprototypes.com/docs/SPI_(binary)
*/
#include "bithandling.h"
#include "buspirate_generic.hpp"
#include "buspirate_plugin.hpp"
#include "uHexdump.hpp"
#include "uLogger.hpp"
#include "uNumeric.hpp"
#include "uString.hpp"

#include <algorithm>
#include <array>
#include <span>
#include <stddef.h>
#include <stdint.h>
#include <stop_token>
#include <string>
#include <vector>

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
#undef LT_HDR
#endif
#ifdef LOG_HDR
#undef LOG_HDR
#endif
#define LT_HDR               "BPIRATE_SPI |"
#define LOG_HDR              LOG_STRING(LT_HDR)

///////////////////////////////////////////////////////////////////
//                          DEFINES                              //
///////////////////////////////////////////////////////////////////

#define PROTOCOL_NAME        "SPI"

// return to bitbang mode
#define SPI_MODE_EXIT        0b0000'0000
#define SPI_MODE_EXIT_ANSWER "BBIO1"

// get the mode
#define SPI_MODE_GET         0b0000'0001
#define SPI_MODE_ANSWER      "SPI1"

// CS handling
#define SPI_CS_LOW           0b0000'0010 // 0000'001x - CS low  (0)
#define SPI_CS_HIGH          0b0000'0011 // 0000'001x - CS high (1)

#define SPI_SNIFF_CS_LOW     0b0000'1110 // 0000'11XX - Sniff SPI traffic when CS low(10)
#define SPI_SNIFF_ALL        0b0000'1101 // 0000'11XX - Sniff SPI traffic when all(01)
#define SPI_SNIFF_STOP       0b1111'1111 // Send a single byte to exit, Bus Pirate responds 0x01 on exit (0x01 reply location was changed in v5.8)
#define SPI_WRITE_READ       0b0000'0100 // 0000'0100 - Write then read

#define SPI_BULK_WR_BASE     0b0001'0000 // 0001'xxxx - Bulk SPI transfer, send/read 1-16 bytes (0=1byte!)
#define SPI_CFG_PERIF_BASE   0b0100'0000 // 0100'wxyz - Configure peripherals w=power, x=pull-ups, y=AUX, z=CS
#define SPI_SET_SPEED_BASE   0b0110'0000 // 0110'0xxx - SPI speed
#define SPI_CONFIG_BASE      0b1000'0000 // 1000'wxyz - SPI config, w=HiZ/3.3v, x=CKP idle, y=CKE edge, z=SMP sample

static const char *pstrInvalidSubcommand = "Invalid subcommand:";

///////////////////////////////////////////////////////////////////
//            PUBLIC INTERFACES IMPLEMENTATION                   //
///////////////////////////////////////////////////////////////////

/* ============================================================================================
 List the subcommands of the protocol
============================================================================================ */

bool BuspiratePlugin::m_handle_spi_help(const std::string &strArgs, std::stop_token /*st*/) const
{
    return generic_module_list_commands<BuspiratePlugin>(this, PROTOCOL_NAME);
}

/* ============================================================================================
SPI cs command handler
--------------------------
 0000001x - CS high (1) or low (0)
Toggle the Bus Pirate chip select pin, follows HiZ configuration setting.
CS high is pin output at 3.3volts, or HiZ.
CS low is pin output at ground. Bus Pirate responds 0x01.
============================================================================================ */

bool BuspiratePlugin::m_handle_spi_cs(const std::string &strArgs, std::stop_token st) const
{
    bool bRetVal = true;

    if ("help" == strArgs) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use: en[GND] dis[3.3V/HiZ]"));
    } else {
        if ("en" == strArgs) {
            m_spi_cs_enable(true, st);
        } // 00000010
        else if ("dis" == strArgs) {
            m_spi_cs_enable(false, st);
        } // 00000011
        else {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING(pstrInvalidSubcommand); LOG_STRING(strArgs));
            bRetVal = false;
        }
    }

    return bRetVal;

} /* m_handle_spi_cs() */

/* ============================================================================================
SPI sniff command handler
-----------------------------
000011XX - Sniff SPI traffic when CS low(10)/all(01)
The SPI sniffer is implemented in hardware and should work up to 10MHz.
It follows the configuration settings you entered for SPI mode.
The sniffer can read all traffic, or filter by the state of the CS pin.

Send the SPI sniffer command to start the sniffer, the Bus Pirate responds 0x01 then sniffed data starts to flow.
Send any byte to exit. Bus Pirate responds 0x01 on exit. (0x01 reply location was changed in v5.8)

If the sniffer can't keep with the SPI data, the MODE LED turns off and the sniff is aborted. (new in v5.1)
The sniffer follows the output clock edge and output polarity settings of the SPI mode,
but not the input sample phase.
============================================================================================ */

bool BuspiratePlugin::m_handle_spi_sniff(const std::string &strArgs, std::stop_token st) const
{
    bool bRetVal = true;

    if ("help" == strArgs) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use | on | off"));
    } else {
        uint8_t request = 0;
        bool bStop      = false;

        if ("all" == strArgs) {
            request = SPI_SNIFF_ALL;
        } else if ("cslo" == strArgs) {
            request = SPI_SNIFF_CS_LOW;
        } else {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING(pstrInvalidSubcommand); LOG_STRING(strArgs));
            bRetVal = false;
        }

        if (true == bRetVal) {
            if (true == bStop) {
                uint8_t response[sizeof(m_positive_response)] = {};
                bRetVal                                       = generic_uart_send_receive(numeric::byte2span(request), numeric::byte2span(response), numeric::byte2span(m_positive_response), true, st);
            } else {
                bRetVal = generic_uart_send_receive(numeric::byte2span(request));
            }
        }
    }

    return bRetVal;

} /* m_handle_spi_sniff() */

/* ============================================================================================
SPI speed command handler
-----------------------------
000=30kHz, 001=125kHz, 010=250kHz, 011=1MHz, 100=2MHz, 101=2.6MHz, 110=4MHz, 111=8MHz
This command sets the SPI bus speed according to the values shown. Default startup speed is 000 (30kHz).
============================================================================================ */

bool BuspiratePlugin::m_handle_spi_speed(const std::string &strArgs, std::stop_token st) const
{
    return generic_module_set_speed<BuspiratePlugin>(this, PROTOCOL_NAME, strArgs, st);

} /* m_handle_spi_speed() */

/* ============================================================================================
SPI configuration command handler
----------------------------------
1000wxyz - SPI config, w=HiZ/3.3v, x=CKP idle, y=CKE edge, z=SMP sample

This command configures the SPI settings.
Options and start-up defaults are the same as the user terminal SPI mode.
w= pin output HiZ(0)/3.3v(1),
x=CKP clock idle phase (low=0),
y=CKE clock edge (active to idle=1),
z=SMP sample time (middle=0). The Bus Pirate responds 0x01 on success.

Default raw SPI startup condition is 0010. HiZ mode configuration applies to the SPI pins and the CS pin,
but not the AUX pin.
See the PIC24FJ64GA002 datasheet and the SPI section[PDF] of the PIC24 family manual
for more about the SPI configuration settings.
============================================================================================ */

bool BuspiratePlugin::m_handle_spi_cfg(const std::string &strArgs, std::stop_token st) const
{
    bool bRetVal           = true;
    static uint8_t request = SPI_CONFIG_BASE;

    if ("help" == strArgs) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("z/V - pin output: z(HiZ/0)! V(3.3V/1)"));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("l/H - CKP clock idle phase: l(low/0)! H(high/1)"));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("i/A - CKE clock edge i(Idle2Active/0) A(Active2Idle/1)"));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("m/E - SMP sample time m(middle/0)! E(end/1)"));
    } else if ("?" == strArgs) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("spi::cfg:"); LOG_UINT8(request));
    } else {
        // pin output
        if (ustring::containsChar(strArgs, 'z')) {
            BIT_CLEAR(request, 3);
        }
        if (ustring::containsChar(strArgs, 'V')) {
            BIT_SET(request, 3);
        }
        // clock idle phase
        if (ustring::containsChar(strArgs, 'l')) {
            BIT_CLEAR(request, 2);
        }
        if (ustring::containsChar(strArgs, 'H')) {
            BIT_SET(request, 2);
        }
        // clock edge
        if (ustring::containsChar(strArgs, 'i')) {
            BIT_CLEAR(request, 1);
        }
        if (ustring::containsChar(strArgs, 'A')) {
            BIT_SET(request, 1);
        }
        // sample time
        if (ustring::containsChar(strArgs, 'm')) {
            BIT_CLEAR(request, 0);
        }
        if (ustring::containsChar(strArgs, 'E')) {
            BIT_SET(request, 0);
        }

        uint8_t response[sizeof(m_positive_response)] = {};
        bRetVal                                       = generic_uart_send_receive(numeric::byte2span(request), numeric::byte2span(response), numeric::byte2span(m_positive_response), true, st);
    }

    return bRetVal;

} /* m_handle_spi_cfg() */

/* ============================================================================================
    SPI peripheral command handler
-----------------------------------
    0100wxyz - Configure peripherals w=power, x=pull-ups, y=AUX, z=CS
     * Configure peripherals:
     *
     *    7     6     5     4     3     2     1     0
     * +-----+-----+-----+-----+-----+-----+-----+-----+
     * |  0  |  1  |  0  |  0  |  W  |  X  |  Y  |  Z  |
     * +-----+-----+-----+-----+-----+-----+-----+-----+
     *  \__________ __________/ \_ _/ \_ _/ \_ _/ \_ _/
     *             |              |     |     |     |
     *             |              |     |     |     +--> CS       : 1 - Enable, 0 - Disable.
     *             |              |     |     +--------> Aux      : 1 - Enable, 0 - Disable.
     *             |              |     +--------------> Pull-ups : 1 - Enable, 0 - Disable.
     *             |              +--------------------> Power    : 1 - Enable, 0 - Disable.
     *             +-----------------------------------> Command  : 4xh - Configure peripherals.
============================================================================================ */

bool BuspiratePlugin::m_handle_spi_per(const std::string &strArgs, std::stop_token st) const
{
    return generic_set_peripheral(strArgs, st);

} /* m_handle_spi_per() */

/* ============================================================================================
    SPI bulk transfer command handler (READ)
----------------------------------------------
     * 0001xxxx - Bulk SPI transfer, write 1-16 bytes (0=1byte!)
     * Bulk SPI transfer:
     *
     *    7     6     5     4     3     2     1     0
     * +-----+-----+-----+-----+-----+-----+-----+-----+--- -- -   - -- ---+
     * |  0  |  0  |  0  |  1  |                       |                   |
     * +-----+-----+-----+-----+-----+-----+-----+-----+--- -- -   - -- ---+
     *  \__________ __________/ \__________ __________/ \________ ________/
     *             |                       |                     |
     *             |                       |                     +---------> Payload      : From 1 to 16 bytes.
     *             |                       +-------------------------------> Payload Size : Number of bytes - 1.
     *             +-------------------------------------------------------> Command      : 1xh
============================================================================================ */

bool BuspiratePlugin::m_handle_spi_read(const std::string &strArgs, std::stop_token st) const
{
    bool bRetVal = true;

    if (strArgs == "help") {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use: 1 .. 16"));
    } else {
        size_t szReadSize = 0;
        if ((true == (bRetVal = numeric::str2sizet(strArgs, szReadSize)))) {
            if ((szReadSize >= 1) && (szReadSize <= 16)) {
                std::vector<uint8_t> response(szReadSize);
                if (true == (bRetVal = m_spi_read(response, st))) {
                    hexutils::logHexdump(LOG_WERBOSE, "SPI Read:", "SAoC", response);
                }
            } else {
                LOG_PRINT(LOG_EMPTY, LOG_STRING("Size out or range, use 1..16"); LOG_SIZET(szReadSize));
                bRetVal = false;
            }
        }
    }

    return bRetVal;

} /* m_handle_spi_read() */

/* ============================================================================================
    SPI bulk transfer command handler (WRITE)
---------------------------------------------
     * 0001xxxx - Bulk SPI transfer, write 1-16 bytes (0=1byte!)
     * Bulk SPI transfer:
     *
     *    7     6     5     4     3     2     1     0
     * +-----+-----+-----+-----+-----+-----+-----+-----+--- -- -   - -- ---+
     * |  0  |  0  |  0  |  1  |                       |                   |
     * +-----+-----+-----+-----+-----+-----+-----+-----+--- -- -   - -- ---+
     *  \__________ __________/ \__________ __________/ \________ ________/
     *             |                       |                     |
     *             |                       |                     +---------> Payload      : From 1 to 16 bytes.
     *             |                       +-------------------------------> Payload Size : Number of bytes - 1.
     *             +-------------------------------------------------------> Command      : 1xh
============================================================================================ */

bool BuspiratePlugin::m_handle_spi_write(const std::string &strArgs, std::stop_token st) const
{
    return generic_write_data(this, strArgs, &BuspiratePlugin::m_spi_bulk_write, st);

} /* m_handle_spi_write() */

/* ============================================================================================
    SPI "write then read" command handler
-----------------------------------------
     00000100 - Write then read
     This command was developed to help speed ROM programming with Flashrom. It might be helpful for a lot of common SPI operations.
     It enables chip select, writes 0-4096 bytes, reads 0-4096 bytes, then disables chip select.
     All data for this command can be sent at once, and it will be buffered in the Bus Pirate.
     The write and read operations happen all at once, and the read data is buffered.
     At the end of the operation, the read data is returned from the buffer.
     The goal is to meet the stringent timing requirements of some ROM chips by buffering everything instead of letting the serial port delay things.
     Write then read command format
     - command (1byte) | number of write bytes (2bytes) | number of read bytes (2bytes) | bytes to write (0-4096bytes)

     Return data format success/0x01 (1byte) bytes read from SPI (0-4096bytes)

      1   First send the write then read command (00000100)
      2   The next two bytes (High8/Low8) set the number of bytes to write (0 to 4096)
      3   The next two bytes (h/l) set the number of bytes to read (0 to 4096)
      4   If the number of bytes to read or write are out of bounds, the Bus Pirate will return 0x00 now
      5   Now send the bytes to write. Bytes are buffered in the Bus Pirate, there is no acknowledgment that a byte is received.
      6   Now the Bus Pirate will write the bytes to SPI and read/return the requsted number of read bytes
      7   CS goes low, all write bytes are sent at once
      8   Read starts immediately, all bytes are put into a buffer at max SPI speed (no waiting for UART)
      9   At the end of the read, CS goes high
     10   The Bus Pirate now returns 0x01, success
     11   Finally, the buffered read bytes are returned via the serial port

     Except as described above, there is no acknowledgment that a byte is received.
============================================================================================ */
bool BuspiratePlugin::m_handle_spi_wrrd(const std::string &strArgs, std::stop_token st) const
{
    return generic_write_read_data(m_CMD_SPI_WRRD, strArgs, st);

} /* m_handle_spi_wrrd() */

/* ============================================================================================
     BuspiratePlugin::m_handle_spi_wrrdf
============================================================================================ */
bool BuspiratePlugin::m_handle_spi_wrrdf(const std::string &strArgs, std::stop_token st) const
{
    return generic_write_read_file(m_CMD_SPI_WRRD, strArgs, st);

} /* m_handle_spi_wrrdf */

/* ============================================================================================
    BuspiratePlugin::m_spi_cs_enable
============================================================================================ */
bool BuspiratePlugin::m_spi_cs_enable(bool bEnable, std::stop_token st) const
{
    uint8_t csValue                               = bEnable ? SPI_CS_LOW : SPI_CS_HIGH;
    uint8_t response[sizeof(m_positive_response)] = {};
    return generic_uart_send_receive(numeric::byte2span(csValue), numeric::byte2span(response), numeric::byte2span(m_positive_response), true, st);

} /* m_spi_cs_enable() */

/* ============================================================================================
    BuspiratePlugin::m_spi_bulk_write
============================================================================================ */
bool BuspiratePlugin::m_spi_bulk_write(std::span<const uint8_t> request, std::stop_token st) const
{
    bool bRetVal                             = false;
    std::array<uint8_t, 17> internal_request = {}; // zero-initialized

    if ((bRetVal = m_spi_cs_enable(true, st))) {
        size_t offset = 0;

        while (offset < request.size()) {
            size_t szCount      = std::min<size_t>(6, request.size() - offset);
            internal_request[0] = SPI_BULK_WR_BASE | static_cast<uint8_t>(szCount - 1);
            std::copy_n(request.begin() + offset, szCount, internal_request.begin() + 1);

            // The bulk SPI response is: [0x01 ACK][szCount MISO bytes]
            // We must read all szCount+1 bytes to keep the UART buffer clean.
            std::array<uint8_t, 17> full_response = {};
            std::span<uint8_t> fullReplySpan(full_response.data(), szCount + 1);
            if (false == (bRetVal = generic_uart_send_receive(std::span<uint8_t>{internal_request.data(), szCount + 1}, fullReplySpan, numeric::byte2span(m_positive_response), true, st))) {
                break;
            }

            offset += szCount;
            if (st.stop_requested()) {
                bRetVal = false;
                break;
            }
        }

        if (true == bRetVal) {
            bRetVal = m_spi_cs_enable(false, st);
        }
    }

    return bRetVal;
}

/* ============================================================================================
    BuspiratePlugin::m_handle_spi_read
============================================================================================ */
bool BuspiratePlugin::m_spi_read(std::span<uint8_t> response, std::stop_token st) const
{
    bool bRetVal                             = false;
    std::array<uint8_t, 17> internal_request = {}; // max 16 bytes + command

    const size_t count                       = response.size();

    if ((bRetVal = m_spi_cs_enable(true, st))) {
        size_t offset = 0;
        while (offset < count) {
            size_t szCount      = std::min<size_t>(6, count - offset);
            internal_request[0] = SPI_BULK_WR_BASE | static_cast<uint8_t>(szCount - 1);
            std::fill_n(internal_request.begin() + 1, szCount, 0x00); // send dummy bytes

            // The bulk SPI response is: [0x01 ACK][szCount MISO bytes] = szCount+1 bytes total.
            std::array<uint8_t, 7> reply = {}; // 1 ACK + up to 6 data bytes
            std::span<uint8_t> replySpan(reply.data(), szCount + 1);

            if (!(bRetVal = generic_uart_send_receive(std::span<uint8_t>{internal_request.data(), szCount + 1}, replySpan, numeric::byte2span(m_positive_response), true, st))) {
                break;
            }

            // reply[0] is the ACK (already validated); actual MISO data starts at reply[1]
            std::copy_n(reply.begin() + 1, szCount, response.begin() + offset);
            offset += szCount;
            if (st.stop_requested()) {
                bRetVal = false;
                break;
            }
        }

        if (bRetVal) {
            bRetVal = m_spi_cs_enable(false, st);
        }
    }

    return bRetVal;
}

/* ============================================================================================
    BuspiratePlugin::m_handle_spi_script
============================================================================================ */
bool BuspiratePlugin::m_handle_spi_script(const std::string &strArgs, std::stop_token st) const
{
    bool bRetVal = true;

    if ("help" == strArgs) {
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Use: scriptname"));
    } else {
        return generic_execute_script<BuspiratePlugin, BuspiratePlugin::SPI_CommDriver>(this, m_strInstanceName, strArgs, st);
    }

    return bRetVal;

} /* m_handle_spi_script() */
