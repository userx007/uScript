Replace this section of the main CMakeLists.txt

```
# --- 6. User plugins ----

set(UPLUGIN_TARGETS
    SimpleTypes
)
```

with this one


```
# --- 6. User plugins ----

set(UPLUGIN_TARGETS
    SimpleTypes
    AcousticGunshotDetectionSystemTypes
    AlarmsTypes
    ArbitrationTypes
    AutomaticWeaponTypes
    BrakesTypes
    HMIInputDevicesTypes
    HMIPresentationTypes
    LaserWarningSystemTypes
    LRFTypes
    MountTypes
    NavigationReferenceTypes
    PowerTypes
    RoutesTypes
    SingleShotGrenadeLauncherArrayTypes
    TacticalEffectorTypes
    TacticalSensorTypes
    UsageAndConditionMonitoringTypes
    VehicleConfigurationTypes
    VideoTypes
    VideoTrackingTypes
)
```