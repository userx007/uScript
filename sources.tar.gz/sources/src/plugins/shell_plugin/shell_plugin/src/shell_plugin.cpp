#include "shell_plugin.hpp"

#include "uGuiNotify.hpp"
#include "ushell_core.h"
#include "ushell_core_datatypes.h"
#include "ushell_core_terminal.h"
#include "ushell_core_terminal_linux.h"

#include <memory>
#include <string>

/////////////////////////////////////////////////////////////////////////////////
//                  PLUGIN ENTRY POINTS                                        //
/////////////////////////////////////////////////////////////////////////////////

extern "C" {
    EXPORTED ShellPlugin *pluginEntry()
    {
        return new ShellPlugin();
    }

    EXPORTED void pluginExit(ShellPlugin *pPlugin)
    {
        if (nullptr != pPlugin) {
            delete pPlugin;
        }
    }
}

///////////////////////////////////////////////////////////////////
//                          COMMAND HANDLERS                     //
///////////////////////////////////////////////////////////////////

/**
 * \brief RUN command implementation; launches an interactive shell session.
 *        The session blocks until the user exits the shell.
 *
 * \note Usage example: <br>
 *       SHELL.RUN
 *
 * \param[in] args unused (no arguments expected)
 *
 * \return true if succeeded, false otherwise
 */

bool ShellPlugin::m_Shell_RUN(const std::string &strArgs, std::stop_token st) const
{
    bool bRetVal = false;

    do {

        if (!strArgs.empty()) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Expected no argument(s)"));
            break;
        }

        // if plugin is not enabled stop execution here and return true as the argument(s) validation passed
        if (false == m_bIsEnabled) {
            bRetVal = true;
            break;
        }

        // In GUI mode, stdin is a QProcess pipe — isatty(STDIN_FILENO) returns
        // false so TerminalRAII would bail early AND emit "Not a valid terminal."
        // on stdout, corrupting the GUI protocol stream.  Skip it entirely when
        // the front-end is attached; raw character delivery works over the pipe
        // without any termios manipulation.
        std::unique_ptr<TerminalRAII> terminal;
        if (!gui_mode_active()) {
            terminal = std::make_unique<TerminalRAII>();
        }

        std::shared_ptr<Microshell> pShellPtr = Microshell::getShellSharedPtr(uShellPluginEntry(m_pvUserData), "root");

        if (nullptr != pShellPtr) {
            // ── GUI: signal the front-end that the shell session is starting ──
            gui_notify_shell_run();

            pShellPtr->Run();

            // ── GUI: signal that the shell exited (user typed "exit") ──────
            // gui_notify_shell_exit() emits GUI:SHELL_EXIT then blocks on
            // stdin until the Qt side writes "SHELL_DONE\n" back, ensuring
            // the main script only resumes once the UI is in normal mode.
            gui_notify_shell_exit();
        }

        // implementation here..
        bRetVal = true;

    } while (false);

    return bRetVal;
}

/**
 * \brief INFO command implementation; shows details about plugin and
 *        describe the supported functions with examples of usage.
 *        This command takes no arguments and is executed even if the plugin initialization fails
 *
 * \note Usage example: <br>
 *       SHELL.INFO
 *
 * \param[in] pstrArgs NULL (NULL means that no arguments are provided to this function)
 *
 * \return true on success, false otherwise
 */

bool ShellPlugin::m_Shell_INFO(const std::string &strArgs, std::stop_token st) const
{
    bool bRetVal = false;

    do {

        // expected no arguments
        if (!strArgs.empty()) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Expected no argument(s)"));
            break;
        }

        // if plugin is not enabled stop execution here and return true as the argument(s) validation passed
        if (false == m_bIsEnabled) {
            bRetVal = true;
            break;
        }

        LOG_SEP();
        LOG_PRINT(LOG_EMPTY, LOG_STRING(SHELL_PLUGIN_NAME); LOG_STRING("Vers:"); LOG_STRING(m_strVersion));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Build:"); LOG_STRING(__DATE__); LOG_STRING(__TIME__));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("Description: launch an interactive shell session"));

        LOG_SEP();
        LOG_PRINT(LOG_EMPTY, LOG_STRING("RUN : start an interactive shell session (blocks until the user exits)"));
        LOG_PRINT(LOG_EMPTY, LOG_STRING("  Usage: SHELL.RUN"));
        LOG_SEP();

        bRetVal = true;

    } while (false);

    return bRetVal;
}
