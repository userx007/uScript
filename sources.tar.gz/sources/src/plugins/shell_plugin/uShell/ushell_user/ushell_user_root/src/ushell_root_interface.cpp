#include "ushell_core_datatypes.h"
#include "ushell_core_settings.h"
#include "ushell_root_datatypes.h"

/* user commands dispatcher */
static int uShellExecuteCommand(const command_s *pCmd);

#if (1 == uSHELL_SUPPORTS_EXTERNAL_USER_DATA)
void *pvLocalUserData = nullptr;
#endif /* (1 == uSHELL_SUPPORTS_EXTERNAL_USER_DATA) */

/* disable warnings */
#if defined(__GNUC__) && defined(__AVR__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmissing-braces"
#endif /*defined (__GNUC__) && defined(__AVR__)*/

#if (defined(__GNUC__) && (defined(__xtensa__) || defined(__ARM_ARCH)))
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-function-type"
#endif /*(defined(__GNUC__) && defined(__xtensa__))*/

/** \brief define array of functions (basic properties) */
#define uSHELL_COMMANDS_TABLE_BEGIN static const fctDef_s g_vsFuncDefArray[] = {
#define uSHELL_COMMAND_PARAMS_PATTERN(t)
#define uSHELL_COMMAND(a, b, c) {#a, #b},
#define uSHELL_COMMANDS_TABLE_END \
    }                             \
    ;
#include uSHELL_COMMANDS_CONFIG_FILE
#undef uSHELL_COMMANDS_TABLE_BEGIN
#undef uSHELL_COMMAND_PARAMS_PATTERN
#undef uSHELL_COMMAND
#undef uSHELL_COMMANDS_TABLE_END

/** \brief define array of functions (extended properties) */
#define uSHELL_COMMANDS_TABLE_BEGIN static const fctDefEx_s g_vsFuncDefExArray[] = {
#define uSHELL_COMMAND_PARAMS_PATTERN(t)
#if (defined(__GNUC__) && (defined(__AVR__) || defined(__ARM_ARCH) || defined(__xtensa__)))
#define uSHELL_COMMAND(a, b, c) {(v_fctptr_t)a, b##_type},
#elif ((defined(__GNUC__) && defined(__linux__)) || defined(__MINGW32__))
#ifdef __cplusplus
#define uSHELL_COMMAND(a, b, c) {(v_fctptr_t)a, b##_type},
#else
#define uSHELL_COMMAND(a, b, c) {(fctype_u)(b##_fctptr_t)a, b##_type},
#endif                    // __cplusplus
#elif (defined(_MSC_VER)) /* i.e MinGW or Microsoft VisualStudio for Windows console */
#ifdef __cplusplus
#define uSHELL_COMMAND(a, b, c) {(v_fctptr_t)a, b##_type},
#else
#define uSHELL_COMMAND(a, b, c) {(b##_fctptr_t)a, b##_type},
#endif
#elif (defined(__ghs) || defined(__ghs__)) /* Green Hills Software compiler */
#define uSHELL_COMMAND(a, b, c) {a, b##_type},
#else
#error "Build variant not defined, please define it..."
#endif
#define uSHELL_COMMANDS_TABLE_END \
    }                             \
    ;
#include uSHELL_COMMANDS_CONFIG_FILE
#undef uSHELL_COMMANDS_TABLE_BEGIN
#undef uSHELL_COMMAND_PARAMS_PATTERN
#undef uSHELL_COMMAND
#undef uSHELL_COMMANDS_TABLE_END

/* end of disable warnings */
#if (defined(__GNUC__) && (defined(__AVR__) || defined(__xtensa__)))
#pragma GCC diagnostic pop
#endif /*defined (__GNUC__) && defined(__AVR__)*/

/* info for functions */
#if (1 == uSHELL_IMPLEMENTS_COMMAND_HELP)
#define uSHELL_COMMANDS_TABLE_BEGIN static const char *const g_vstrInfoArray[] = {
#define uSHELL_COMMAND_PARAMS_PATTERN(t)
#define uSHELL_COMMAND(a, b, c) c,
#define uSHELL_COMMANDS_TABLE_END \
    }                             \
    ;
#include uSHELL_COMMANDS_CONFIG_FILE
#undef uSHELL_COMMANDS_TABLE_BEGIN
#undef uSHELL_COMMAND_PARAMS_PATTERN
#undef uSHELL_COMMAND
#undef uSHELL_COMMANDS_TABLE_END
#endif /*(1 == uSHELL_IMPLEMENTS_COMMAND_HELP)*/

/* autocomplete index array */
#if (1 == uSHELL_IMPLEMENTS_AUTOCOMPLETE)
static int g_viAutocompleteIndexArray[uSHELL_NR_ELEMS(g_vsFuncDefArray)] = {0};
#endif /*(1 == uSHELL_IMPLEMENTS_AUTOCOMPLETE)*/

/* user shortcuts array */
#if (1 == uSHELL_IMPLEMENTS_USER_SHORTCUTS)
#define uSHELL_USER_SHORTCUTS_TABLE_BEGIN static shortcut_s g_vsShortcutsArray[] = {{' ', nullptr}
#define uSHELL_USER_SHORTCUT(a, b, c)   \
    ,                                   \
    {                                   \
        a, uShellUserHandleShortcut_##b \
    }
#define uSHELL_USER_SHORTCUTS_TABLE_END \
    }                                   \
    ;
#include uSHELL_USER_SHORTCUTS_CONFIG_FILE
#undef uSHELL_USER_SHORTCUTS_TABLE_BEGIN
#undef uSHELL_USER_SHORTCUT
#undef uSHELL_USER_SHORTCUTS_TABLE_END
#else
static shortcut_s g_vsShortcutsArray[] = {{' ', nullptr}};
#endif /*(1 == uSHELL_IMPLEMENTS_USER_SHORTCUTS)*/

#if (1 == uSHELL_IMPLEMENTS_USER_SHORTCUTS)
/* user shortcuts help info array */
#define uSHELL_USER_SHORTCUTS_TABLE_BEGIN static const char *const g_vstrShortcutsInfoArray[] = {
#define uSHELL_USER_SHORTCUT(a, b, c)     c,
#define uSHELL_USER_SHORTCUTS_TABLE_END \
    }                                   \
    ;
#include uSHELL_USER_SHORTCUTS_CONFIG_FILE
#undef uSHELL_USER_SHORTCUTS_TABLE_BEGIN
#undef uSHELL_USER_SHORTCUT
#undef uSHELL_USER_SHORTCUTS_TABLE_END
#endif /*(1 == uSHELL_IMPLEMENTS_USER_SHORTCUTS)*/

/* partial initialization of the shell instance structure */
static uShellInst_s sShellInstance = {
    .psFuncDefArray   = g_vsFuncDefArray,
    .psShortcutsArray = g_vsShortcutsArray,
#if (1 == uSHELL_IMPLEMENTS_COMMAND_HELP)
    .ppstrInfoArray = g_vstrInfoArray,
#if (1 == uSHELL_IMPLEMENTS_USER_SHORTCUTS)
    .ppstrShortcutsInfoArray = g_vstrShortcutsInfoArray,
#endif /*(1 == uSHELL_IMPLEMENTS_USER_SHORTCUTS)*/
#endif /* (1 == uSHELL_IMPLEMENTS_COMMAND_HELP) */
#if (1 == uSHELL_IMPLEMENTS_AUTOCOMPLETE)
    .piAutocompleteIndexArray = g_viAutocompleteIndexArray,
#endif /* (1 == uSHELL_IMPLEMENTS_AUTOCOMPLETE) */
#if (1 == uSHELL_IMPLEMENTS_SAVE_HISTORY)
    .pstrPromptName = nullptr,
#endif /*(1 == uSHELL_IMPLEMENTS_SAVE_HISTORY)*/
#if (1 == uSHELL_IMPLEMENTS_SHELL_EXIT)
    .bKeepRuning = true,
#endif /*(1 == uSHELL_IMPLEMENTS_SHELL_EXIT)*/
    .iNrFunctions  = uSHELL_NR_ELEMS(g_vsFuncDefArray),
    .iNrShortcuts  = uSHELL_NR_ELEMS(g_vsShortcutsArray),
    .pfExec        = uShellExecuteCommand,
    .vstrPrompt    = {0},
    .iPromptLength = 0};

/******************************************************************************/
/**
 * @brief Plugin entry point - initializes and returns shell instance
 * @param pvUserData Optional user data pointer (if external user data is supported)
 * @return Pointer to initialized shell instance
 */
#if (1 == uSHELL_SUPPORTS_EXTERNAL_USER_DATA)
uShellPluginInterface *uShellPluginEntry(void *pvUserData)
{
    pvLocalUserData = pvUserData;
    return &sShellInstance;
} /* uShellPluginEntry( void *pvUserData ) */

#else

uShellPluginInterface *uShellPluginEntry(void)
{
    return &sShellInstance;
} /*uShellPluginEntry() */

#endif /*(1 == uSHELL_SUPPORTS_EXTERNAL_USER_DATA)*/

/******************************************************************************/
/**
 * @brief Plugin exit point - performs cleanup when plugin is unloaded
 * @param ptrPlugin Pointer to the plugin interface being cleaned up
 *
 * This function is called when a plugin is being unloaded or when the shell
 * instance is being destroyed. It provides a hook for resource cleanup.
 */
void uShellPluginExit(uShellPluginInterface *pPlugin)
{
    if (!pPlugin) {
        return;
    }

    /* Reset the bKeepRunning flag to ensure clean shutdown */
#if (1 == uSHELL_IMPLEMENTS_SHELL_EXIT)
    pPlugin->bKeepRuning = false;
#endif

    /* Clear autocomplete index array if present */
#if (1 == uSHELL_IMPLEMENTS_AUTOCOMPLETE)
    if (pPlugin->piAutocompleteIndexArray) {
        for (int i = 0; i < pPlugin->iNrFunctions; i++) {
            pPlugin->piAutocompleteIndexArray[i] = 0;
        }
    }
#endif

    /* Clear prompt */
    if (pPlugin->vstrPrompt[0] != '\0') {
        pPlugin->vstrPrompt[0] = '\0';
        pPlugin->iPromptLength = 0;
    }

    /* Note: We don't free the static arrays (g_vsFuncDefArray, etc.) as they
     * are statically allocated and will be cleaned up when the program exits.
     * For dynamically loaded plugins, the OS will reclaim this memory when
     * the shared library is unloaded.
     */
} /* uShellPluginExit() */

/******************************************************************************/
/**
 * @brief Execute a shell command based on parsed command structure
 * @param psCmd Pointer to command structure with parsed parameters
 * @return Error code from uSHELL_ERR_* enumeration
 */
static int uShellExecuteCommand(const command_s *pCmd)
{
    /* void:v, (byte)u8:b:vb, (word)u16:w:vw, (int)u32:i:vi, (long)u64:l:vl, float:f:vf, string:s:vs, bool:o:vo */
    switch (g_vsFuncDefExArray[pCmd->iFctIndex].eParamType) {
    case v_type:
        return g_vsFuncDefExArray[pCmd->iFctIndex].uFctType.v_fct();
    case s_type:
        return g_vsFuncDefExArray[pCmd->iFctIndex].uFctType.s_fct(pCmd->vs[0]);
    case lio_type:
        return g_vsFuncDefExArray[pCmd->iFctIndex].uFctType.lio_fct(pCmd->vl[0], pCmd->vi[0], pCmd->vo[0]);
    default:
        return uSHELL_ERR_PARAMS_PATTERN_NOT_IMPLEM;
    }
} /* uShellExecuteCommand() */
