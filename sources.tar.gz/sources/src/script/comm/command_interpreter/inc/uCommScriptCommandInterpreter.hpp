#ifndef U_COMM_SCRIPT_COMMAND_INTERPRETER_HPP
#define U_COMM_SCRIPT_COMMAND_INTERPRETER_HPP

#include "uSharedConfig.hpp"
#include "ICommDriver.hpp"
#include "ICommScriptCommandInterpreter.hpp"
#include "uCommScriptDataTypes.hpp"

#include "uLogger.hpp"
#include "uString.hpp"
#include "uHexlify.hpp"
#include "uHexdump.hpp"
#include "uNumeric.hpp"
#include "uTimer.hpp"
#include "uFile.hpp"
#include "uGuiNotify.hpp"

#include <regex>
#include <string>
#include <memory>
#include <string_view>
#include <filesystem>

/////////////////////////////////////////////////////////////////////////////////
//                             LOG DEFINITIONS                                 //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
    #undef LT_HDR
#endif
#ifdef LOG_HDR
    #undef LOG_HDR
#endif

#define LT_HDR     "COMM_CMD_I  |"
#define LOG_HDR    LOG_STRING(LT_HDR)

/////////////////////////////////////////////////////////////////////////////////
//                            CLASS DEFINITION                                 //
/////////////////////////////////////////////////////////////////////////////////

/**
 * @brief Interprets and executes communication commands from scripts
 * 
 * This class takes CommCommand objects (parsed script lines) and executes them
 * using any ICommDriver-derived driver. It handles:
 * - Send/receive operations in specified order
 * - Multiple data formats (hex, string, file, token, etc.)
 * - Pattern matching and validation
 * - File transfers in chunks
 * - INFO-severity log messages via the '@' print statement (no driver I/O)
 * 
 * @tparam TDriver The concrete driver type (must derive from ICommDriver)
 */
template <typename TDriver>
class CommScriptCommandInterpreter : public ICommScriptCommandInterpreter<CommCommand, TDriver>
{
public:

    using SendFunc = SendFunction<TDriver>;
    using RecvFunc = RecvFunction<TDriver>;

    /**
     * @brief Constructor
     * @param driver Shared pointer to the communication driver
     * @param pluginName Plugin identity for the GUI comm-dump panel (e.g. UART_PLUGIN_NAME).
     *                    Forwarded verbatim as the "Plugin" column; see gui_notify_comm_dump().
     * @param maxRecvSize Maximum buffer size for receive operations
     * @param defaultTimeout Default timeout in milliseconds (0 = use driver default)
     * @param pfsend Optional override for the physical write primitive. When empty
     *               (default), every send goes straight to driver->tout_write() and
     *               this class produces the GUI comm-dump row itself, exactly as
     *               before this parameter existed — every plugin that doesn't pass
     *               one is completely unaffected.
     *               When set, the interpreter calls pfsend(...) instead of
     *               driver->tout_write() directly, and — since only the injected
     *               function actually knows what went out on the wire (e.g. a
     *               transport protocol that turns one logical send into several
     *               physical frames) — this class stops emitting its own
     *               comm-dump row for that direction, trusting pfsend to report
     *               whatever rows are accurate (see KVCANPlugin::m_Send()).
     * @param pfrecv Same idea as pfsend, for the read side (driver->tout_read()).
     */
    explicit CommScriptCommandInterpreter(
        std::shared_ptr<const TDriver> driver,
        std::string pluginName,
        size_t maxRecvSize = 4096,
        uint32_t defaultTimeout = 5000,
        SendFunc pfsend = SendFunc{},
        RecvFunc pfrecv = RecvFunc{})
        : m_driver(driver)
        , m_pluginName(std::move(pluginName))
        , m_maxRecvSize(maxRecvSize)
        , m_defaultTimeout(defaultTimeout)
        , m_pfsend(std::move(pfsend))
        , m_pfrecv(std::move(pfrecv))
    {
        static_assert(std::is_base_of<ICommDriver, TDriver>::value,
                     "TDriver must derive from ICommDriver");
    }

    /**
     * @brief Interpret and execute a single command
     * @param command   The parsed command to execute
     * @param bRealExec false during a script dry-run/validation pass: the driver
     *                  must already be open (validated by the caller) and the
     *                  command's grammar has already been validated, but this
     *                  call stops one step short of the actual send/receive
     *                  interface and returns success without touching real
     *                  hardware I/O. true for normal execution.
     * @return true if execution (or dry-run validation) successful, false otherwise
     */
    bool interpretCommand(const CommCommand& command, bool bRealExec) override
    {
        /* PRINT is a pure logging statement - it performs no driver I/O, so it
         * is handled before the driver-availability check and does not require
         * an open port. */
        if (command.direction == CommCommandDirection::PRINT) {
            auto lineNr = ustring::fmtLineNr(command.iLineNumber);
            LOG_PRINT(LOG_INFO, LOG_HDR; LOG_STRING(lineNr.data()); LOG_STRING(command.values.first));
            return true;
        }

        if (!m_driver || !m_driver->is_open()) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Driver not available or port not open"));
            return false;
        }
        auto lineNr = ustring::fmtLineNr(command.iLineNumber);

        if (!bRealExec && ((command.direction == CommCommandDirection::SEND_RECV) ||
                           (command.direction == CommCommandDirection::RECV_SEND))) {
            // Dry-run: the caller (ucmdexec::generic_cmd) has already validated the
            // command's grammar and successfully opened/configured the driver above -
            // this is deliberately the one place left to stop, one step short of the
            // actual send/receive interface, so a dry-run pass never puts a byte on
            // the wire or blocks on a real read. DELAY has no hardware side effect so
            // it is allowed to fall through unchanged; PRINT was already handled above.
            LOG_PRINT(LOG_INFO, LOG_HDR; LOG_STRING(lineNr.data());
                      LOG_STRING("Dry-run: valid, skipping send/receive"));
            return true;
        }

        LOG_PRINT(LOG_DEBUG, LOG_HDR; LOG_STRING(lineNr.data()); 
                  LOG_STRING("Exec:"); 
                  LOG_STRING(getDirectionName(command.direction));
                  LOG_STRING("["); LOG_STRING(command.values.first); 
                  LOG_STRING(":"); LOG_STRING(command.values.second);
                  LOG_STRING("]=["); 
                  LOG_STRING(getTokenTypeName(command.tokens.first));
                  LOG_STRING(":"); 
                  LOG_STRING(getTokenTypeName(command.tokens.second));
                  LOG_STRING("] xtra=[");
                  LOG_STRING(command.xtra_params.first);
                  LOG_STRING(":");
                  LOG_STRING(command.xtra_params.second);
                  LOG_STRING("]"));

        bool result = false;

        // Execute based on direction
        if (command.direction == CommCommandDirection::SEND_RECV) {
            // Send first (first xtra_param), then receive (second xtra_param)
            result = executeSend(command.values.first, command.tokens.first, command.xtra_params.first);
            if (result && command.tokens.second != CommCommandTokenType::EMPTY) {
                result = executeReceive(command.values.second, command.tokens.second, command.xtra_params.second);
            }
        } else if (command.direction == CommCommandDirection::RECV_SEND) {
            // Receive first (first xtra_param), then send (second xtra_param)
            result = executeReceive(command.values.first, command.tokens.first, command.xtra_params.first);
            if (result && command.tokens.second != CommCommandTokenType::EMPTY) {
                result = executeSend(command.values.second, command.tokens.second, command.xtra_params.second);
            }
        } else if (command.direction == CommCommandDirection::DELAY) {
            size_t szDelay = 0;
            if (numeric::str2sizet(command.values.first, szDelay)) {
                if (command.values.second == TIME_MICROSECONDS) {
                    utime::delay_us(szDelay);    
                } else if (command.values.second == TIME_MILISECONDS) {
                    utime::delay_ms(szDelay);    
                } else if (command.values.second == TIME_SECONDS) {
                    utime::delay_seconds(szDelay);    
                } else {
                    LOG_PRINT(LOG_WARNING, LOG_HDR; LOG_STRING("No delay execution (invalid unit)"));
                } 
                result = true;
            }
        } else {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid command type"));
            return false;
        }

        if (!result) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Comm command failed"));
        }

        return result;
    }

    /**
     * @brief Get last received data
     */
    const std::vector<uint8_t>& getLastReceived() const
    {
        return m_lastReceived;
    }

    /**
     * @brief Set default timeout for operations
     */
    void setDefaultTimeout(uint32_t timeout)
    {
        m_defaultTimeout = timeout;
    }

    /**
     * @brief Set maximum receive buffer size
     */
    void setMaxRecvSize(size_t size)
    {
        m_maxRecvSize = size;
    }

private:

    std::shared_ptr<const TDriver> m_driver;
    std::string m_pluginName;
    size_t m_maxRecvSize;
    uint32_t m_defaultTimeout;
    SendFunc m_pfsend;
    RecvFunc m_pfrecv;
    std::vector<uint8_t> m_lastReceived;

    /**
     * @brief Physical write primitive — pfsend override if one was injected,
     *        otherwise m_driver->tout_write() directly (today's behaviour).
     */
    ICommDriver::WriteResult doWrite(std::span<const uint8_t> data, const std::string& xtra_params) const
    {
        return m_pfsend ? m_pfsend(m_defaultTimeout, data, m_driver, xtra_params)
                         : m_driver->tout_write(m_defaultTimeout, data, xtra_params);
    }

    /**
     * @brief Physical read primitive — pfrecv override if one was injected,
     *        otherwise m_driver->tout_read() directly (today's behaviour).
     */
    ICommDriver::ReadResult doRead(std::span<uint8_t> buffer, const ICommDriver::ReadOptions& options,
                                    const std::string& xtra_params) const
    {
        return m_pfrecv ? m_pfrecv(m_defaultTimeout, buffer, options, m_driver, xtra_params)
                         : m_driver->tout_read(m_defaultTimeout, buffer, options, xtra_params);
    }

    /**
     * @brief Append one Rx/Tx record to the GUI comm-dump panel, if enabled.
     *
     * No-op (single bool check) outside GUI mode, so it is safe to call
     * unconditionally after every tout_read()/tout_write(). describeConnection()
     * is documented as cheap/no-I/O, but we still gate it behind gui_mode_active()
     * so CLI runs pay nothing beyond the flag check. Zero-length transfers are
     * skipped (nothing meaningful to show, and avoids a stray row on timeouts
     * that returned 0 bytes).
     *
     * @param dir         Rx or Tx
     * @param xtra_params Same xtra_params passed to the tout_read()/tout_write()
     *                    call this record is reporting on, so describeConnection()
     *                    reflects the resolved channel/address for that exchange.
     * @param data        Pointer to the bytes actually transferred
     * @param len         Number of bytes actually transferred (bytes_read/bytes_written)
     */
    void notifyCommDump(CommDir dir, std::string_view xtra_params,
                         const uint8_t* data, size_t len) const
    {
        if (len == 0 || !gui_mode_active()) {
            return;
        }
        gui_notify_comm_dump(m_pluginName,
                              m_driver->describeConnection(xtra_params),
                              dir, data, static_cast<uint32_t>(len));
    }

    /**
     * @brief Execute a send operation
     * @param value       The data value to send (string representation)
     * @param type        The token type indicating how to interpret the value
     * @param xtra_params Optional channel/address identifier forwarded to tout_write
     * @return true if send successful, false otherwise
     */
    bool executeSend(const std::string& value, CommCommandTokenType type,
                     const std::string& xtra_params = {})
    {
        // Empty token means no send operation
        if (type == CommCommandTokenType::EMPTY) {
            return true;
        }

        LOG_PRINT(LOG_VERBOSE, LOG_HDR; 
                  LOG_STRING("Send:"); LOG_STRING(value); 
                  LOG_STRING("["); LOG_STRING(getTokenTypeName(type))
                  LOG_STRING("]"));

        // Handle file send specially
        if (type == CommCommandTokenType::FILENAME) {
            return sendFile(value, xtra_params);
        }

        // Convert value to bytes based on type
        std::vector<uint8_t> data;
        if (!convertToData(value, type, data)) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; 
                      LOG_STRING("Failed to convert data for send"));
            return false;
        }

        // Send the data
        auto result = doWrite(std::span<const uint8_t>(data), xtra_params);
        
        if (result.status != ICommDriver::Status::SUCCESS) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; 
                      LOG_STRING("Write failed:"); 
                      LOG_STRING(ICommDriver::to_string(result.status));
                      LOG_STRING("Bytes written:"); LOG_SIZET(result.bytes_written));
            return false;
        }

        // A pfsend override (e.g. a segmented transport protocol) knows what
        // actually went out on the wire and is responsible for its own
        // comm-dump row(s); this generic row would otherwise show the pre-
        // segmentation logical payload instead of the real physical frames.
        if (!m_pfsend) {
            notifyCommDump(CommDir::Tx, xtra_params, data.data(), result.bytes_written);
        }

        LOG_PRINT(LOG_VERBOSE, LOG_HDR; 
                  LOG_STRING("Sent:"); LOG_SIZET(result.bytes_written); 
                  LOG_STRING("bytes"));
        return true;
    }

    /**
     * @brief Execute a receive operation
     * @param value       The expected data value or pattern (string representation)
     * @param type        The token type indicating how to interpret the value
     * @param xtra_params Optional channel/address identifier forwarded to tout_read
     * @return true if receive successful and data matches expectation, false otherwise
     */
    bool executeReceive(const std::string& value, CommCommandTokenType type,
                        const std::string& xtra_params = {})
    {
        // Empty token means no receive operation
        if (type == CommCommandTokenType::EMPTY) {
            return true;
        }

        LOG_PRINT(LOG_VERBOSE, LOG_HDR; 
                  LOG_STRING("Recv:"); LOG_STRING(value); 
                  LOG_STRING("["); LOG_STRING(getTokenTypeName(type));
                  LOG_STRING("]"));

        switch (type) {
            case CommCommandTokenType::REGEX:
                return receiveAndMatchRegex(value, xtra_params);

            case CommCommandTokenType::TOKEN_STRING:
                return receiveUntilToken(value, false, xtra_params);

            case CommCommandTokenType::TOKEN_HEXSTREAM:
                return receiveUntilToken(value, true, xtra_params);

            case CommCommandTokenType::SIZEOF:
                return receiveExactSize(value, xtra_params);

            case CommCommandTokenType::LINE:
                return receiveUntilDelimiter('\n', value, xtra_params);

            case CommCommandTokenType::FILENAME:
                return receiveToFile(value, xtra_params);

            case CommCommandTokenType::HEXSTREAM:
            case CommCommandTokenType::STRING_DELIMITED:
            case CommCommandTokenType::STRING_DELIMITED_EMPTY:
            case CommCommandTokenType::STRING_RAW:
                return receiveAndCompare(value, type, xtra_params);

            case CommCommandTokenType::ANYTHING:
                return receiveAndHexdump(value, xtra_params);

            default:
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Unsupported receive token type"));
                return false;
        }
    }

    /**
     * @brief Receive data and match against regex pattern
     */
    bool receiveAndMatchRegex(const std::string& pattern, const std::string& xtra_params = {})
    {
        // Read exact bytes from driver
        m_lastReceived.resize(m_maxRecvSize);
        ICommDriver::ReadOptions options;
        options.mode = ICommDriver::ReadMode::Exact;

        auto result = doRead(std::span<uint8_t>(m_lastReceived), options, xtra_params);

        if (result.status != ICommDriver::Status::SUCCESS) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; 
                      LOG_STRING("Read failed:"); 
                      LOG_STRING(ICommDriver::to_string(result.status)));
            return false;
        }

        // Resize to actual bytes read
        m_lastReceived.resize(result.bytes_read);
        if (!m_pfrecv) {
            notifyCommDump(CommDir::Rx, xtra_params, m_lastReceived.data(), m_lastReceived.size());
        }

        // Convert to string for regex matching
        std::string received(m_lastReceived.begin(), m_lastReceived.end());

        // Match against pattern
        try {
            std::regex re(pattern);
            bool matched = std::regex_match(received, re);
            
            if (!matched) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; 
                          LOG_STRING("Regex match failed. Received:"); 
                          LOG_STRING(received));
            }
            
            return matched;
        } catch (const std::regex_error& e) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; 
                      LOG_STRING("Invalid regex pattern:"); 
                      LOG_STRING(e.what()));
            return false;
        }
    }

    /**
     * @brief Receive data until a specific token is found
     */
    bool receiveUntilToken(const std::string& tokenStr, bool isHexStream = false,
                           const std::string& xtra_params = {})
    {
        // Convert token string to bytes
        std::vector<uint8_t> token;
        if (!convertToData(tokenStr, (isHexStream ? CommCommandTokenType::TOKEN_HEXSTREAM : CommCommandTokenType::TOKEN_STRING), token)) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to convert token"));
            return false;
        }

        // Setup read options for token search
        m_lastReceived.resize(m_maxRecvSize);
        ICommDriver::ReadOptions options;
        options.mode = ICommDriver::ReadMode::UntilToken;
        options.token = std::span<const uint8_t>(token);
        options.use_buffer = true;

        auto result = doRead(std::span<uint8_t>(m_lastReceived), options, xtra_params);

        if (result.status != ICommDriver::Status::SUCCESS) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; 
                      LOG_STRING("Token search failed:"); 
                      LOG_STRING(ICommDriver::to_string(result.status)));
            return false;
        }

        if (!result.found_terminator) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Token not found within timeout"));
            return false;
        }

        // No comm-dump record here: every driver's ReadMode::UntilToken leaves
        // result.bytes_read == 0 by design (the matched bytes are consumed
        // internally by the KMP scan and never copied into the caller's
        // buffer), so there is nothing to hand to notifyCommDump(). For the
        // same reason, m_lastReceived is cleared rather than left at its
        // initial m_maxRecvSize-sized (stale/uninitialized) state, so that
        // getLastReceived() - and therefore a "VAL ?= PLUGIN.CMD ..." capture -
        // never surfaces garbage bytes for this receive type. Widening
        // ICommDriver::tout_read()/ReadResult to also expose the consumed
        // bytes for this mode is a possible follow-up, but out of scope here.
        m_lastReceived.clear();
        return true;
    }

    /**
     * @brief Receive exact number of bytes specified as size
     */
    bool receiveExactSize(const std::string& sizeStr, const std::string& xtra_params = {})
    {
        size_t expectedSize = 0;
        if (!numeric::str2sizet(sizeStr, expectedSize)) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid size value:"); LOG_STRING(sizeStr));
            return false;
        }

        if (expectedSize == 0 || expectedSize > m_maxRecvSize) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Size out of range:"); LOG_SIZET(expectedSize));
            return false;
        }

        m_lastReceived.resize(m_maxRecvSize);
        ICommDriver::ReadOptions options;
        options.mode = ICommDriver::ReadMode::Exact;

        auto result = doRead(std::span<uint8_t>(m_lastReceived), options, xtra_params);

        if (result.status != ICommDriver::Status::SUCCESS) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; 
                      LOG_STRING("Read failed:"); 
                      LOG_STRING(ICommDriver::to_string(result.status)));
            return false;
        }

        m_lastReceived.resize(result.bytes_read);
        if (!m_pfrecv) {
            notifyCommDump(CommDir::Rx, xtra_params, m_lastReceived.data(), m_lastReceived.size());
        }

        LOG_PRINT(LOG_VERBOSE, LOG_HDR; 
                  LOG_STRING("Received:"); LOG_SIZET(result.bytes_read); 
                  LOG_STRING("bytes"));
        return (result.bytes_read == expectedSize);
    }

    /**
     * @brief Receive data until delimiter character
     */
    bool receiveUntilDelimiter(uint8_t delimiter, const std::string& expectedStr,
                               const std::string& xtra_params = {})
    {
        m_lastReceived.resize(m_maxRecvSize);
        ICommDriver::ReadOptions options;
        options.mode = ICommDriver::ReadMode::UntilDelimiter;
        options.delimiter = delimiter;

        auto result = doRead(std::span<uint8_t>(m_lastReceived), options, xtra_params);

        if (result.status != ICommDriver::Status::SUCCESS) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; 
                      LOG_STRING("Read until delimiter failed:"); 
                      LOG_STRING(ICommDriver::to_string(result.status)));
            return false;
        }

        m_lastReceived.resize(result.bytes_read);
        if (!m_pfrecv) {
            notifyCommDump(CommDir::Rx, xtra_params, m_lastReceived.data(), m_lastReceived.size());
        }

        // If no expected string provided, just return success
        if (expectedStr.empty()) {
            LOG_PRINT(LOG_VERBOSE, LOG_HDR; 
                      LOG_STRING("Received line:"); LOG_SIZET(result.bytes_read); 
                      LOG_STRING("bytes"));
            return true;
        }

        // Compare with expected (add newline to expected for comparison)
        std::vector<uint8_t> expected;
        if (!convertToData(expectedStr, CommCommandTokenType::LINE, expected)) {
            return false;
        }

        // Note: m_lastReceived won't have the delimiter, but expected will have '\0'
        // added by the driver when the expected delimiter was encontered
        if (expected.size() > 0 && expected.back() == '\0') {
            expected.pop_back();
        }

        bool matched = std::equal(m_lastReceived.begin(), m_lastReceived.end(), 
                                 expected.begin(), expected.end());

        if (!matched) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Line content mismatch"));
        }

        return matched;
    }

    /**
     * @brief Receive data and compare with expected value
     */
    bool receiveAndCompare(const std::string& expectedStr, CommCommandTokenType type,
                           const std::string& xtra_params = {})
    {
        // First receive the data
        m_lastReceived.resize(m_maxRecvSize);
        ICommDriver::ReadOptions options;
        options.mode = ICommDriver::ReadMode::Exact;

        auto result = doRead(std::span<uint8_t>(m_lastReceived), options, xtra_params);

        if (result.status != ICommDriver::Status::SUCCESS) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; 
                      LOG_STRING("Read failed:"); 
                      LOG_STRING(ICommDriver::to_string(result.status)));
            return false;
        }

        m_lastReceived.resize(result.bytes_read);
        if (!m_pfrecv) {
            notifyCommDump(CommDir::Rx, xtra_params, m_lastReceived.data(), m_lastReceived.size());
        }

        // Convert expected string to bytes
        std::vector<uint8_t> expected;
        if (!convertToData(expectedStr, type, expected)) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to convert expected data"));
            return false;
        }

        // Compare
        bool matched = (result.bytes_read == expected.size()) &&
                      std::equal(m_lastReceived.begin(), m_lastReceived.end(),
                                expected.begin(), expected.end());

        if (!matched) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; 
                      LOG_STRING("Data mismatch. Expected:"); LOG_SIZET(expected.size());
                      LOG_STRING("Received:"); LOG_SIZET(result.bytes_read));
        }

        return matched;
    }

    /**
     * @brief Receive data and print is as hexdump
     */
    bool receiveAndHexdump(const std::string& expectedStr, const std::string& xtra_params = {})
    {
        // First receive the data
        m_lastReceived.resize(m_maxRecvSize);
        ICommDriver::ReadOptions options;
        options.mode = ICommDriver::ReadMode::Exact;

        auto result = doRead(std::span<uint8_t>(m_lastReceived), options, xtra_params);

        if (result.status != ICommDriver::Status::SUCCESS) {
            // "Receive whatever is sent" is a best-effort read: the driver is
            // expected to unblock either when some data arrives or when the
            // timeout elapses, and the caller/script sees neither of those as
            // an error - a timeout with nothing to show for it is a valid,
            // successful outcome (0 bytes), not a failure. A real I/O problem
            // (anything other than READ_TIMEOUT) is still reported as a
            // failure since it means the port itself is unusable.
            if (result.status == ICommDriver::Status::READ_TIMEOUT) {
                m_lastReceived.clear();
                LOG_PRINT(LOG_VERBOSE, LOG_HDR;
                          LOG_STRING("No data received within timeout (receive-anything is best-effort)"));
                return true;
            }

            LOG_PRINT(LOG_ERROR, LOG_HDR; 
                      LOG_STRING("Read failed:"); 
                      LOG_STRING(ICommDriver::to_string(result.status)));
            return false;
        }
        m_lastReceived.resize(result.bytes_read);
        if (!m_pfrecv) {
            notifyCommDump(CommDir::Rx, xtra_params, m_lastReceived.data(), m_lastReceived.size());
        }
        hexutils::logHexdump(LOG_VERBOSE, "Recv:", "SAoC", m_lastReceived);

        return true;
    }

    /**
     * @brief Send file in chunks
     * Format: "filename" or "filename,chunksize"
     */
    bool sendFile(const std::string& fileSpec, const std::string& xtra_params = {})
    {
        // Parse filename and optional chunk size
        std::pair<std::string, std::string> parts;
        ustring::splitAtFirst(fileSpec, CHAR_SEPARATOR_COMMA, parts);

        std::string filepath = parts.first;
        size_t chunkSize = 1024; // Default chunk size

        // Parse chunk size if provided
        if (!parts.second.empty()) {
            if (!numeric::str2sizet(parts.second, chunkSize)) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid chunk size:"); LOG_STRING(parts.second));
                return false;
            }
        }

        // Validate file exists
        if (!std::filesystem::exists(filepath) || 
            !std::filesystem::is_regular_file(filepath)) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("File not found:"); LOG_STRING(filepath));
            return false;
        }

        // Get file size
        auto fileSize = std::filesystem::file_size(filepath);
        LOG_PRINT(LOG_VERBOSE, LOG_HDR; 
                  LOG_STRING("Sending file:"); LOG_STRING(filepath);
                  LOG_STRING("Size:"); LOG_UINT64(fileSize);
                  LOG_STRING("Chunk:"); LOG_SIZET(chunkSize));

        // Open file
        std::ifstream file(filepath, std::ios::binary);
        if (!file) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to open file:"); LOG_STRING(filepath));
            return false;
        }

        // Send file in chunks
        std::vector<uint8_t> chunk(chunkSize);
        size_t totalSent = 0;

        while (file) {
            file.read(reinterpret_cast<char*>(chunk.data()), chunkSize);
            std::streamsize bytesRead = file.gcount();

            if (bytesRead > 0) {
                std::span<const uint8_t> dataSpan(chunk.data(), bytesRead);
                auto result = doWrite(dataSpan, xtra_params);

                if (result.status != ICommDriver::Status::SUCCESS) {
                    LOG_PRINT(LOG_ERROR, LOG_HDR; 
                              LOG_STRING("File write failed at offset:"); 
                              LOG_SIZET(totalSent);
                              LOG_STRING("Status:"); 
                              LOG_STRING(ICommDriver::to_string(result.status)));
                    return false;
                }

                if (!m_pfsend) {
                    notifyCommDump(CommDir::Tx, xtra_params, chunk.data(), result.bytes_written);
                }
                totalSent += result.bytes_written;
            }
        }

        LOG_PRINT(LOG_VERBOSE, LOG_HDR; 
                  LOG_STRING("File sent successfully. Total:"); 
                  LOG_SIZET(totalSent); LOG_STRING("bytes"));
        return true;
    }

    /**
     * @brief Receive data to file
     * Format: "filename" or "filename,expected_size" or "filename,expected_size,chunksize"
     */
    bool receiveToFile(const std::string& fileSpec, const std::string& xtra_params = {})
    {
        // Parse the file specification
        std::vector<std::string> parts;
        ustring::tokenize(fileSpec, CHAR_SEPARATOR_COMMA, parts);

        if (parts.empty() || parts[0].empty()) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid file specification"));
            return false;
        }

        std::string filepath = parts[0];
        size_t expectedSize = 0;
        size_t chunkSize = 1024;

        // Parse optional expected size
        if (parts.size() > 1 && !parts[1].empty()) {
            if (!numeric::str2sizet(parts[1], expectedSize)) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid expected size:"); LOG_STRING(parts[1]));
                return false;
            }
        }

        // Parse optional chunk size
        if (parts.size() > 2 && !parts[2].empty()) {
            if (!numeric::str2sizet(parts[2], chunkSize)) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Invalid chunk size:"); LOG_STRING(parts[2]));
                return false;
            }
        }

        LOG_PRINT(LOG_VERBOSE, LOG_HDR; 
                  LOG_STRING("Receiving to file:"); LOG_STRING(filepath);
                  LOG_STRING("Expected:"); LOG_SIZET(expectedSize);
                  LOG_STRING("Chunk:"); LOG_SIZET(chunkSize));

        // Open output file
        std::ofstream file(filepath, std::ios::binary);
        if (!file) {
            LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Failed to create file:"); LOG_STRING(filepath));
            return false;
        }

        // Receive file in chunks
        std::vector<uint8_t> chunk(chunkSize);
        size_t totalReceived = 0;
        ICommDriver::ReadOptions options;
        options.mode = ICommDriver::ReadMode::Exact;

        while (true) {
            // Determine how many bytes to read in this iteration
            size_t bytesToRead = chunkSize;
            if (expectedSize > 0 && (totalReceived + chunkSize > expectedSize)) {
                bytesToRead = expectedSize - totalReceived;
                if (bytesToRead == 0) break; // All expected data received
            }

            // Read chunk
            std::span<uint8_t> buffer(chunk.data(), bytesToRead);
            auto result = doRead(buffer, options, xtra_params);

            if (result.status != ICommDriver::Status::SUCCESS) {
                // Check if we've received all expected data
                if (expectedSize > 0 && totalReceived == expectedSize) {
                    break;
                }
                LOG_PRINT(LOG_ERROR, LOG_HDR; 
                          LOG_STRING("File read failed:"); 
                          LOG_STRING(ICommDriver::to_string(result.status)));
                return false;
            }

            if (result.bytes_read == 0) {
                break; // No more data
            }

            if (!m_pfrecv) {
                notifyCommDump(CommDir::Rx, xtra_params, chunk.data(), result.bytes_read);
            }

            // Write to file
            file.write(reinterpret_cast<const char*>(chunk.data()), result.bytes_read);
            if (!file) {
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("File write failed"));
                return false;
            }

            totalReceived += result.bytes_read;

            // Stop if we've received expected amount
            if (expectedSize > 0 && totalReceived >= expectedSize) {
                break;
            }
        }

        LOG_PRINT(LOG_VERBOSE, LOG_HDR; 
                  LOG_STRING("File received successfully. Total:"); 
                  LOG_SIZET(totalReceived); LOG_STRING("bytes"));
        return true;
    }

    /**
     * @brief Convert string value to data bytes based on token type
     */
    bool convertToData(const std::string& value, 
                      CommCommandTokenType type, 
                      std::vector<uint8_t>& data) const
    {
        switch (type) {
            case CommCommandTokenType::HEXSTREAM:
                return hexutils::hexstringToVector(value, data);
            case CommCommandTokenType::LINE:                
            case CommCommandTokenType::STRING_RAW:
            case CommCommandTokenType::STRING_DELIMITED:
            case CommCommandTokenType::STRING_DELIMITED_EMPTY:
                return ustring::stringToVector(expandEscapes(value), data);
            case CommCommandTokenType::TOKEN_STRING:
                return ustring::stringToVector(expandEscapes(value), data, false);
            case CommCommandTokenType::TOKEN_HEXSTREAM:
                return hexutils::stringUnhexlify(value, data);
            default:
                LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Unsupported token type for data conversion"));
                return false;
        }
    }

    /**
     * @brief Expand literal escape sequences into their actual byte values
     * @param value Input string possibly containing literal \r and \n sequences
     * @return String with \r replaced by 0x0D and \n replaced by 0x0A
     * 
     * Handles:
     *   \r        → 0x0D
     *   \n        → 0x0A
     *   \r\n      → 0x0D 0x0A
     *   \\r \\n   → left as-is (escaped backslash)
     */
    std::string expandEscapes(const std::string& value) const
    {
        std::string result;
        result.reserve(value.size());

        for (size_t i = 0; i < value.size(); ++i) {
            if (value[i] == '\\' && (i + 1) < value.size()) {
                switch (value[i + 1]) {
                    case 'r':
                        result += '\r';     // 0x0D
                        ++i;
                        continue;
                    case 'n':
                        result += '\n';     // 0x0A
                        ++i;
                        continue;
                    case '\\':
                        result += '\\';    // escaped backslash → keep one
                        ++i;
                        continue;
                    default:
                        break;
                }
            }
            result += value[i];
        }

        return result;
    }    
};

#endif // U_COMM_SCRIPT_COMMAND_INTERPRETER_HPP
