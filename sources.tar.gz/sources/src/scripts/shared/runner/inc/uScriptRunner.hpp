#ifndef U_SCRIPT_RUNNER_HPP
#define U_SCRIPT_RUNNER_HPP

#include "IScriptInterpreter.hpp"
#include "IScriptReader.hpp"
#include "IScriptRunner.hpp"
#include "IScriptValidator.hpp"
#include "uLogger.hpp"
#include "uScriptDataTypes.hpp"

#include <memory>
#include <string>
#include <vector>

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
#undef LT_HDR
#endif
#ifdef LOG_HDR
#undef LOG_HDR
#endif

#define LT_HDR  "SCR_RUN     |"
#define LOG_HDR LOG_STRING(LT_HDR)

/////////////////////////////////////////////////////////////////////////////////
//                    CLASS DECLARATION / DEFINITION                           //
/////////////////////////////////////////////////////////////////////////////////

/**
 * @brief Basic script runner without communication driver dependency
 *
 * Coordinates script reading, validation, and interpretation for scripts
 * that don't require device communication.
 *
 * @tparam TScriptEntries Type representing script entries/commands
 */
template <typename TScriptEntries>
class ScriptRunner : public IScriptRunner {
    public:
        /**
         * @brief Construct a basic script runner
         * @param shpScriptReader Script reader component
         * @param shvScriptValidator Script validator component
         * @param shvScriptInterpreter Script interpreter component (Level 1)
         */
        explicit ScriptRunner(std::shared_ptr<IScriptReader> shpScriptReader,
                              std::shared_ptr<IScriptValidator<TScriptEntries>> shpShvScriptValidator,
                              std::shared_ptr<IScriptInterpreter<TScriptEntries>> shpShvScriptInterpreter)
            : m_shpScriptReader(std::move(shpScriptReader))
            , m_shpScriptValidator(std::move(shpShvScriptValidator))
            , m_shpScriptInterpreter(std::move(shpShvScriptInterpreter))
        {
        }

        bool runScript(const char *pstrCallCtx, bool bRealExec, bool bUseDryRun) override
        {
            bool bRetVal = false;

            do {

                // validation phase
                if (!bRealExec) {
                    LOG_PRINT(LOG_FIXED, LOG_HDR; LOG_STRING("Reading"); LOG_STRING(pstrCallCtx));
                    if (false == m_shpScriptReader->readScript(m_vRawScriptLines)) {
                        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Script reading failed"));
                        break;
                    }

                    LOG_PRINT(LOG_FIXED, LOG_HDR; LOG_STRING("Validating"); LOG_STRING(pstrCallCtx));
                    if (false == m_shpScriptValidator->validateScript(m_vRawScriptLines, m_sScriptEntries)) {
                        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Script validation failed"));
                        break;
                    }

                    LOG_PRINT(LOG_FIXED, LOG_HDR; LOG_STRING("Dry interpreting"); LOG_STRING(pstrCallCtx));
                    if (false == m_shpScriptInterpreter->interpretScript(m_sScriptEntries, false)) {
                        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Script dry interpretation failed"));
                        break;
                    }

                    // execution phase
                } else {
                    LOG_PRINT(LOG_FIXED, LOG_HDR; LOG_STRING("Interpreting"); LOG_STRING(pstrCallCtx));
                    if (false == m_shpScriptInterpreter->interpretScript(m_sScriptEntries, true)) {
                        LOG_PRINT(LOG_ERROR, LOG_HDR; LOG_STRING("Script interpretation failed"));
                        break;
                    }
                }

                bRetVal = true;

            } while (false);

            return bRetVal;
        }

    protected:
        std::shared_ptr<IScriptReader> m_shpScriptReader;
        std::shared_ptr<IScriptValidator<TScriptEntries>> m_shpScriptValidator;
        std::shared_ptr<IScriptInterpreter<TScriptEntries>> m_shpScriptInterpreter;

    private:
        std::vector<ScriptRawLine> m_vRawScriptLines;
        TScriptEntries m_sScriptEntries;
};

#endif // U_SCRIPT_RUNNER_HPP
