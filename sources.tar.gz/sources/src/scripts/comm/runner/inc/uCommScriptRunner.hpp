#ifndef SCRIPTRUNNER_COMM_HPP
#define SCRIPTRUNNER_COMM_HPP

#include "ICommScriptInterpreter.hpp"
#include "uScriptRunner.hpp"

#include <memory>

/////////////////////////////////////////////////////////////////////////////////
//                            LOG DEFINITIONS                                  //
/////////////////////////////////////////////////////////////////////////////////

#ifdef LT_HDR
#undef LT_HDR
#endif
#ifdef LOG_HDR
#undef LOG_HDR
#endif

#define LT_HDR  "COMMSCRIPT_R|"
#define LOG_HDR LOG_STRING(LT_HDR)

/////////////////////////////////////////////////////////////////////////////////
//                    CLASS DECLARATION / DEFINITION                           //
/////////////////////////////////////////////////////////////////////////////////

/**
 * @brief Script runner with communication driver support
 *
 * Extends the basic script runner to work with communication-enabled
 * interpreters for scripts that interact with devices/drivers.
 *
 * @tparam TScriptEntries Type representing script entries/commands
 * @tparam TDriver Type of communication driver
 */
template <typename TScriptEntries, typename TDriver = void>
class CommScriptRunner : public ScriptRunner<TScriptEntries> {
    public:
        /**
         * @brief Construct a communication-enabled script runner
         * @param shpScriptReader Script reader component
         * @param shvScriptValidator Script validator component
         * @param shvScriptInterpreter Communication-enabled script interpreter (Level 2+)
         */
        explicit CommScriptRunner(std::shared_ptr<IScriptReader> shpScriptReader,
                                  std::shared_ptr<IScriptValidator<TScriptEntries>> shpShvScriptValidator,
                                  std::shared_ptr<ICommScriptInterpreter<TScriptEntries, TDriver>> shpShvScriptInterpreter)
            : ScriptRunner<TScriptEntries>(shpScriptReader, shpShvScriptValidator, shpShvScriptInterpreter)
            , m_shpScriptInterpreterComm(std::move(shpShvScriptInterpreter))
        {
        }

    private:
        std::shared_ptr<ICommScriptInterpreter<TScriptEntries, TDriver>> m_shpScriptInterpreterComm;
};

#endif // SCRIPTRUNNER_COMM_HPP
