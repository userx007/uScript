#pragma once
#include "ScriptHighlighterBase.hpp"

class QTextDocument;

/**
 * @brief Syntax highlighter for the uscript language.
 *
 * Inherits block-comment handling, highlightBlock(), fmt(), addRule(),
 * addMacroAssignRule(), addMacroVariableRule() and addTypedTokenDecorators()
 * from ScriptHighlighterBase.
 *
 *  Colour ownership — full table (Dracula-inspired palette):
 *  ──────────────────────────────────────────────────────────────────────
 *  Token / role                     Hex       Colour      Style   Owner
 *  ──────────────────────────────────────────────────────────────────────
 *  NAME in NAME :=                  #bd93f9   purple      bold    base
 *  := operator                      #ff79c6   pink                base
 *  NAME in NAME ?=                  #8be9fd   cyan        bold    here
 *  NAME in NAME [=                  #ffb86c   amber       bold    here
 *  ?=  [=  operators                #ff79c6   pink                here
 *    (all three assignment ops share pink for visual unity)
 *  $VAR / $ARR.$IDX                 #8be9fd   cyan                base
 *  $NAME  in $NAME.SIZE             #ffb86c   amber       bold    here
 *  SIZE   in $NAME.SIZE             #bd93f9   purple              here
 *    (SIZE reads a declared array macro's element count — see
 *     m_validateArraySizeUsage() in uScriptValidator.cpp)
 *  PLUGIN.  namespace               #20a39e   green       bold    here
 *  .COMMAND                         #ff5555   red         bold    here
 *    (green↔red complement pair — strongest contrast on the wheel)
 *  LOAD_PLUGIN keyword              #ff79c6   pink        bold    here
 *  LOAD_PLUGIN argument             #20a39e   green       bold    here
 *  IF / GOTO / REPEAT / UNTIL /     #ff79c6   pink        bold    here
 *    BREAK / CONTINUE / END_REPEAT
 *  LABEL keyword                    #ff79c6   pink        bold    here
 *    (same as all other control-flow keywords)
 *  label name                       #bd93f9   purple              here
 *    (same family as constant names)
 *  REPEAT range literal token       #89a1ef   blue                here
 *    (begin / end / step — decimal, hex, binary, octal, or float/exp)
 *  REPEAT range $macro token        #8be9fd   cyan                here
 *  REPEAT range ","  separator      #6272a4   slate               here
 *  PRINT / DELAY / FORMAT /         #a5b4fc   periwinkle  bold    here
 *    MATH / EVAL / BITSTREAM /
 *    BYTESTREAM / BITSTREAMVAL /
 *    BYTESTREAMVAL
 *  | HEX  post-processor pipe       #6272a4   slate               here
 *  HEX    post-processor keyword    #a5b4fc   periwinkle  bold    here
 *    (same as MATH/EVAL — HEX is a post-processing function)
 *  HEX width digits (8/16/.../128)  #bd93f9   purple              here
 *    or FLOAT / DOUBLE
 *  HEX endian (LE / BE)             #8be9fd   cyan                here
 *  BITSTREAM/BYTESTREAM/            #89a1ef   blue                here
 *    BYTESTREAMVAL field
 *    offset/length/value literal
 *      (BYTESTREAMVAL's byte_offset:bit_offset:value_size shares this
 *       row: same 3-colon-separated-token shape as BITSTREAM/BYTESTREAM's
 *       own offset:length:value, coloured by the same unanchored rule —
 *       covers both the scalar "?=" and array "[=" forms, and any number
 *       of array fields, with no dedicated rule needed)
 *  BITSTREAM/BYTESTREAM/            #8be9fd   cyan                here
 *    BYTESTREAMVAL field
 *    offset/length/value $macro
 *  BITSTREAM/BYTESTREAM/            #6272a4   slate               here
 *    BYTESTREAMVAL field ":"
 *  BITSTREAMVAL field               #89a1ef   blue                here
 *    bit_offset/value_size literal
 *      (own rule: 2-colon-separated-token shape, guarded against
 *       matching inside a 3-token BYTESTREAM(VAL) field — covers both
 *       the scalar "?=" and array "[=" forms)
 *  BITSTREAMVAL field               #8be9fd   cyan                here
 *    bit_offset/value_size $macro
 *  BITSTREAMVAL field ":"           #6272a4   slate               here
 *  | REVERSE_BIT|REVERSE_BYTE pipe  #6272a4   slate               here
 *  REVERSE_BIT / REVERSE_BYTE       #a5b4fc   periwinkle  bold    here
 *    (same as HEX — another post-processing function)
 *  BREAKPOINT                       #ff5555   red         bold    here
 *  |NUM  |STR  |VER  |BOOL          #8be9fd   cyan                here
 *  ==  !=  >=  <=  >  <             #ff79c6   pink                here
 *  AND  OR  NOT                     #ff79c6   pink                here
 *  TRUE                             #0F956A   green               here
 *  FALSE                            #CB2C2A   red                 here
 *  &  thread suffix                 #50fa7b   bright-green bold   here
 *    (Dracula "go" green — visually distinct, semantically: "launch")
 *  H  X  prefix letter              #ff5555   red         bold    base
 *  R  prefix letter                 #ffb86c   amber       bold    base
 *  T  L  prefix letter              #8be9fd   cyan        bold    base
 *  S  prefix letter                 #bd93f9   purple      bold    base
 *  F  prefix letter                 #ff79c6   pink        bold    base
 *  All '...' content                #f1fa8c   yellow              base  (RESERVED)
 *  %0 %1 …  format tokens           #ffb86c   amber               here
 *  v1.2.3  version literals         #89a1ef   blue                here
 *  numeric literals                 #89a1ef   blue                here
 *    (hex 0x… / binary 0b… / octal 0o… / decimal, optionally signed —
 *     see ScriptHighlighterBase::addNumericLiteralRule())
 *  # comment / --- !-- delimiters   #6272a4   slate               base
 *  ──────────────────────────────────────────────────────────────────────
 */
class ScriptHighlighter : public ScriptHighlighterBase
{
    Q_OBJECT
public:
    explicit ScriptHighlighter(QTextDocument *parent = nullptr);
};
